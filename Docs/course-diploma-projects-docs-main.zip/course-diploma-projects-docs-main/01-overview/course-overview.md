<!-- prev: none | next: project-types-and-criteria.md -->

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Start here. Understand the course structure before choosing your topic.

    :school: **Staff:** Reference for explaining the course to new students.

    **Prerequisites:** None — this is where everyone starts.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Diploma Project Documentation

This knowledge base contains all documentation for the diploma project process: course requirements, organizational procedures, templates, and recommendations.

---

## What the Knowledge Base Includes

| Section | Contents |
|---------|----------|
| [**01 — Overview**](course-overview.md) | Course overview and project types |
| [**02 — Getting Started**](../02-getting-started/team-rules.md) | Topic selection, supervisor role, lifecycle |
| [**03 — Process and Timeline**](../03-process-and-timeline/diploma-lifecycle.md) | Key dates, team rules, reviews, assessments |
| [**04 — Technical Requirements**](../04-technical-requirements/04a-business-and-docs/business-analysis.md) | Requirements for 17 technical courses |
| [**05 — Deliverables**](../05-deliverables/official-requirements.md) | Thesis guide, presentation, video, templates |
| [**06 — Defense and Completion**](../06-defense-and-completion/final-deliverables-checklist.md) | Final checklist, defense process, repository upload |

---

## Course Requirements

Here you will find requirements for different components of the diploma project. Each file contains minimum (5 points) and maximum (10 points) requirements.

| # | Course |
|---|--------|
| 1 | Databases |
| 2 | Backend Development |
| 3 | Adaptive UI |
| 4 | Refined UX |
| 5 | AI Assistant / Chatbot |
| 6 | CI/CD |
| 7 | Frontend Development |
| 8 | Microservice Architecture |
| 9 | Containerization |
| 10 | API Documentation |
| 11 | Automated Testing |
| 12 | Business Analysis |
| 13 | Cloud Technologies |
| 14 | Cryptography |
| 15 | Machine Learning |
| 16 | Qualitative/Quantitative Testing |
| 17 | Real-time Analytics |

---

## Organization

This section contains organizational documents that define the diploma project process.

| # | Description |
|---|-------------|
| 1 | Topic requirements and complexity criteria |
| 2 | Key dates and project milestones |
| 3 | Team work rules |
| 4 | Advisor responsibilities |
| 5 | Expert reviewer responsibilities |
| 6 | Advisor qualifications |
| 7 | Topic change deadlines |
| 8 | Diploma project timeline |
| 9 | Administration guide |
| 10 | Defense registration requirements |
| 11 | Upload to the state repository |
| 12 | Review process |
| 13 | Pre-defense (предзащита) recommendations |
| 14 | Final materials before the defense |

---

## Final Deliverables

This section describes requirements for the final deliverables of your diploma project.

| Name | Description |
|------|-------------|
| Explanatory note requirements | Folder with explanatory note requirements |
| Presentation requirements | Requirements for the presentation |
| Demo video requirements | Requirements for the demo video |

### Official Documents

The following official documents are also available:

| Document | Description |
|----------|-------------|
| Cover page and summary | Cover page and summary of official requirements |
| Methodological guidelines | Full methodological guidelines for diploma project formatting |

---

## Templates

Use the following document templates to fill in.

| # | Description |
|---|-------------|
| 1 | Review template for an independent expert |
| 2 | Advisor's review template |
