<!-- prev: course-overview.md | next: ../02-getting-started/team-rules.md -->

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Use this to choose your project type and select 7+ complexity criteria.

    :school: **Staff:** Reference for verifying student criteria selection.

    **Prerequisites:** Read [Course Overview](course-overview.md) first.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Topic Requirements and Complexity

## Project Types

You can choose one of the following project types:

- Web applications
- Mobile applications
- Game applications

---

## Complexity Criteria List

*(Labels: required, technical, data, infrastructure, processes)*

| Complexity Criteria | Description |
|---------------------|-------------|
| **Business Analysis** (required) | vision, problem, stakeholders, scope, features — **defended before committee** |
| **Back-end** (required) |  |
| **Front-end** (required) |  |
| **Refined UX** (technical) | user scenarios, wireframes, testing |
| **Adaptive UI (Web/Mobile)** (technical) | works correctly for 3 or more form factors |
| **AI Assistant / Chatbot** (technical) | NLP pipeline |
| **Cryptography** (technical) |  |
| **Database** (data) | normalization, indexes, ER diagram |
| **Real-time Analytics** (data) |  |
| **ML Model** (data) | training, metric not lower than baseline |
| **Cloud** (infrastructure) | deploy to AWS/Azure/GCP |
| **Microservices** (infrastructure) | 2 or more services, REST/gRPC |
| **CI/CD pipeline** (infrastructure) | automated tests + deploy |
| **Containerization** (infrastructure) | Docker/Compose/K8s |
| **API Documentation** (processes) | OpenAPI 3.0/GraphQL schema |
| **Automated tests with 70%+ coverage** (processes) | unit + integration |
| **Qualitative or quantitative testing** (processes) | report |

---

## How a "Complete Diploma" Is Calculated

The complexity criteria exist to help you verify that your project is sufficiently complex for a diploma. Think of them as a **minimum threshold**, not a guarantee:

- **If your project does not meet the criteria** → it will not be admitted to the defense (with rare exceptions).
- **If your project meets the criteria** → it satisfies the minimum complexity requirement, but admission also depends on implementation quality, defense performance, and expert evaluations.

> Meeting all checkmarks is necessary but not sufficient for a successful defense.

| Level | Min. total checkmarks | Restrictions |
|-------|-----------------------|--------------|
| **Standard** | 7 | You need at least 1 from each category (technical, data, infrastructure, processes) and 1 from required |
| **Team** | 10 | When working in a team, each student must choose their own 5 checkmarks |

> **Important:** Checkmarks measure breadth (how many areas you cover). The pre-defense committee also evaluates **depth** (how complex each component is). A project with 7 checkmarks at surface level may still be deemed insufficient. Conversely, a highly specialized project (e.g., a Rust framework) with fewer UI components but deep backend complexity may be accepted — discuss with your supervisor early.

---

## What Is Not Allowed

> Violating any of these rules leads to topic rejection with no option to revise.

| Not Allowed | Explanation |
|-------------|-------------|
| **Template online stores** | Ready-made CMS themes (WooCommerce, Shopify, PrestaShop, etc.) with minimal changes to the interface or logic, and similar projects. |
| **Reuse of previous work** | Projects already defended in other subjects, courses, hackathons, or external competitions. |
| **Tutorial clone** | A step-by-step copy of a GitHub repository, article, or YouTube course without significant improvements. |
| **Zero code originality** | Auto-generated code/scripts where 80% or more of lines match public examples without original modifications. |
| **Black-box Low-code** | Built with website builders (Wix, Tilda, etc.) where you cannot show the source code or architecture. Also, using messengers (Telegram, etc.) as the front-end part of the application without significant custom logic. |
| **License violations** | Use of illegal software, unlisted OSS licenses, EULA violations. |
| **No GDPR compliance** | Projects that process personal data without a Privacy Notice and DPA. |
| **Ethical restrictions** | Content that violates academic ethics, promotes violence, or discrimination. |
| **Low technical level** | Work that does not meet the minimum score (see the criteria matrix). |

> Whether a project falls into the "risk zone" is discussed during the topic approval stage.
