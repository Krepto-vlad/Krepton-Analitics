# Staff Guide

Quick reference for supervisors, experts, and administrators. Find your responsibilities by role and stage.

=== "Supervisor / Expert"

    ## Your Responsibilities by Stage

    | Stage | When | What You Do | Reference |
    |-------|------|-------------|-----------|
    | Topic Selection | Weeks 1–2 | Verify student's criteria selection (7+ items), sign application | [Supervisor Role](02-getting-started/supervisor-role.md) |
    | Weekly Standups | Weeks 4–18 | 15-min weekly check-ins with student (document all meetings) | [Supervisor Role](02-getting-started/supervisor-role.md) |
    | Progress Review 1 | Weeks 4–6 | Evaluate initial prototype/architecture | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Progress Review 2 | Weeks 10–12 | Evaluate working MVP; **assess complexity risk** | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Progress Review 3 | Weeks 13–15 | Evaluate feature-complete build | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Expert Assessments | Weeks 7–18 | Set assessment slots, pre-check materials, grade students (10-point scale) | [Expert Assessment](03-process-and-timeline/expert-assessment.md) |
    | Progress Review 4 | Weeks 17–18 | Evaluate final version + thesis draft | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Thesis Review | Week 18 | Proofread English thesis (receive at least 5 working days before pre-defense) | [Thesis Guide](05-deliverables/thesis-guide.md) |
    | Pre-Defense Admission | Week 19 | Sign admission to pre-defense or provide written rejection | [Defense Preparation](06-defense-and-completion/defense-preparation.md) |
    | Supervisor Review | Week 20 | Write review using `advisors-review.docx` template | [Review Templates](05-deliverables/review-templates.md) |

    !!! warning "Key obligation: Complexity check at Week 10"
        At **Progress Review 2**, you must assess whether the student's project meets complexity requirements. If the project is too simple, you must notify the student **in writing**. The pre-defense committee evaluates overall project complexity — not just individual criteria.

    ??? info "Expert Assessment Quick Reference"
        **How it works:**

        - Set available time slots for students to book
        - Pre-check submitted materials a few days before the meeting
        - Hold max **2 meetings** per student per criterion:
            1. **Stage defense:** Assess grade, explain verbally, recommend improvements
            2. **Appeal (optional):** Assign final grade — no further appeal possible
        - Grade on a **10-point scale**
        - A grade **below 5** or **"not passed"** means the student is **not admitted to final defense**

        **Your decision points:**

        - Expert grade per criterion: You decide
        - Admission to pre-defense: Supervisor decides (sign or reject in writing)

        See [Expert Assessment](03-process-and-timeline/expert-assessment.md) and [Booking Slots](03-process-and-timeline/booking-slots.md) for full details.

    ??? info "Supervisor Qualifications"
        Who can be a supervisor:

        - SDC instructor with Master's or PhD degree
        - Outside university instructor with Master's or PhD degree
        - Industry specialist with 3+ years of relevant experience

        See [Supervisor Role](02-getting-started/supervisor-role.md) for full details.

=== "Administrator"

    ## Your Responsibilities by Stage

    | Stage | When | What You Do | Reference |
    |-------|------|-------------|-----------|
    | Semester Start | Week 1 | Publish semester timeline, distribute to all participants | [Timeline](03-process-and-timeline/timeline.md), [Admin Guide](03-process-and-timeline/admin-guide.md) |
    | Topic Approval | Weeks 2–3 | Review applications, approve or reject topics | [Admin Guide](03-process-and-timeline/admin-guide.md) |
    | Slot Setup | After approval | Assign expert assessment slots, announce sign-up process | [Booking Slots](03-process-and-timeline/booking-slots.md) |
    | Progress Monitoring | Weeks 4–18 | Monitor 4 progress reviews across all students | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Pre-Defense | Week 19 | Organize pre-defense schedule (send at least 2 weeks in advance) | [Admin Guide](03-process-and-timeline/admin-guide.md) |
    | Reviewer Assignment | After pre-defense | Provide independent reviewer contacts (within 3 working days) | [Review Process](06-defense-and-completion/review-process.md) |
    | Review Collection | Weeks 20–21 | Confirm both reviews (supervisor + independent) are received | [Review Templates](05-deliverables/review-templates.md) |
    | Final Defense | Week 22 | Organize final defense, collect all final materials | [Final Checklist](06-defense-and-completion/final-deliverables-checklist.md) |

    !!! info "Decision Authority"
        | Decision | Who Decides |
        |----------|-------------|
        | Topic approval | Administration |
        | Expert grade per criterion | Expert instructor |
        | Admission to pre-defense | Supervisor |
        | Admission to final defense | Pre-defense committee |
        | Final grade | Defense committee |

    ??? success "Communication Checklist"
        Use this checklist to track your communications each semester:

        - [ ] Timeline published and distributed to all students and staff
        - [ ] Expert assessment slots announced with sign-up instructions
        - [ ] Pre-defense schedule sent at least 2 weeks in advance
        - [ ] Reviewer contacts distributed within 3 working days of successful pre-defense
        - [ ] Final defense schedule confirmed at least 2 weeks in advance
        - [ ] Upload instructions for national repository sent to students

    ??? info "Topic Change Handling"
        - Students may change topics freely until the administrative deadline you set
        - After **BA defense**: students may change topic (including radical changes), but must re-defend BA for the new topic
        - After **pre-defense**: only minor adjustments to topic wording/description are allowed (within 3 working days, only if committee recommends). No radical changes to topic or scope
        - Students submit changes via standard form to office@esdc.lt (CC supervisor)

        See [Topic Changes](02-getting-started/topic-changes.md) for the student-facing process.

    ### Key Reference Pages

    - [Admin Guide](03-process-and-timeline/admin-guide.md) — full operational procedures
    - [Timeline](03-process-and-timeline/timeline.md) — week-by-week milestones with deadlines
    - [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) — 6 lifecycle stages overview
