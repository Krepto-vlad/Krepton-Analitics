<!-- prev: booking-slots.md | next: admin-guide.md -->

!!! abstract "Stage 4 of 7 — Build & Get Assessed | Weeks 7–15"
    :mortar_board: **Students:** Week-by-week milestones and critical deadlines. Bookmark this page.

    :school: **Staff:** Complete semester timeline for reference.

    **Prerequisites:** Topic approved. Use this as your calendar throughout the semester.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Diploma Project Timeline

## Overview

This timeline defines the key milestones and deadlines for the diploma project. All dates are approximate and will be confirmed by the administration at the start of each semester.

---

## Week-by-Week Schedule

| Week | Milestone | Deliverable | Responsible |
|------|-----------|-------------|-------------|
| 1-2 | Topic selection and supervisor assignment | Signed application form | Student + Supervisor |
| 3 | Topic approval by administration | Approved application | Administration |
| 4-6 | Progress Review 1 (опроцентовка 1) | Initial prototype / architecture | Student → Supervisor |
| 7-9 | Expert submissions begin | Materials sent to experts 1 week before slot | Student → Expert |
| 10-12 | Progress Review 2 (опроцентовка 2) — **includes complexity check** | Working MVP with core features | Student → Supervisor |
| 13-15 | Progress Review 3 (опроцентовка 3) | Feature-complete build | Student → Supervisor |
| 16-17 | **Video deadline** | Demo video (.mp4) finalized | Student |
| 17-18 | Progress Review 4 (опроцентовка 4) | Final version, thesis draft complete | Student → Supervisor |
| 18 | **Thesis submitted to supervisor** | Final explanatory note (5 working days before pre-defense) | Student → Supervisor |
| 19 | **Pre-defense** | Presentation + deployed application + video | Student → Committee |
| 20 | Reviews obtained | Supervisor review + independent review | Student |
| 21 | Repository upload | Upload to talpykla.elaba.lt | Student |
| 22 | **Final defense** | All deliverables complete | Student → Committee |

> **Note:** The administration will publish exact dates at the beginning of each semester. This table shows the relative sequence and spacing.

---

## Critical Deadlines

| Deadline | Rule |
|----------|------|
| Video | Must be completed **before** pre-defense |
| Deployment | Application must be live and accessible **before** pre-defense |
| Thesis to supervisor | At least **5 working days** before pre-defense |
| Expert submissions | Materials sent **1 week** before the booked slot |
| Review requests | Sent immediately after successful pre-defense |

---

## What Happens If You Miss a Deadline

| Missed Deadline | Consequence |
|-----------------|-------------|
| Topic approval | Automatic expulsion |
| Expert submission | Not admitted to assessment; may lose the slot |
| Pre-defense materials | Not admitted to pre-defense |
| Final defense materials | Not admitted to final defense |
