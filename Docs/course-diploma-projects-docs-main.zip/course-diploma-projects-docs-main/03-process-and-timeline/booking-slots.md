<!-- prev: expert-assessment.md | next: timeline.md -->

!!! abstract "Stage 4 of 7 — Build & Get Assessed | Weeks 7–15"
    :mortar_board: **Students:** How to book assessment slots with experts. Book early.

    :school: **Staff:** Slot availability rules and no-show policies.

    **Prerequisites:** Expert assessment slots have been announced by administration.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Rules for Booking a Discipline Review Slot with an Expert Instructor

Booking a review slot is **entirely your responsibility**.

Instructors provide a fixed number of slots that matches the number of students in the group. Reviewing student work is not the main priority for instructors, who have their primary professional duties.

## Instructors Are Not Required To

- Give up personal time outside working hours (before 9:00 or after 21:00)
- Create extra slots for students who missed the set deadlines
- Adjust their schedule to fit your individual preferences

## Example Situation

For the "Artificial Intelligence" discipline, 17 slots were available for 17 students. Only 5 students signed up before the deadline.

**Result:** 12 slots of 30 minutes each went unused. When trying to find extra time, it turns out that students keep putting off sign-up. Then they try to book time at 8:00–9:00, ignoring the stated working hours.

## Important Warning

There is a separate problem: some students book slots and do not show up without any notice. This is disrespectful to the instructor and blocks time for other students. If you signed up, you must attend or cancel your booking in advance.
