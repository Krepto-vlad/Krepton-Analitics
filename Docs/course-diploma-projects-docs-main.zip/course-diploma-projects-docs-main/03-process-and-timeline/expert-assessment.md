<!-- prev: diploma-lifecycle.md | next: booking-slots.md -->

!!! abstract "Stage 4 of 7 — Build & Get Assessed | Weeks 7–15"
    :mortar_board: **Students:** How expert assessments work — grading, meetings, and appeals.

    :school: **Staff:** Your procedures for running expert assessments.

    **Prerequisites:** Topic approved. Development started. Ready to book assessment slots.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Expert Instructor Responsibilities

## Preparing Requirements and Report Format

- Check the **compliance checklist** and the description of expected results for the discipline.
- Specify the **report format** that you must provide.
- Define the **method for collecting materials** (form, platform, deadlines).

## Assigning Slots

- Set **dates and slots** for defending a part of the project (discipline) after topics are approved and according to the timeline.
- Give you the ability to choose a suitable time from the available slots.

## Pre-check

- A few days before the meeting, check that you have submitted all required materials.
- If you have not submitted the materials, you are not allowed to be assessed.

## Individual Meetings

- The expert holds no more than **two meetings** with you:
  - **Stage defense:**
    - Assess how well you completed the item.
    - Explain the grade verbally.
    - Give recommendations on how to improve the grade before the final defense.
  - **Appeal:**
    - Assign the final grade.
    - Communicate the decision. No further appeal is possible.

## Grading and Pass/Fail

- After the meeting:
  - A **grade on a 10-point scale** is assigned.
  - The item is marked as **passed or not passed**.
  - If the grade is **below 5** or the item is **not passed**:
    - You **are not admitted** to the final diploma defense.

---

## Complexity Evaluation

In addition to individual criterion grades, the pre-defense committee evaluates the **overall project complexity**. This considers:

- **Depth of each component** — a criterion implemented at a basic level contributes less to overall complexity than one implemented with advanced patterns
- **Integration complexity** — how components interact and whether the system demonstrates real distributed/full-stack behavior
- **Novelty** — whether the project goes beyond tutorial-level implementations

A project that passes all individual criteria at minimum level but lacks overall complexity may not be admitted to the final defense. The pre-defense committee makes this determination.

> This applies particularly to non-standard projects (e.g., a framework or library with no frontend) where the depth of a single domain may compensate for missing breadth.
