<!-- prev: ../02-getting-started/topic-changes.md | next: expert-assessment.md -->

!!! abstract "Stage 2 of 7 — Topic Approval | Week 3"
    :mortar_board: **Students:** Understand the full 6-stage lifecycle of your diploma project.

    :school: **Staff:** Reference for the complete process with all decision gates.

    **Prerequisites:** You have chosen your topic and supervisor ([Stage 1](../student-journey.md)).

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Key Stages of the Diploma Project

## Introduction

This section describes the step-by-step diploma project process. You will learn about the roles of the supervisor and experts. You will also learn about the stages and actions needed for a successful defense.

> For specific dates and week numbers, see [Timeline](timeline.md).

---

## Stages and Your Responsibilities

### Choosing a Supervisor and Topic

- You choose your supervisor.
- Together with your supervisor, you define the topic and the list of complexity items ("checkmarks").
- You fill in and sign the application form.

### Topic Approval

- The application is submitted for approval by the administration.
- If the topic is not approved, you face **automatic expulsion**.

### Working with Your Supervisor

- Weekly standup meetings with your supervisor (15 min, at least once a week).
- Reports follow the format: what was done, what is planned, blockers.
- You must pass 4 progress checkpoints (опроцентовки) — stages where your work is reviewed and accepted.
  - **At checkpoint 2 (midpoint)**, the supervisor must explicitly assess whether the project is on track to meet the required complexity level. If there is a risk that the project may not be complex enough for the diploma, the student must be informed **in writing** at this stage — not at pre-defense.
  - If the supervisor identifies a complexity risk, the student must either:
    - Add scope to increase complexity, or
    - Adjust the topic (see [Topic Changes](../02-getting-started/topic-changes.md))
- You must submit all complexity items to experts on time.
- You must prepare an explanatory note for your supervisor to review.

### Working with Expert Instructors

- Each complexity item you chose requires a separate submission to an expert.
- **You are required to:**
    - Pick a date and time slot. Sign up for a meeting with the expert on the assigned days to defend the relevant section of your diploma.
    - Send the section materials to the expert at least one week before the meeting.
    - Attend the meeting with the expert to defend your work and receive your grade.
- You receive verbal feedback at the meeting with the expert.
- You may make changes based on the feedback. You may file an appeal no later than the date when the final grade is posted for that stage.

### BA Defense (Separate Committee Event)

- The Business Analysis criterion is **not** assessed by an individual expert like other criteria.
- It requires a **separate defense before a committee** — this is the first formal gate in the diploma process.
- You must pass the BA defense before proceeding to other expert assessments.
- After passing the BA defense, you may change your project topic (see [Topic Changes](../02-getting-started/topic-changes.md)), but you must re-defend BA for the new topic.

### Pre-defense and Final Defense

- The **pre-defense (предзащита)** is a formal evaluation with a working committee. It carries the same weight as the final defense — treat it accordingly:
  - You must have a **deployed application**, **finished demo video**, and **complete presentation**
  - The committee evaluates your project's complexity, your ability to present, and your technical decisions
  - A poor pre-defense can result in **denial of admission** to the final defense
  - You may receive binding feedback that requires changes before the final defense
- After a successful pre-defense, you receive permission to proceed to the final defense and a referral for review.
- You need to get 2 reviews — one from your supervisor and one from an external expert.
- The final defense takes place with a committee and external experts.

---

## Summary

You must meet all deadlines, work with your supervisor regularly, and pass all components with experts. These are required conditions for admission to the defense. Missing deadlines or failing key items may lead to expulsion or denial of admission to the diploma defense.

Grades and other diploma project results (for example, weekly meeting attendance statistics) will be shared with the working and final committees as reference materials.
