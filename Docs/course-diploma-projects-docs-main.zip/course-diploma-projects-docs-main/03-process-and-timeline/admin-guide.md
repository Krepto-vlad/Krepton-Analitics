<!-- prev: timeline.md | next: ../04-technical-requirements/04a-business-and-docs/business-analysis.md -->

!!! abstract "All Stages — Administrative Reference"
    :school: **Administrators:** Your operational procedures for the entire semester.

    :mortar_board: **Students:** You do not need to read this page. It is for course administrators.

    **Prerequisites:** None — this is a reference document.

    [Staff Guide](../staff-guide.md) | [Full Journey](../student-journey.md)

# Administration Guide — Diploma Project Process

## Purpose

This document describes the administrative actions, responsibilities, and timing for managing the diploma project process.

---

## Key Responsibilities

| Responsibility | When | Action |
|---------------|------|--------|
| Publish semester timeline | Semester start (week 1) | Post exact dates for all milestones in the timeline |
| Topic approval | Week 2-3 | Review and approve/reject student applications |
| Assign expert slots | After topic approval | Coordinate with experts to set assessment slots |
| Monitor progress reviews | Weeks 4-17 | Verify supervisors conduct 4 progress checkpoints |
| Organize pre-defense | Week 19 (per timeline) | Schedule rooms, committees, notify students |
| Provide reviewer contacts | After successful pre-defense | Send reviewer contact to student |
| Confirm review receipt | Before final defense | Verify both reviews (advisor + independent) received |
| Organize final defense | Week 22 (per timeline) | Schedule rooms, committee, external experts |
| Collect final materials | After defense | Confirm repository upload, archive deliverables |

---

## Decision Points

| Decision | Who Decides | Criteria |
|----------|-------------|----------|
| Topic approval | Administration | Meets complexity requirements, no prohibited categories |
| Admission to pre-defense | Supervisor | All criteria submitted to experts, thesis draft reviewed |
| Admission to final defense | Pre-defense committee | Project complexity sufficient, presentation adequate, deployment live |
| Final grade | Defense committee | Cumulative evaluation of all components |

---

## Communication Checklist

- [ ] Timeline published and distributed to all students, supervisors, and experts
- [ ] Expert assessment slots announced with sign-up instructions
- [ ] Pre-defense schedule sent at least 2 weeks in advance
- [ ] Reviewer contacts distributed within 3 working days of successful pre-defense
- [ ] Final defense schedule confirmed at least 2 weeks in advance
