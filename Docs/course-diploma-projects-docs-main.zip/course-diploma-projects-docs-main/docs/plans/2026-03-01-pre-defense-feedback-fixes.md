# Pre-Defense Feedback Fixes — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Implement all 19 findings from `course-feedback.md` across 12 existing files and 2 new files.

**Architecture:** 5 independent workstreams (Tasks 1-5) that can run in parallel, followed by 1 sequential cross-cutting task (Task 6) that updates navigation links and README. Finding #19 is recommendation-only (no file changes needed — addressed by findings #9, #13, #18).

**Tech Stack:** Markdown files only. No build tools, no tests. Verification = visual review of diffs.

---

## Task 1: Presentation Requirements & Criteria Template

**Findings:** #1 (elevator pitch), #2 (purpose section), #6 (criteria justification), #15 (criteria slides → appendix)

**Files:**
- Modify: `05-deliverables/presentation-requirements.md`
- Modify: `05-deliverables/thesis-template/docs/02-technical/criteria/_template.md`

### Step 1: Add Purpose section to presentation-requirements.md

In `05-deliverables/presentation-requirements.md`, insert a new `## Purpose` section between the title (line 3) and `## Format` (line 5).

**Find this text (lines 3-5):**
```markdown
# Diploma Project Presentation Requirements

## Format
```

**Replace with:**
```markdown
# Diploma Project Presentation Requirements

## Purpose

Your presentation is not a report — it is a **sales pitch for your engineering work**. The committee evaluates:

1. **Can you explain your product's value?** (first 30 seconds)
2. **Did you make informed technical decisions?** (not "I picked X because I had to")
3. **Does the project work as a real product?** (live deployment, real data)

Every slide must serve one of these goals. If a slide does not help you convince the committee, it does not belong in your main presentation.

---

## Format
```

### Step 2: Replace Problem section with Elevator Pitch + Problem

In `05-deliverables/presentation-requirements.md`, replace the "### Problem (1–2 slides)" section.

**Find this text (lines 28-35):**
```markdown
### Problem (1–2 slides)

You must answer:
- What problem are you solving?
- Who has this problem? (target audience)
- Why is it important? (consequences of not solving)

**Format:** Use pain points, statistics, or user quotes if available.
```

**Replace with:**
```markdown
### Elevator Pitch + Problem (1–2 slides)

**Slide 1 must open with a 30-second elevator pitch:**
> "What does my application do — explained to a non-technical person? Why would someone want to use or buy it?"

You must answer:
- What problem are you solving? Show the **before** state (how things work without your product)
- Who has this problem? (target audience)
- Why is it important? (consequences of not solving — pain points, time/money lost, statistics)

**Format:** Use a before/after comparison, pain-point statistics, or a real user quote. The committee must understand the product's value within the first 30 seconds.
```

### Step 3: Replace Evaluation Criteria section with summary + appendix structure

In `05-deliverables/presentation-requirements.md`, replace the entire "### Evaluation Criteria (7 slides)" section (lines 72-101).

**Find this text:**
```markdown
### Evaluation Criteria (7 slides)

You will prepare **one slide per criterion.** Each slide must include:

| Element | Description |
|---------|-------------|
| **Criterion name** | Clear title |
| **Why this approach** | 1–2 sentences on decision rationale |
| **What was implemented** | Key features/components (3–5 bullet points) |
| **Technologies used** | Specific tools, libraries, frameworks |
| **Diagram/Schema** | Visual representation (architecture, flow, schema, screenshot) |

**Example slide content:**
```
Criterion: Database (OLTP)

WHY: Needed relational DB for transactional data with complex relations

WHAT:
• PostgreSQL with 12 tables, 3NF normalized
• Migrations via Flyway
• Role-based access (app_read, app_write, admin)
• Indexes on frequently queried columns

TECH: PostgreSQL 15, Flyway, pgAdmin

[ER Diagram]
```

**Visual required:** Each criterion slide must have at least one diagram, schema, screenshot, or code snippet.
```

**Replace with:**
```markdown
### Evaluation Criteria — Summary (2–3 slides)

Present your **top 3–4 strongest criteria** in the main presentation. For each:

| Element | Description |
|---------|-------------|
| **Criterion name** | Clear title |
| **Business justification** | Why does your product **need** this? Link to a business requirement, user need, or architectural constraint — not "I had to choose 7 criteria" |
| **Key implementation highlight** | The most interesting technical decision (1–2 bullet points) |
| **Visual** | Diagram, screenshot, or code snippet |

> Focus on criteria where you did the most interesting or complex work. Do not give equal time to all 7.

> **Common mistake:** Do not say "I chose this criterion because I needed 7 checkmarks." Instead, explain which business requirement or user problem demanded this technology. For example: "My application handles financial transactions from multiple regions, so I needed a database with ACID compliance and partitioning — this drove the Database criterion."

**Example slide content:**
```
Criterion: Database (OLTP)

BUSINESS NEED: The platform processes 500+ orders/day with complex inventory
relations — data integrity failures cost the business real money.

WHAT:
• PostgreSQL with 12 tables, 3NF normalized
• Migrations via Flyway
• Role-based access (app_read, app_write, admin)
• Indexes on frequently queried columns

TECH: PostgreSQL 15, Flyway, pgAdmin

[ER Diagram]
```

**Visual required:** Each criterion slide in the main presentation must have at least one diagram, schema, screenshot, or code snippet.

---

### Criteria Appendix (optional, 7 slides at the end)

If required by the administration, prepare one slide per criterion in the appendix section of your presentation. These slides follow the full format (criterion name, business justification, implementation details, technologies, diagram) but are **not part of your spoken presentation** — they serve as reference material for the committee.
```

### Step 4: Update Slide Count Summary table

In `05-deliverables/presentation-requirements.md`, replace the Slide Count Summary table.

**Find this text:**
```markdown
## Slide Count Summary

| Section | Slides |
|---------|--------|
| Title | 1 |
| Problem | 1–2 |
| Solution | 1–2 |
| Demo | 2–3 |
| Architecture | 1–2 |
| **Criteria (7×1)** | **7** |
| Challenges | 1 |
| Results | 1 |
| Q&A | 1 |
| **Total** | **18–24** |
```

**Replace with:**
```markdown
## Slide Count Summary

| Section | Slides |
|---------|--------|
| Title | 1 |
| Elevator Pitch + Problem | 1–2 |
| Solution | 1–2 |
| Demo | 2–3 |
| Architecture | 1–2 |
| **Criteria (summary)** | **2–3** |
| Challenges | 1 |
| Results | 1 |
| Q&A | 1 |
| **Subtotal (spoken)** | **12–18** |
| Criteria Appendix (optional) | 7 |
| **Total** | **12–25** |
```

### Step 5: Update criteria template Context prompt

In `05-deliverables/thesis-template/docs/02-technical/criteria/_template.md`, update the Context placeholder text.

**Find this text (line 15):**
```markdown
[Describe the problem or requirement this criterion addresses. What forces are at play? What constraints exist?]
```

**Replace with:**
```markdown
[Describe the business requirement or user problem that made this criterion necessary for your project. Do not write "I chose this because I needed N checkmarks." Explain what product need or architectural constraint drove this decision. What forces are at play? What constraints exist?]
```

### Step 6: Verify changes

Run: `git diff 05-deliverables/presentation-requirements.md 05-deliverables/thesis-template/docs/02-technical/criteria/_template.md`

Expected: All 4 edits visible — Purpose section added, Problem→Elevator Pitch, Criteria restructured, template Context updated.

### Step 7: Commit

```bash
git add 05-deliverables/presentation-requirements.md 05-deliverables/thesis-template/docs/02-technical/criteria/_template.md
git commit -m "$(cat <<'EOF'
docs: restructure presentation requirements — elevator pitch, purpose, criteria appendix

Findings #1, #2, #6, #15 from pre-defense feedback:
- Add Purpose section explaining presentation goals
- Replace Problem section with Elevator Pitch + Problem
- Restructure criteria from 7 mandatory slides to 2-3 summary + optional appendix
- Add business justification guidance and anti-pattern warnings
- Update criteria template Context prompt to require business rationale

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Defense Preparation & Checklist

**Findings:** #5 (research metrics), #7 (presentation strategy), #8 (deploy blocker + deploy section in defense-prep), #9 (video deadline + checklist note)

**Files:**
- Modify: `06-defense-and-completion/defense-preparation.md`
- Modify: `06-defense-and-completion/final-deliverables-checklist.md`
- Modify: `05-deliverables/video-requirements.md`

### Step 1: Rewrite Research Projects section in defense-preparation.md

**Find this text (lines 15-16):**
```markdown
## Research Projects
Show your metrics and results.
```

**Replace with:**
```markdown
## Research Projects

If your project is research-oriented (ML model, algorithm comparison, data analysis), you must present:

- **Hypothesis or research question** — what you set out to prove or investigate
- **Methodology** — how you structured the experiment (dataset, parameters, conditions)
- **Baseline** — what the starting point or comparison benchmark was
- **Results with metrics** — quantitative outcomes (accuracy, precision, F1, latency, throughput, etc.)
- **Success/failure criteria** — define in advance what constitutes a successful outcome vs. a failed one
- **Interpretation** — what the results mean and whether they support the hypothesis

A negative result (hypothesis disproven) is acceptable **if** the methodology was sound and the analysis is thorough. Do not hide negative results — present them honestly and explain what you learned.
```

### Step 2: Add Presentation Strategy section to defense-preparation.md

Append the following **after** the "## Thesis Document" section (end of file):

```markdown

---

## Presentation Strategy

### Focus on Strengths

Lead with what you did well. The committee forms their impression in the first 2-3 minutes. If you open with apologies ("I didn't have time for...", "this part is incomplete..."), you set a negative frame that colors everything after it.

**Do:**
- Open with your elevator pitch and strongest feature
- Show your best technical decisions with confidence
- Present challenges as "Problem → Solution" stories
- Acknowledge limitations briefly in the Results slide — don't dwell

**Don't:**
- Apologize for criteria you scored lower on
- Say "I know this isn't great, but..."
- Spend more time on what's missing than on what's done
- Read your slides word for word

### Time Allocation

Spend 70% of your time on your strongest 3-4 criteria and the product demo. Spend 30% on the remaining criteria. The committee will ask about weak areas in Q&A — that is the appropriate place to discuss limitations.
```

### Step 3: Add Deployment section to defense-preparation.md

Insert **before** the "## Speech" section:

```markdown
## Deployment

Your application **must** be deployed and accessible via a public URL before the pre-defense. This is a hard requirement, not optional. If your application is not deployed, you will not be admitted to the defense.

- Verify the URL works from a different network (not your local machine)
- Ensure the deployment will remain live through the final defense date
- Have a backup plan (local demo) in case of cloud outage — but this does not replace the deployment requirement

---
```

### Step 4: Rewrite final-deliverables-checklist.md

Replace the deliverables table in `06-defense-and-completion/final-deliverables-checklist.md`.

**Find this text (lines 5-14):**
```markdown
You must have the following materials ready before the defense:

| # | Document | Description |
|---|----------|-------------|
| 1 | **Thesis document (пояснительная записка)** | A PDF file with the full text of your diploma project, formatted according to the requirements |
| 2 | **Abstract** | A short summary of your work (usually 1 page) in English |
| 3 | **Presentation** | Slides for the defense (PowerPoint, Google Slides, or PDF) |
| 4 | **Demo video** | A video that shows how your application works (30 seconds – 2 minutes) |
| 5 | **Advisor report** | Evaluation and comments from your academic advisor |
| 6 | **Review** | Evaluation and comments from an independent reviewer |
```

**Replace with:**
```markdown
You must have the following materials ready before the defense:

| # | Document | Description |
|---|----------|-------------|
| 1 | **Thesis document (пояснительная записка)** | A PDF file with the full text of your diploma project, formatted according to the requirements |
| 2 | **Abstract** | A short summary of your work (usually 1 page) in English |
| 3 | **Presentation** | Slides for the defense (PowerPoint, Google Slides, or PDF) |
| 4 | **Demo video** | A video that shows how your application works (30 seconds – 2 minutes) |
| 5 | **Advisor report** | Evaluation and comments from your academic advisor |
| 6 | **Review** | Evaluation and comments from an independent reviewer |
| 7 | **Live deployment** | Application accessible via a public URL. Must be running at the time of defense. **No deployment = not admitted to defense.** |

---

## Blockers

The following items are **hard blockers** — without them, you will not be admitted to the defense:

| Blocker | Why |
|---------|-----|
| No live deployment | The committee must be able to open and use your application during the defense |
| No demo video | Required for portfolio and institutional records |
| No thesis document | The reviewer cannot write a review without it |
```

### Step 5: Update "Important" section in final-deliverables-checklist.md

**Find this text (lines 18-20):**
```markdown
## Important

All documents must be ready **before the defense date**. They must follow the requirements described in the corresponding sections of the documentation.
```

**Replace with:**
```markdown
## Important

All documents must be ready **before the defense date**. They must follow the requirements described in the corresponding sections of the documentation.

> **Note:** The demo video and live deployment must be ready **before the pre-defense**, not just the final defense. The pre-defense committee evaluates these items.
```

### Step 6: Add Deadline section to video-requirements.md

In `05-deliverables/video-requirements.md`, insert a new `## Deadline` section **before** `## Submission` (line 109).

**Find this text:**
```markdown
## Submission

### File Delivery
```

**Insert before it:**
```markdown
## Deadline

> Your demo video must be completed and accessible **before the pre-defense**, not before the final defense.

The pre-defense committee uses the video as part of their evaluation. If you do not have a finished video at the time of pre-defense, you may not be admitted.

Plan to finish recording and editing your video **at least 1 week before the pre-defense** to allow time for review and re-recording if needed.

---

## Submission

### File Delivery
```

### Step 7: Verify changes

Run: `git diff 06-defense-and-completion/defense-preparation.md 06-defense-and-completion/final-deliverables-checklist.md 05-deliverables/video-requirements.md`

Expected: Research metrics expanded, strategy section added, deployment section added, checklist has item 7 + Blockers table, Important note updated, video has Deadline section.

### Step 8: Commit

```bash
git add 06-defense-and-completion/defense-preparation.md 06-defense-and-completion/final-deliverables-checklist.md 05-deliverables/video-requirements.md
git commit -m "$(cat <<'EOF'
docs: add defense blockers, video deadline, research metrics, presentation strategy

Findings #5, #7, #8, #9 from pre-defense feedback:
- Expand research project metrics guidance with hypothesis/baseline/interpretation
- Add presentation strategy section (focus on strengths, time allocation)
- Add deployment as hard blocker in deliverables checklist
- Add Blockers table and pre-defense note to checklist
- Add Deadline section to video requirements (before pre-defense)
- Add deployment check section to defense preparation tips

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Process, Lifecycle & Supervisor

**Findings:** #3 (supervisor versioning), #12 (complexity evaluation), #13 (early complexity warning), #14 (pre-defense seriousness)

**Files:**
- Modify: `02-getting-started/supervisor-role.md`
- Modify: `03-process-and-timeline/diploma-lifecycle.md`
- Modify: `03-process-and-timeline/expert-assessment.md`

### Step 1: Expand supervisor review section

In `02-getting-started/supervisor-role.md`, replace the "Review the Explanatory Note" section.

**Find this text (lines 36-38):**
```markdown
### Review the Explanatory Note

- **Mandatory proofreading** of the explanatory note in English.
  - Check the structure, terminology, language, and logical flow.
```

**Replace with:**
```markdown
### Review the Explanatory Note

- **Mandatory proofreading** of the explanatory note in English.
  - Check the structure, terminology, language, and logical flow.
- The student must send the **final version** of the explanatory note to the supervisor **at least 5 working days** before the pre-defense.
- The supervisor reviews and signs off on the submitted version. If the student makes changes after sign-off, a new review cycle is required.
- **Versioning:** The supervisor should confirm which version (by date or commit hash) was reviewed.
```

### Step 2: Add complexity check to progress checkpoints in diploma-lifecycle.md

In `03-process-and-timeline/diploma-lifecycle.md`, expand the progress checkpoint bullet.

**Find this text (line 28):**
```markdown
- You must pass 4 progress checkpoints (опроцентовки) — stages where your work is reviewed and accepted.
```

**Replace with:**
```markdown
- You must pass 4 progress checkpoints (опроцентовки) — stages where your work is reviewed and accepted.
  - **At checkpoint 2 (midpoint)**, the supervisor must explicitly assess whether the project is on track to meet the required complexity level. If there is a risk that the project may not be complex enough for the diploma, the student must be informed **in writing** at this stage — not at pre-defense.
  - If the supervisor identifies a complexity risk, the student must either:
    - Add scope to increase complexity, or
    - Adjust the topic (see [Topic Changes](../02-getting-started/topic-changes.md))
```

### Step 3: Rewrite pre-defense section in diploma-lifecycle.md

**Find this text (lines 42-46):**
```markdown
### Pre-defense and Final Defense

- The pre-defense (предзащита) takes place with a working committee. After the pre-defense, you receive permission to proceed to the final defense and a referral for review.
- The review becomes available to you after a successful pre-defense. You need to get 2 reviews — one from your supervisor and one from an external expert.
- The final defense takes place with a committee and external experts.
```

**Replace with:**
```markdown
### Pre-defense and Final Defense

- The **pre-defense (предзащита)** is a formal evaluation with a working committee. It carries the same weight as the final defense — treat it accordingly:
  - You must have a **deployed application**, **finished demo video**, and **complete presentation**
  - The committee evaluates your project's complexity, your ability to present, and your technical decisions
  - A poor pre-defense can result in **denial of admission** to the final defense
  - You may receive binding feedback that requires changes before the final defense
- After a successful pre-defense, you receive permission to proceed to the final defense and a referral for review.
- You need to get 2 reviews — one from your supervisor and one from an external expert.
- The final defense takes place with a committee and external experts.
```

### Step 4: Add timeline cross-reference to diploma-lifecycle.md

Append after the "## Introduction" paragraph (after line 7):

**Find this text:**
```markdown
## Introduction

This section describes the step-by-step diploma project process. You will learn about the roles of the supervisor and experts. You will also learn about the stages and actions needed for a successful defense.
```

**Replace with:**
```markdown
## Introduction

This section describes the step-by-step diploma project process. You will learn about the roles of the supervisor and experts. You will also learn about the stages and actions needed for a successful defense.

> For specific dates and week numbers, see [Timeline](timeline.md).
```

### Step 5: Add Complexity Evaluation section to expert-assessment.md

Append the following to the end of `03-process-and-timeline/expert-assessment.md`:

```markdown

---

## Complexity Evaluation

In addition to individual criterion grades, the pre-defense committee evaluates the **overall project complexity**. This considers:

- **Depth of each component** — a criterion implemented at a basic level contributes less to overall complexity than one implemented with advanced patterns
- **Integration complexity** — how components interact and whether the system demonstrates real distributed/full-stack behavior
- **Novelty** — whether the project goes beyond tutorial-level implementations

A project that passes all individual criteria at minimum level but lacks overall complexity may not be admitted to the final defense. The pre-defense committee makes this determination.

> This applies particularly to non-standard projects (e.g., a framework or library with no frontend) where the depth of a single domain may compensate for missing breadth.
```

### Step 6: Verify changes

Run: `git diff 02-getting-started/supervisor-role.md 03-process-and-timeline/diploma-lifecycle.md 03-process-and-timeline/expert-assessment.md`

Expected: Supervisor versioning added, checkpoint 2 complexity check added, pre-defense section strengthened, timeline cross-ref added, complexity evaluation section added.

### Step 7: Commit

```bash
git add 02-getting-started/supervisor-role.md 03-process-and-timeline/diploma-lifecycle.md 03-process-and-timeline/expert-assessment.md
git commit -m "$(cat <<'EOF'
docs: strengthen process — supervisor versioning, complexity checks, pre-defense weight

Findings #3, #12, #13, #14 from pre-defense feedback:
- Require supervisor to review final version with 5-day deadline and version tracking
- Add mandatory complexity assessment at checkpoint 2 (midpoint)
- Add overall complexity evaluation section to expert assessment
- Strengthen pre-defense language to convey same weight as final defense
- Add timeline cross-reference to diploma lifecycle

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: New Files — Timeline and Admin Guide

**Findings:** #4 (timeline), #17 (admin guide)

**Files:**
- Create: `03-process-and-timeline/timeline.md`
- Create: `03-process-and-timeline/admin-guide.md`

### Step 1: Create timeline.md

Create the file `03-process-and-timeline/timeline.md` with the following content:

```markdown
<!-- prev: booking-slots.md | next: admin-guide.md -->

# Diploma Project Timeline

## Overview

This timeline defines the key milestones and deadlines for the diploma project. All dates are approximate and will be confirmed by the administration at the start of each semester.

---

## Week-by-Week Schedule

| Week | Milestone | Deliverable | Responsible |
|------|-----------|-------------|-------------|
| 1-2 | Topic selection and supervisor assignment | Signed application form | Student + Supervisor |
| 3 | Topic approval by administration | Approved application | Administration |
| 4-6 | Progress Review 1 (опроцентовка 1) | Initial prototype / architecture | Student → Supervisor |
| 7-9 | Expert submissions begin | Materials sent to experts 1 week before slot | Student → Expert |
| 10-12 | Progress Review 2 (опроцентовка 2) — **includes complexity check** | Working MVP with core features | Student → Supervisor |
| 13-15 | Progress Review 3 (опроцентовка 3) | Feature-complete build | Student → Supervisor |
| 16-17 | **Video deadline** | Demo video (.mp4) finalized | Student |
| 17-18 | Progress Review 4 (опроцентовка 4) | Final version, thesis draft complete | Student → Supervisor |
| 18 | **Thesis submitted to supervisor** | Final explanatory note (5 working days before pre-defense) | Student → Supervisor |
| 19 | **Pre-defense** | Presentation + deployed application + video | Student → Committee |
| 20 | Reviews obtained | Supervisor review + independent review | Student |
| 21 | Repository upload | Upload to talpykla.elaba.lt | Student |
| 22 | **Final defense** | All deliverables complete | Student → Committee |

> **Note:** The administration will publish exact dates at the beginning of each semester. This table shows the relative sequence and spacing.

---

## Critical Deadlines

| Deadline | Rule |
|----------|------|
| Video | Must be completed **before** pre-defense |
| Deployment | Application must be live and accessible **before** pre-defense |
| Thesis to supervisor | At least **5 working days** before pre-defense |
| Expert submissions | Materials sent **1 week** before the booked slot |
| Review requests | Sent immediately after successful pre-defense |

---

## What Happens If You Miss a Deadline

| Missed Deadline | Consequence |
|-----------------|-------------|
| Topic approval | Automatic expulsion |
| Expert submission | Not admitted to assessment; may lose the slot |
| Pre-defense materials | Not admitted to pre-defense |
| Final defense materials | Not admitted to final defense |
```

### Step 2: Create admin-guide.md

Create the file `03-process-and-timeline/admin-guide.md` with the following content:

```markdown
<!-- prev: timeline.md | next: ../04-technical-requirements/04a-business-and-docs/business-analysis.md -->

# Administration Guide — Diploma Project Process

## Purpose

This document describes the administrative actions, responsibilities, and timing for managing the diploma project process.

---

## Key Responsibilities

| Responsibility | When | Action |
|---------------|------|--------|
| Publish semester timeline | Semester start (week 1) | Post exact dates for all milestones in the timeline |
| Topic approval | Week 2-3 | Review and approve/reject student applications |
| Assign expert slots | After topic approval | Coordinate with experts to set assessment slots |
| Monitor progress reviews | Weeks 4-17 | Verify supervisors conduct 4 progress checkpoints |
| Organize pre-defense | Week 19 (per timeline) | Schedule rooms, committees, notify students |
| Provide reviewer contacts | After successful pre-defense | Send reviewer contact to student |
| Confirm review receipt | Before final defense | Verify both reviews (advisor + independent) received |
| Organize final defense | Week 22 (per timeline) | Schedule rooms, committee, external experts |
| Collect final materials | After defense | Confirm repository upload, archive deliverables |

---

## Decision Points

| Decision | Who Decides | Criteria |
|----------|-------------|----------|
| Topic approval | Administration | Meets complexity requirements, no prohibited categories |
| Admission to pre-defense | Supervisor | All criteria submitted to experts, thesis draft reviewed |
| Admission to final defense | Pre-defense committee | Project complexity sufficient, presentation adequate, deployment live |
| Final grade | Defense committee | Cumulative evaluation of all components |

---

## Communication Checklist

- [ ] Timeline published and distributed to all students, supervisors, and experts
- [ ] Expert assessment slots announced with sign-up instructions
- [ ] Pre-defense schedule sent at least 2 weeks in advance
- [ ] Reviewer contacts distributed within 3 working days of successful pre-defense
- [ ] Final defense schedule confirmed at least 2 weeks in advance
```

### Step 3: Verify new files exist

Run: `ls -la 03-process-and-timeline/timeline.md 03-process-and-timeline/admin-guide.md`

Expected: Both files exist with appropriate sizes.

### Step 4: Commit

```bash
git add 03-process-and-timeline/timeline.md 03-process-and-timeline/admin-guide.md
git commit -m "$(cat <<'EOF'
docs: add timeline and admin guide — two new process documents

Findings #4, #17 from pre-defense feedback:
- Create timeline.md with week-by-week milestone schedule and critical deadlines
- Create admin-guide.md with administration responsibilities, decision points, and communication checklist

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Requirements & Templates

**Findings:** #10 (rate limiting), #11 (criteria = help), #16 (before/after), #18 (BA mandatory)

**Files:**
- Modify: `04-technical-requirements/04e-infrastructure/microservices.md`
- Modify: `01-overview/project-types-and-criteria.md`
- Modify: `05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md`
- Modify: `04-technical-requirements/04a-business-and-docs/business-analysis.md`

### Step 1: Add rate limiting to microservices minimum requirements

In `04-technical-requirements/04e-infrastructure/microservices.md`, add rate limiting to the Communication section.

**Find this text (lines 33-36):**
```markdown
**Communication:**
- Synchronous: REST API or gRPC between services
- Clear interaction contracts (versioned APIs)
- Timeouts and retry policies for all calls
- Handling of unavailable dependent services
```

**Replace with:**
```markdown
**Communication:**
- Synchronous: REST API or gRPC between services
- Clear interaction contracts (versioned APIs)
- Timeouts and retry policies for all calls
- Handling of unavailable dependent services
- **Rate limiting** on API Gateway or service entry points (basic request throttling to prevent cascade failures)
```

### Step 2: Add rate limiting to API Gateway section

In the same file, update the API Gateway section.

**Find this text (lines 47-50):**
```markdown
**API Gateway or entry point:**
- Single entry point for external clients
- Request routing to services
- Basic authentication/authorization
```

**Replace with:**
```markdown
**API Gateway or entry point:**
- Single entry point for external clients
- Request routing to services
- Basic authentication/authorization
- Rate limiting (requests per second/minute per client)
```

### Step 3: Add "necessary but not sufficient" framing to project-types-and-criteria.md

In `01-overview/project-types-and-criteria.md`, add framing before the checkmarks table.

**Find this text (lines 40-41):**
```markdown
## How a "Complete Diploma" Is Calculated

| Level | Min. total checkmarks | Restrictions |
```

**Replace with:**
```markdown
## How a "Complete Diploma" Is Calculated

The complexity criteria exist to help you verify that your project is sufficiently complex for a diploma. Think of them as a **minimum threshold**, not a guarantee:

- **If your project does not meet the criteria** → it will not be admitted to the defense (with rare exceptions).
- **If your project meets the criteria** → it satisfies the minimum complexity requirement, but admission also depends on implementation quality, defense performance, and expert evaluations.

> Meeting all checkmarks is necessary but not sufficient for a successful defense.

| Level | Min. total checkmarks | Restrictions |
```

### Step 4: Add depth vs. breadth note after checkmarks table

In the same file, add a note after the Team row of the table (after line 46).

**Find this text:**
```markdown
| **Team** | 10 | When working in a team, each student must choose their own 5 checkmarks |

---
```

**Replace with:**
```markdown
| **Team** | 10 | When working in a team, each student must choose their own 5 checkmarks |

> **Important:** Checkmarks measure breadth (how many areas you cover). The pre-defense committee also evaluates **depth** (how complex each component is). A project with 7 checkmarks at surface level may still be deemed insufficient. Conversely, a highly specialized project (e.g., a Rust framework) with fewer UI components but deep backend complexity may be accepted — discuss with your supervisor early.

---
```

### Step 5: Add Business Analysis to the complexity criteria table as mandatory

In the same file, add BA to the criteria table.

**Find this text (line 20):**
```markdown
| **Back-end** (required) |  |
```

**Insert before it:**
```markdown
| **Business Analysis** (required) | vision, problem, stakeholders, scope, features — **defended before committee** |
```

### Step 6: Add Before/After section to thesis template problem-and-goals.md

In `05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md`, add a Before/After section after the Pain Points table.

**Find this text (lines 17-21):**
```markdown
| # | Pain Point | Severity | Current Workaround |
|---|------------|----------|-------------------|
| 1 | [What frustrates users] | High/Medium/Low | [How they cope now] |
| 2 | [What inefficiencies exist] | High/Medium/Low | [How they cope now] |
| 3 | [What needs are unmet] | High/Medium/Low | [How they cope now] |
```

**Append after this table:**
```markdown

### Before / After

Show the concrete difference your product makes:

| Aspect | Before (without your product) | After (with your product) |
|--------|-------------------------------|---------------------------|
| [Key workflow or metric] | [Current state — slow, manual, error-prone] | [Improved state — fast, automated, reliable] |
| [Key workflow or metric] | [Current state] | [Improved state] |
| [Key workflow or metric] | [Current state] | [Improved state] |

> This table should make the product's value obvious at a glance. Use specific numbers where possible (e.g., "30 min manual process → 2 min automated").
```

### Step 7: Add mandatory + committee defense note to business-analysis.md

In `04-technical-requirements/04a-business-and-docs/business-analysis.md`, add the mandatory status block.

**Find this text (lines 3-5):**
```markdown
# Business Analysis Requirements for Passing the BA Stage of Diploma Preparation

You will use this document to understand what is expected of you to pass the BA stage of diploma preparation.
```

**Replace with:**
```markdown
# Business Analysis Requirements for Passing the BA Stage of Diploma Preparation

> **Status: Mandatory criterion.** Unlike other criteria, Business Analysis must be completed and defended before a committee — not just with an individual expert. This is a prerequisite for continuing with the diploma project.

> **Topic change policy:** After successfully defending the BA criterion, you may change your project topic. If you change your topic, you must re-defend the BA criterion for the new topic.

You will use this document to understand what is expected of you to pass the BA stage of diploma preparation.
```

### Step 8: Verify changes

Run: `git diff 04-technical-requirements/04e-infrastructure/microservices.md 01-overview/project-types-and-criteria.md 05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md 04-technical-requirements/04a-business-and-docs/business-analysis.md`

Expected: Rate limiting added to minimum reqs, checkmark framing added, depth note added, BA in criteria table, before/after in template, BA mandatory note.

### Step 9: Commit

```bash
git add 04-technical-requirements/04e-infrastructure/microservices.md 01-overview/project-types-and-criteria.md 05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md 04-technical-requirements/04a-business-and-docs/business-analysis.md
git commit -m "$(cat <<'EOF'
docs: update requirements — rate limiting, BA mandatory, complexity framing, before/after

Findings #10, #11, #16, #18 from pre-defense feedback:
- Add rate limiting to microservices minimum requirements (Communication + API Gateway)
- Add "necessary but not sufficient" framing to complexity criteria
- Add depth vs. breadth note after checkmarks table
- Add Business Analysis as mandatory criterion (defended before committee)
- Add Before/After section to thesis template problem-and-goals.md
- Add mandatory status and topic change policy to business-analysis.md

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Cross-Cutting — Navigation Links & README

**Depends on:** Tasks 1-5 (must run after all others complete)

**Files:**
- Modify: `03-process-and-timeline/booking-slots.md` (update next link)
- Modify: `README.md` (add new files to Section 3 table)
- Modify: `01-overview/course-overview.md` (add new docs to Organization table)

### Step 1: Update booking-slots.md navigation

In `03-process-and-timeline/booking-slots.md`, update the next pointer.

**Find this text (line 1):**
```markdown
<!-- prev: expert-assessment.md | next: ../04-technical-requirements/04a-business-and-docs/business-analysis.md -->
```

**Replace with:**
```markdown
<!-- prev: expert-assessment.md | next: timeline.md -->
```

### Step 2: Update README.md Section 3 table

In `README.md`, add timeline and admin guide to the Section 3 table.

**Find this text:**
```markdown
| 8 | [Booking Slots](03-process-and-timeline/booking-slots.md) | 1 min | Section 2 |

---
```

**Replace with:**
```markdown
| 8 | [Booking Slots](03-process-and-timeline/booking-slots.md) | 1 min | Section 2 |
| 9 | [Timeline](03-process-and-timeline/timeline.md) | 2 min | Section 2 |
| 10 | [Administration Guide](03-process-and-timeline/admin-guide.md) | 2 min | Section 2 |

---
```

### Step 3: Update README.md total reading time

In `README.md`, update the Section 3 row in the summary table.

**Find this text:**
```markdown
| 3. Process and Timeline | 3 | 4 min |
```

**Replace with:**
```markdown
| 3. Process and Timeline | 5 | 8 min |
```

### Step 4: Update the total row in README.md

**Find this text:**
```markdown
| **Total** | **34 + template** | **~106 min** |
```

**Replace with:**
```markdown
| **Total** | **36 + template** | **~110 min** |
```

### Step 5: Update course-overview.md Organization table

In `01-overview/course-overview.md`, add the new entries to the Organization table.

**Find this text:**
```markdown
| 7 | Topic change deadlines |
| 8 | Defense registration requirements |
```

**Replace with:**
```markdown
| 7 | Topic change deadlines |
| 8 | Diploma project timeline |
| 9 | Administration guide |
| 10 | Defense registration requirements |
```

Also renumber the subsequent rows (original 8→10, 9→11, 10→12, 11→13, 12→14).

### Step 6: Update business-analysis.md navigation link (since admin-guide now points to it)

In `04-technical-requirements/04a-business-and-docs/business-analysis.md`, update the prev pointer.

**Find this text (line 1):**
```markdown
<!-- prev: ../03-process-and-timeline/booking-slots.md | next: api-documentation.md -->
```

**Replace with:**
```markdown
<!-- prev: ../03-process-and-timeline/admin-guide.md | next: api-documentation.md -->
```

### Step 7: Verify navigation chain

Run these commands to check the chain is consistent:
```bash
head -1 03-process-and-timeline/booking-slots.md
head -1 03-process-and-timeline/timeline.md
head -1 03-process-and-timeline/admin-guide.md
head -1 04-technical-requirements/04a-business-and-docs/business-analysis.md
```

Expected chain: booking-slots → timeline → admin-guide → business-analysis

### Step 8: Commit

```bash
git add 03-process-and-timeline/booking-slots.md README.md 01-overview/course-overview.md 04-technical-requirements/04a-business-and-docs/business-analysis.md
git commit -m "$(cat <<'EOF'
docs: update navigation links and README for new timeline and admin guide

Cross-cutting updates after all findings implemented:
- Update booking-slots.md next link to point to timeline.md
- Update business-analysis.md prev link to point to admin-guide.md
- Add timeline and admin guide to README.md Section 3 table
- Update reading time totals in README.md
- Add new documents to course-overview.md Organization table

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
EOF
)"
```

---

## Execution Summary

| Task | Agent | Findings | Files Modified | Files Created | Can Parallel |
|------|-------|----------|----------------|---------------|-------------|
| 1 | A | #1, #2, #6, #15 | 2 | 0 | Yes |
| 2 | B | #5, #7, #8, #9 | 3 | 0 | Yes |
| 3 | C | #3, #12, #13, #14 | 3 | 0 | Yes |
| 4 | D | #4, #17 | 0 | 2 | Yes |
| 5 | E | #10, #11, #16, #18 | 4 | 0 | Yes |
| 6 | — | Cross-cutting | 4 | 0 | After 1-5 |

**Finding #19** (pre-pre-defense) requires no code changes — it is a recommendation that findings #9, #13, and #18 collectively address. Document in the commit log only.

**Total: 14 files modified/created, 6 commits, 5 parallel + 1 sequential.**
