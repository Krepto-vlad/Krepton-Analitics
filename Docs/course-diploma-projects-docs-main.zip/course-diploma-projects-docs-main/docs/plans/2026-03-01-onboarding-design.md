# Onboarding Experience Design

**Date:** 2026-03-01
**Status:** Approved

## Problem

Students land in the documentation and get lost. 34 chapters across 7 tabs with no "you are here" feeling. Teachers and administrators have responsibilities scattered across multiple pages with no consolidated view. Two pages (`timeline.md`, `admin-guide.md`) exist but are hidden from navigation.

## Design Decisions

### Approach: Role-Based Landing Pages + Stage Badges

Two new pages as onboarding entry points, plus stage badges on all existing pages.

**Why this approach:**

- Clear entry points per role (students vs. staff)
- "You are here" on every page via stage badges
- Full journey visible at a glance
- Staff guide with tabs cleanly separates supervisor vs. admin duties
- Hidden pages added to navigation

### Audiences

1. **Students** — navigate the 7-stage journey from topic selection to final defense
2. **Supervisors / Experts** — mentor students, run assessments, write reviews
3. **Administrators** — manage process, approve topics, organize defenses

Supervisors and administrators share one page with content tabs.

## New Pages

### 1. `student-journey.md` (root level)

**Purpose:** Single-page journey map showing all 7 stages with checklists.

**Structure:**

- Journey overview table (7 stages, week ranges, actions, page links)
- Collapsible stage details (`??? success`) with:
  - Action checklist (task list format)
  - All 17 criteria grouped by category (in Stage 1)
  - Links to relevant pages
  - "What happens next" pointer
- All 17 technical criteria shown grouped: Required (3), Business & Docs (1), Data Layer (2), Frontend & UX (2), Infrastructure (4), Testing (2), Specialized (3)

**7 Stages:**

| Stage | When | Summary |
|-------|------|---------|
| 1. Choose Your Topic | Weeks 1-2 | Select type, pick 7+ criteria, find supervisor |
| 2. Get Approved | Week 3 | Submit application, admin approval |
| 3. Plan & Start Building | Weeks 4-6 | Set up repo, prototype, Progress Review 1 |
| 4. Build & Get Assessed | Weeks 7-15 | Expert assessments, progress reviews, complexity check |
| 5. Prepare Deliverables | Weeks 16-18 | Video, presentation, thesis, deploy |
| 6. Pre-Defense | Week 19 | Present to committee, get reviewer contact |
| 7. Final Defense | Weeks 20-22 | Reviews, repository upload, defend |

**MkDocs elements:** Tables, `??? success` collapsible blocks, task lists, links.

### 2. `staff-guide.md` (root level)

**Purpose:** Consolidated reference for supervisors, experts, and administrators.

**Structure:**

- Content tabs: `=== "Supervisor / Expert"` and `=== "Administrator"`
- Each tab has:
  - Responsibility matrix (stage, when, action, page link)
  - Key obligation callout (admonition)
  - Quick reference collapsible sections
- Administrator tab includes communication checklist and decision authority table

**MkDocs elements:** Content tabs (`===`), tables, admonitions (`!!! warning`, `!!! info`), collapsible blocks, task lists.

## Stage Badges on Existing Pages

Every content page gets an admonition inserted at the top (after any `<!-- prev/next -->` comment).

**Format:**

```markdown
!!! abstract "Stage X of 7 — Stage Name | Weeks N–M"
    :mortar_board: **Students:** [role-specific guidance]
    :school: **Staff:** [role-specific guidance]

    **Prerequisites:** [what must be done first]

    [← Previous: ...](link) | [Next: ... →](link) | [Full Journey](../student-journey.md)
```

**Stage mapping:**

- Stage 1 (Wk 1-2): course-overview, project-types-and-criteria, team-rules, supervisor-role, topic-changes
- Stage 2 (Wk 3): diploma-lifecycle
- Stage 3 (Wk 4-18): All 17 technical requirement pages, thesis-guide
- Stage 4 (Wk 7-18): expert-assessment, booking-slots, timeline
- Stage 5 (Wk 16-18): video-requirements, presentation-requirements, official-requirements
- Stage 6 (Wk 19): defense-preparation, review-templates
- Stage 7 (Wk 20-22): final-deliverables-checklist, review-process, repository-upload
- All Stages: admin-guide

## Navigation Changes

**mkdocs.yml nav updates:**

- Add `student-journey.md` and `staff-guide.md` under "Getting Started"
- Add `timeline.md` to "Process and Timeline" (after diploma-lifecycle)
- Add `admin-guide.md` to "Process and Timeline" (at end)

**index.md update:**

- Add role-based entry links at the top of the landing page

## MkDocs Extensions Confirmed

- `pymdownx.tabbed` (alternate_style) — content tabs
- `pymdownx.details` — collapsible blocks
- `admonition` — callout boxes
- `pymdownx.tasklist` (custom_checkbox) — checklists
- `tables` — data tables
- `pymdownx.emoji` — role icons
- `attr_list` + `md_in_html` — extended formatting

**Not available:** Mermaid diagrams (superfences exists but no custom_fences config).

## Files Affected

| What | Type | Count |
|------|------|-------|
| `student-journey.md` | New | 1 |
| `staff-guide.md` | New | 1 |
| Stage badges on content pages | Edit | ~30 |
| `mkdocs.yml` nav | Edit | 1 |
| `index.md` landing page | Edit | 1 |
| **Total** | | ~34 |
