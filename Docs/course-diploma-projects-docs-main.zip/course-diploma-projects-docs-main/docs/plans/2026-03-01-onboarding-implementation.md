# Onboarding Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add role-based onboarding to the diploma project knowledge base so students and staff can find their way through the 22-week process.

**Architecture:** Two new Markdown pages (`student-journey.md`, `staff-guide.md`) at the repo root, stage badge admonitions added to ~30 existing pages, nav updates in `mkdocs.yml`, and role links on `index.md`. All content uses MkDocs Material features already enabled (tabbed, details, admonition, tasklist, emoji).

**Tech Stack:** MkDocs Material, Markdown, YAML

**Design doc:** `docs/plans/2026-03-01-onboarding-design.md`

---

### Task 1: Create `student-journey.md`

**Files:**
- Create: `student-journey.md` (repo root)

**Step 1: Create the student journey page**

Write the full file at `student-journey.md` with this content:

```markdown
# Your Diploma Journey

This page shows your complete path from topic selection to final defense. Use it to find what you need right now.

## Journey Overview

| Stage | When | What You Do | Key Pages |
|-------|------|-------------|-----------|
| [1. Choose Your Topic](#stage-1-choose-your-topic-weeks-12) | Weeks 1–2 | Select project type, pick 7+ criteria, find supervisor | [Course Overview](01-overview/course-overview.md), [Project Types](01-overview/project-types-and-criteria.md), [Team Rules](02-getting-started/team-rules.md) |
| [2. Get Approved](#stage-2-get-approved-week-3) | Week 3 | Submit application, get admin approval | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md), [Topic Changes](02-getting-started/topic-changes.md) |
| [3. Plan & Start Building](#stage-3-plan--start-building-weeks-46) | Weeks 4–6 | Set up repo, start coding, Progress Review 1 | [Thesis Guide](05-deliverables/thesis-guide.md), [Technical Requirements](04-technical-requirements/04a-business-and-docs/business-analysis.md) |
| [4. Build & Get Assessed](#stage-4-build--get-assessed-weeks-715) | Weeks 7–15 | Expert assessments, progress reviews, complexity check | [Expert Assessment](03-process-and-timeline/expert-assessment.md), [Booking Slots](03-process-and-timeline/booking-slots.md), [Timeline](03-process-and-timeline/timeline.md) |
| [5. Prepare Deliverables](#stage-5-prepare-deliverables-weeks-1618) | Weeks 16–18 | Record video, create presentation, write thesis, deploy | [Video](05-deliverables/video-requirements.md), [Presentation](05-deliverables/presentation-requirements.md), [Official Requirements](05-deliverables/official-requirements.md) |
| [6. Pre-Defense](#stage-6-pre-defense-week-19) | Week 19 | Present to committee, get reviewer contact | [Defense Preparation](06-defense-and-completion/defense-preparation.md), [Review Templates](05-deliverables/review-templates.md) |
| [7. Final Defense](#stage-7-final-defense-weeks-2022) | Weeks 20–22 | Get reviews, upload to repository, defend | [Final Checklist](06-defense-and-completion/final-deliverables-checklist.md), [Repository Upload](06-defense-and-completion/repository-upload.md) |

---

??? success "Stage 1: Choose Your Topic (Weeks 1–2)"

    ### What you need to do

    - [ ] Read the [Course Overview](01-overview/course-overview.md) to understand the process
    - [ ] Choose your project type: web, mobile, or game application
    - [ ] Select **7+ complexity criteria** (teams: 10+, with 5 per member) from the list below
    - [ ] Check that your topic is not [prohibited](01-overview/project-types-and-criteria.md#prohibited-project-types)
    - [ ] Find a [supervisor](02-getting-started/supervisor-role.md) and agree on your topic
    - [ ] If working in a team, read the [team rules](02-getting-started/team-rules.md)

    ### Criteria to choose from

    All criteria are listed in [Project Types and Criteria](01-overview/project-types-and-criteria.md). Here is the full list grouped by category:

    **Required (must include all 3):**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Business Analysis](04-technical-requirements/04a-business-and-docs/business-analysis.md) | Vision, problem statement, stakeholders, user stories, use cases |
    | [Backend](04-technical-requirements/04c-backend/backend.md) | Server-side framework, API, database, SOLID, 70% test coverage |
    | [Frontend](04-technical-requirements/04d-frontend-and-ux/frontend.md) | SPA with modern framework, state management, responsive layout |

    **Business & Docs:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [API Documentation](04-technical-requirements/04a-business-and-docs/api-documentation.md) | OpenAPI/Swagger spec, tutorials, architecture overview |

    **Data Layer:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Database](04-technical-requirements/04b-data-layer/database.md) | Schema design, migrations, roles, encryption (OLTP, OLAP, or NoSQL) |
    | [Real-time Analytics](04-technical-requirements/04b-data-layer/real-time-analytics.md) | Continuous event streams, WebSocket/SSE, live dashboards |

    **Frontend & UX:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Adaptive UI](04-technical-requirements/04d-frontend-and-ux/adaptive-ui.md) | 3 device types, responsive grid, relative units, WCAG contrast |
    | [Refined UX](04-technical-requirements/04d-frontend-and-ux/refined-ux.md) | Interaction scenarios, visual style, prototypes, user research |

    **Infrastructure:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [CI/CD](04-technical-requirements/04e-infrastructure/cicd.md) | Automated build, test, deploy pipelines |
    | [Containerization](04-technical-requirements/04e-infrastructure/containerization.md) | Docker images, compose files, orchestration |
    | [Cloud](04-technical-requirements/04e-infrastructure/cloud.md) | Cloud provider deployment, scaling, monitoring |
    | [Microservices](04-technical-requirements/04e-infrastructure/microservices.md) | Independent deployable services, async communication |

    **Testing:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Auto Tests](04-technical-requirements/04f-testing/auto-tests.md) | Unit, integration, and E2E test suites |
    | [Testing](04-technical-requirements/04f-testing/testing.md) | Test strategy, quality metrics, coverage analysis |

    **Specialized:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [AI Assistant](04-technical-requirements/04g-specialized/ai-assistant.md) | AI-powered features, prompt engineering, evaluation |
    | [Cryptography](04-technical-requirements/04g-specialized/cryptography.md) | Encryption, digital signatures, secure protocols |
    | [Machine Learning](04-technical-requirements/04g-specialized/machine-learning.md) | ML models, dataset handling, training, deployment |

    ### What happens next

    :arrow_right: **Stage 2:** Your supervisor signs your application and submits it to administration for approval.

??? success "Stage 2: Get Approved (Week 3)"

    ### What you need to do

    - [ ] Confirm your supervisor has signed your application
    - [ ] Wait for administration to approve your topic
    - [ ] If your topic needs changes, follow the [topic change process](02-getting-started/topic-changes.md)

    ### Prerequisites

    :white_check_mark: You have selected 7+ criteria and agreed on a topic with your supervisor.

    !!! warning "Failure risk"
        If your topic is not approved, you face **automatic expulsion** from the diploma process. Make sure your criteria count and topic meet requirements before submission.

    ### Key pages

    - [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) — full process overview
    - [Topic Changes](02-getting-started/topic-changes.md) — how to adjust your topic if needed

    ### What happens next

    :arrow_right: **Stage 3:** Start building your project. Set up your repository and begin coding.

??? success "Stage 3: Plan & Start Building (Weeks 4–6)"

    ### What you need to do

    - [ ] Set up your project repository with proper structure
    - [ ] Start implementing your chosen architecture
    - [ ] Begin writing your [thesis documentation](05-deliverables/thesis-guide.md) early
    - [ ] Complete **Progress Review 1** with your supervisor (initial prototype/architecture)
    - [ ] Attend weekly 15-minute standups with your supervisor
    - [ ] Read the grading rubrics for your chosen criteria (links in Stage 1)

    ### Prerequisites

    :white_check_mark: Your topic is approved by administration.

    ### Key pages

    - [Thesis Guide](05-deliverables/thesis-guide.md) — how to write your thesis document
    - [Official Requirements](05-deliverables/official-requirements.md) — formatting rules
    - All [Technical Requirements](04-technical-requirements/04a-business-and-docs/business-analysis.md) for your chosen criteria

    ### What happens next

    :arrow_right: **Stage 4:** Start booking expert assessment slots and continue building.

??? success "Stage 4: Build & Get Assessed (Weeks 7–15)"

    ### What you need to do

    - [ ] [Book assessment slots](03-process-and-timeline/booking-slots.md) with experts for each criterion
    - [ ] Submit materials to experts **at least 1 week before** your booked slot
    - [ ] Attend expert meetings (max 2 per criterion: assessment + optional appeal)
    - [ ] Complete **Progress Review 2** (Week 10) — working MVP
    - [ ] Complete **Progress Review 3** (Weeks 13–15) — feature-complete build
    - [ ] Continue weekly standups with supervisor

    ### Prerequisites

    :white_check_mark: Topic approved. Repository set up. Development started.

    !!! warning "Complexity check at Week 10"
        At Progress Review 2, your supervisor **must assess** whether your project meets complexity requirements. If the project is too simple, they will notify you **in writing**. Take this seriously — the pre-defense committee can reject projects that lack overall complexity, even if individual criteria pass.

    !!! danger "Expert assessment failure"
        A grade below 5 or "not passed" on any criterion means you are **not admitted to final defense**.

    ### Key pages

    - [Expert Assessment](03-process-and-timeline/expert-assessment.md) — how assessments work
    - [Booking Slots](03-process-and-timeline/booking-slots.md) — how to book and rules
    - [Timeline](03-process-and-timeline/timeline.md) — week-by-week milestones

    ### What happens next

    :arrow_right: **Stage 5:** Start preparing your deliverables — video, presentation, thesis, and deployment.

??? success "Stage 5: Prepare Deliverables (Weeks 16–18)"

    ### What you need to do

    - [ ] Record your [demo video](05-deliverables/video-requirements.md) (30 sec – 2 min, .mp4, 1080p+)
    - [ ] Create your [presentation](05-deliverables/presentation-requirements.md) (12–18 slides + appendix)
    - [ ] Finalize your [thesis document](05-deliverables/thesis-guide.md)
    - [ ] Submit thesis to supervisor **at least 5 working days** before pre-defense
    - [ ] **Deploy your application** — it must be live and accessible before pre-defense
    - [ ] Complete **Progress Review 4** — final version + thesis draft

    ### Prerequisites

    :white_check_mark: Expert assessments in progress or completed. Feature-complete build.

    !!! danger "Hard blockers"
        Without these, you will **not be admitted** to pre-defense:

        - :x: No live deployment — committee cannot open/use your app
        - :x: No demo video — required for institutional records
        - :x: No thesis document — reviewer cannot write review

    ### Key pages

    - [Video Requirements](05-deliverables/video-requirements.md) — specs, structure, dos and don'ts
    - [Presentation Requirements](05-deliverables/presentation-requirements.md) — slide structure, quality checklist
    - [Official Requirements](05-deliverables/official-requirements.md) — thesis formatting rules
    - [Thesis Guide](05-deliverables/thesis-guide.md) — step-by-step writing guide

    ### What happens next

    :arrow_right: **Stage 6:** Present at pre-defense. Your supervisor must sign your admission.

??? success "Stage 6: Pre-Defense (Week 19)"

    ### What you need to do

    - [ ] Get supervisor's written admission (or written rejection with reasons)
    - [ ] Present to the pre-defense committee
    - [ ] Demonstrate your deployed application
    - [ ] Show your demo video
    - [ ] If approved, receive reviewer contact from administration (within 3 days)

    ### Prerequisites

    :white_check_mark: Video recorded. Presentation ready. Thesis submitted to supervisor. App deployed.

    !!! tip "Presentation strategy"
        The committee forms their impression in the first 2–3 minutes. Lead with your strongest features. Spend **70% of your time** on your best 3–4 criteria and the product demo. Save weaker areas for Q&A.

        See [Defense Preparation](06-defense-and-completion/defense-preparation.md) for detailed tips.

    ### Key pages

    - [Defense Preparation](06-defense-and-completion/defense-preparation.md) — how to prepare and present
    - [Review Templates](05-deliverables/review-templates.md) — understand the review process

    ### What happens next

    :arrow_right: **Stage 7:** Get your reviews, upload to the national repository, and prepare for final defense.

??? success "Stage 7: Final Defense (Weeks 20–22)"

    ### What you need to do

    - [ ] Send thesis + repo links + pre-filled review template to your assigned reviewer
    - [ ] Wait for independent review (confirm admin also received it)
    - [ ] Supervisor writes their review using `advisors-review.docx`
    - [ ] Upload thesis to [national repository](06-defense-and-completion/repository-upload.md) (talpykla.elaba.lt)
    - [ ] Verify all [final deliverables](06-defense-and-completion/final-deliverables-checklist.md) are complete
    - [ ] Attend final defense and present to committee + external experts

    ### Prerequisites

    :white_check_mark: Pre-defense passed. Reviewer contact received.

    ### Final deliverables checklist

    | # | Document | Ready? |
    |---|----------|--------|
    | 1 | Thesis document (PDF) | :black_square_button: |
    | 2 | Abstract (1-page English) | :black_square_button: |
    | 3 | Presentation (.pptx/.pdf) | :black_square_button: |
    | 4 | Demo video (.mp4) | :black_square_button: |
    | 5 | Advisor report | :black_square_button: |
    | 6 | Independent review | :black_square_button: |
    | 7 | Live deployment (URL) | :black_square_button: |

    ### Key pages

    - [Final Deliverables Checklist](06-defense-and-completion/final-deliverables-checklist.md) — everything that must exist
    - [Review Process](06-defense-and-completion/review-process.md) — how to get your review
    - [Repository Upload](06-defense-and-completion/repository-upload.md) — upload instructions
    - [Defense Preparation](06-defense-and-completion/defense-preparation.md) — presentation tips
```

**Step 2: Verify the file renders correctly**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

Expected: Build succeeds with no errors referencing `student-journey.md`.

Note: The page won't appear in nav yet (that's Task 5). This step just checks Markdown is valid.

**Step 3: Commit**

```bash
git add student-journey.md
git commit -m "docs: add student journey onboarding page

7-stage journey map with collapsible checklists, criteria grouped by
category, prerequisite indicators, and stage-by-stage navigation."
```

---

### Task 2: Create `staff-guide.md`

**Files:**
- Create: `staff-guide.md` (repo root)

**Step 1: Create the staff guide page**

Write the full file at `staff-guide.md` with this content:

```markdown
# Staff Guide

Quick reference for supervisors, experts, and administrators. Find your responsibilities by role and stage.

=== "Supervisor / Expert"

    ## Your Responsibilities by Stage

    | Stage | When | What You Do | Reference |
    |-------|------|-------------|-----------|
    | Topic Selection | Weeks 1–2 | Verify student's criteria selection (7+ items), sign application | [Supervisor Role](02-getting-started/supervisor-role.md) |
    | Weekly Standups | Weeks 4–18 | 15-min weekly check-ins with student (document all meetings) | [Supervisor Role](02-getting-started/supervisor-role.md) |
    | Progress Review 1 | Weeks 4–6 | Evaluate initial prototype/architecture | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Progress Review 2 | Weeks 10–12 | Evaluate working MVP; **assess complexity risk** | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Progress Review 3 | Weeks 13–15 | Evaluate feature-complete build | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Expert Assessments | Weeks 7–18 | Set assessment slots, pre-check materials, grade students (10-point scale) | [Expert Assessment](03-process-and-timeline/expert-assessment.md) |
    | Progress Review 4 | Weeks 17–18 | Evaluate final version + thesis draft | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Thesis Review | Week 18 | Proofread English thesis (receive at least 5 working days before pre-defense) | [Thesis Guide](05-deliverables/thesis-guide.md) |
    | Pre-Defense Admission | Week 19 | Sign admission to pre-defense or provide written rejection | [Defense Preparation](06-defense-and-completion/defense-preparation.md) |
    | Supervisor Review | Week 20 | Write review using `advisors-review.docx` template | [Review Templates](05-deliverables/review-templates.md) |

    !!! warning "Key obligation: Complexity check at Week 10"
        At **Progress Review 2**, you must assess whether the student's project meets complexity requirements. If the project is too simple, you must notify the student **in writing**. The pre-defense committee evaluates overall project complexity — not just individual criteria.

    ??? info "Expert Assessment Quick Reference"
        **How it works:**

        - Set available time slots for students to book
        - Pre-check submitted materials a few days before the meeting
        - Hold max **2 meetings** per student per criterion:
            1. **Stage defense:** Assess grade, explain verbally, recommend improvements
            2. **Appeal (optional):** Assign final grade — no further appeal possible
        - Grade on a **10-point scale**
        - A grade **below 5** or **"not passed"** means the student is **not admitted to final defense**

        **Your decision points:**

        - Expert grade per criterion: You decide
        - Admission to pre-defense: Supervisor decides (sign or reject in writing)

        See [Expert Assessment](03-process-and-timeline/expert-assessment.md) and [Booking Slots](03-process-and-timeline/booking-slots.md) for full details.

    ??? info "Supervisor Qualifications"
        Who can be a supervisor:

        - SDC instructor with Master's or PhD degree
        - Outside university instructor with Master's or PhD degree
        - Industry specialist with 3+ years of relevant experience

        See [Supervisor Role](02-getting-started/supervisor-role.md) for full details.

=== "Administrator"

    ## Your Responsibilities by Stage

    | Stage | When | What You Do | Reference |
    |-------|------|-------------|-----------|
    | Semester Start | Week 1 | Publish semester timeline, distribute to all participants | [Timeline](03-process-and-timeline/timeline.md), [Admin Guide](03-process-and-timeline/admin-guide.md) |
    | Topic Approval | Weeks 2–3 | Review applications, approve or reject topics | [Admin Guide](03-process-and-timeline/admin-guide.md) |
    | Slot Setup | After approval | Assign expert assessment slots, announce sign-up process | [Booking Slots](03-process-and-timeline/booking-slots.md) |
    | Progress Monitoring | Weeks 4–18 | Monitor 4 progress reviews across all students | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) |
    | Pre-Defense | Week 19 | Organize pre-defense schedule (send at least 2 weeks in advance) | [Admin Guide](03-process-and-timeline/admin-guide.md) |
    | Reviewer Assignment | After pre-defense | Provide independent reviewer contacts (within 3 working days) | [Review Process](06-defense-and-completion/review-process.md) |
    | Review Collection | Weeks 20–21 | Confirm both reviews (supervisor + independent) are received | [Review Templates](05-deliverables/review-templates.md) |
    | Final Defense | Week 22 | Organize final defense, collect all final materials | [Final Checklist](06-defense-and-completion/final-deliverables-checklist.md) |

    !!! info "Decision Authority"
        | Decision | Who Decides |
        |----------|-------------|
        | Topic approval | Administration |
        | Expert grade per criterion | Expert instructor |
        | Admission to pre-defense | Supervisor |
        | Admission to final defense | Pre-defense committee |
        | Final grade | Defense committee |

    ??? success "Communication Checklist"
        Use this checklist to track your communications each semester:

        - [ ] Timeline published and distributed to all students and staff
        - [ ] Expert assessment slots announced with sign-up instructions
        - [ ] Pre-defense schedule sent at least 2 weeks in advance
        - [ ] Reviewer contacts distributed within 3 working days of successful pre-defense
        - [ ] Final defense schedule confirmed at least 2 weeks in advance
        - [ ] Upload instructions for national repository sent to students

    ??? info "Topic Change Handling"
        - Students may adjust topics until the deadline you set
        - After pre-defense, changes allowed only if committee recommends them (within 3 working days)
        - Students submit changes via standard form to office@esdc.lt (CC supervisor)
        - If topic changes after BA defense, student must re-defend BA

        See [Topic Changes](02-getting-started/topic-changes.md) for the student-facing process.

    ### Key Reference Pages

    - [Admin Guide](03-process-and-timeline/admin-guide.md) — full operational procedures
    - [Timeline](03-process-and-timeline/timeline.md) — week-by-week milestones with deadlines
    - [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) — 6 lifecycle stages overview
```

**Step 2: Verify the file renders correctly**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

Expected: Build succeeds with no errors.

**Step 3: Commit**

```bash
git add staff-guide.md
git commit -m "docs: add staff guide with supervisor and admin tabs

Tabbed page with responsibility matrices, key obligation callouts,
communication checklist, and decision authority reference."
```

---

### Task 3: Add stage badges to Section 01 and 02 pages (Stage 1)

**Files:**
- Modify: `01-overview/course-overview.md` (line 2, insert after comment)
- Modify: `01-overview/project-types-and-criteria.md` (line 2, insert after comment)
- Modify: `02-getting-started/team-rules.md` (line 2, insert after comment)
- Modify: `02-getting-started/supervisor-role.md` (line 2, insert after comment)
- Modify: `02-getting-started/topic-changes.md` (line 2, insert after comment)

**Step 1: Add badge to `01-overview/course-overview.md`**

Insert after line 1 (the `<!-- prev/next -->` comment), before line 3 (the `# Title`):

```markdown

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Start here. Understand the course structure before choosing your topic.
    :school: **Staff:** Reference for explaining the course to new students.

    **Prerequisites:** None — this is where everyone starts.

    [Next: Project Types →](project-types-and-criteria.md) | [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

```

**Step 2: Add badge to `01-overview/project-types-and-criteria.md`**

Insert after the comment line, before the heading:

```markdown

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Use this to choose your project type and select 7+ complexity criteria.
    :school: **Staff:** Reference for verifying student criteria selection.

    **Prerequisites:** Read [Course Overview](course-overview.md) first.

    [← Course Overview](course-overview.md) | [Next: Team Rules →](../02-getting-started/team-rules.md) | [Full Journey](../student-journey.md)

```

**Step 3: Add badge to `02-getting-started/team-rules.md`**

```markdown

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Read this if you plan to work in a team (max 2 people).
    :school: **Staff:** Rules for team project supervision.

    **Prerequisites:** Decided whether to work alone or with a partner.

    [← Project Types](../01-overview/project-types-and-criteria.md) | [Next: Supervisor Role →](supervisor-role.md) | [Full Journey](../student-journey.md)

```

**Step 4: Add badge to `02-getting-started/supervisor-role.md`**

```markdown

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Understand what your supervisor does and what they expect from you.
    :school: **Staff:** Your responsibilities as a supervisor — weekly standups, checkpoints, thesis review.

    **Prerequisites:** You are looking for or have been assigned a supervisor.

    [← Team Rules](team-rules.md) | [Next: Topic Changes →](topic-changes.md) | [Full Journey](../student-journey.md)

```

**Step 5: Add badge to `02-getting-started/topic-changes.md`**

```markdown

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Read this if you need to change your topic before or after approval.
    :school: **Staff:** Policy for handling topic change requests.

    **Prerequisites:** You have started the topic selection process.

    [← Supervisor Role](supervisor-role.md) | [Next: Diploma Lifecycle →](../03-process-and-timeline/diploma-lifecycle.md) | [Full Journey](../student-journey.md)

```

**Step 6: Verify build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

Expected: Build succeeds.

**Step 7: Commit**

```bash
git add 01-overview/course-overview.md 01-overview/project-types-and-criteria.md 02-getting-started/team-rules.md 02-getting-started/supervisor-role.md 02-getting-started/topic-changes.md
git commit -m "docs: add stage 1 badges to overview and getting-started pages

Stage 1 (Topic Selection, Weeks 1-2) badges with role guidance,
prerequisites, and navigation links."
```

---

### Task 4: Add stage badges to Section 03 pages (Stages 2 and 4)

**Files:**
- Modify: `03-process-and-timeline/diploma-lifecycle.md` (Stage 2)
- Modify: `03-process-and-timeline/expert-assessment.md` (Stage 4)
- Modify: `03-process-and-timeline/booking-slots.md` (Stage 4)
- Modify: `03-process-and-timeline/timeline.md` (Stage 4)
- Modify: `03-process-and-timeline/admin-guide.md` (All Stages)

**Step 1: Add badge to `diploma-lifecycle.md`**

```markdown

!!! abstract "Stage 2 of 7 — Topic Approval | Week 3"
    :mortar_board: **Students:** Understand the full 6-stage lifecycle of your diploma project.
    :school: **Staff:** Reference for the complete process with all decision gates.

    **Prerequisites:** You have chosen your topic and supervisor ([Stage 1](../student-journey.md#stage-1-choose-your-topic-weeks-12)).

    [← Topic Changes](../02-getting-started/topic-changes.md) | [Next: Expert Assessment →](expert-assessment.md) | [Full Journey](../student-journey.md)

```

**Step 2: Add badge to `expert-assessment.md`**

```markdown

!!! abstract "Stage 4 of 7 — Build & Get Assessed | Weeks 7–15"
    :mortar_board: **Students:** How expert assessments work — grading, meetings, and appeals.
    :school: **Staff:** Your procedures for running expert assessments.

    **Prerequisites:** Topic approved. Development started. Ready to book assessment slots.

    [← Diploma Lifecycle](diploma-lifecycle.md) | [Next: Booking Slots →](booking-slots.md) | [Full Journey](../student-journey.md)

```

**Step 3: Add badge to `booking-slots.md`**

```markdown

!!! abstract "Stage 4 of 7 — Build & Get Assessed | Weeks 7–15"
    :mortar_board: **Students:** How to book assessment slots with experts. Book early.
    :school: **Staff:** Slot availability rules and no-show policies.

    **Prerequisites:** Expert assessment slots have been announced by administration.

    [← Expert Assessment](expert-assessment.md) | [Next: Timeline →](timeline.md) | [Full Journey](../student-journey.md)

```

**Step 4: Add badge to `timeline.md`**

```markdown

!!! abstract "Stage 4 of 7 — Build & Get Assessed | Weeks 7–15"
    :mortar_board: **Students:** Week-by-week milestones and critical deadlines. Bookmark this page.
    :school: **Staff:** Complete semester timeline for reference.

    **Prerequisites:** Topic approved. Use this as your calendar throughout the semester.

    [← Booking Slots](booking-slots.md) | [Next: Admin Guide →](admin-guide.md) | [Full Journey](../student-journey.md)

```

**Step 5: Add badge to `admin-guide.md`**

```markdown

!!! abstract "All Stages — Administrative Reference"
    :school: **Administrators:** Your operational procedures for the entire semester.
    :mortar_board: **Students:** You do not need to read this page. It is for course administrators.

    **Prerequisites:** None — this is a reference document.

    [← Timeline](timeline.md) | [Next: Business Analysis →](../04-technical-requirements/04a-business-and-docs/business-analysis.md) | [Staff Guide](../staff-guide.md)

```

**Step 6: Verify build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

**Step 7: Commit**

```bash
git add 03-process-and-timeline/diploma-lifecycle.md 03-process-and-timeline/expert-assessment.md 03-process-and-timeline/booking-slots.md 03-process-and-timeline/timeline.md 03-process-and-timeline/admin-guide.md
git commit -m "docs: add stage badges to process and timeline pages

Stage 2 (diploma-lifecycle), Stage 4 (expert/booking/timeline),
and All Stages (admin-guide) badges."
```

---

### Task 5: Add stage badges to Section 04 pages (Stage 3) — all 17 technical requirements

**Files:**
- Modify all 17 files in `04-technical-requirements/`

**Step 1: Add badges to all 17 technical requirement files**

Each file gets the same stage badge with a criterion-specific student guidance line. The badge is inserted after the `<!-- prev/next -->` comment on line 1, before the blank line and heading.

**Template for all 17 files:**

```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for this criterion. Read the minimum (grade 5) and maximum (grade 10) requirements.
    :school: **Staff:** Assessment rubric — use for grading.

    **Prerequisites:** Topic approved with this criterion selected.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

```

Note: The `Full Journey` link uses `../../` because these files are two levels deep (`04-technical-requirements/04x-category/file.md`).

The prev/next links in the badge should match the existing `<!-- prev/next -->` comments. For each file:

**04a-business-and-docs/business-analysis.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** **Mandatory criterion.** Must be defended before a committee, not just an expert.
    :school: **Staff:** BA assessment rubric — committee evaluation, not individual expert.

    **Prerequisites:** Topic approved. This is the first criterion to complete.

    [← Admin Guide](../../03-process-and-timeline/admin-guide.md) | [Next: API Documentation →](api-documentation.md) | [Full Journey](../../student-journey.md)

```

**04a-business-and-docs/api-documentation.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for API documentation. Requires OpenAPI/Swagger spec.
    :school: **Staff:** Assessment rubric for API documentation quality.

    **Prerequisites:** API implementation started.

    [← Business Analysis](business-analysis.md) | [Next: Database →](../04b-data-layer/database.md) | [Full Journey](../../student-journey.md)

```

**04b-data-layer/database.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for database design (OLTP, OLAP, or NoSQL options).
    :school: **Staff:** Assessment rubric for database implementation.

    **Prerequisites:** Project architecture designed. Database type chosen.

    [← API Documentation](../04a-business-and-docs/api-documentation.md) | [Next: Real-time Analytics →](real-time-analytics.md) | [Full Journey](../../student-journey.md)

```

**04b-data-layer/real-time-analytics.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for real-time analytics. Must be continuous event streams, not button clicks.
    :school: **Staff:** Assessment rubric for real-time data handling.

    **Prerequisites:** Real-time requirement defined in business analysis.

    [← Database](database.md) | [Next: Backend →](../04c-backend/backend.md) | [Full Journey](../../student-journey.md)

```

**04c-backend/backend.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** **Required criterion.** Modern framework, layered architecture, SOLID, 70% test coverage.
    :school: **Staff:** Backend assessment rubric — verify architecture, testing, deployment.

    **Prerequisites:** Topic approved with backend criterion selected.

    [← Real-time Analytics](../04b-data-layer/real-time-analytics.md) | [Next: Frontend →](../04d-frontend-and-ux/frontend.md) | [Full Journey](../../student-journey.md)

```

**04d-frontend-and-ux/frontend.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** **Required criterion.** SPA with modern framework, state management, responsive layout.
    :school: **Staff:** Frontend assessment rubric — verify SPA architecture, components, testing.

    **Prerequisites:** Backend API available or mocked.

    [← Backend](../04c-backend/backend.md) | [Next: Adaptive UI →](adaptive-ui.md) | [Full Journey](../../student-journey.md)

```

**04d-frontend-and-ux/adaptive-ui.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for adaptive UI. Must support mobile, tablet, and desktop.
    :school: **Staff:** Assessment rubric for multi-device UI support.

    **Prerequisites:** UI framework chosen. Screen layouts defined.

    [← Frontend](frontend.md) | [Next: Refined UX →](refined-ux.md) | [Full Journey](../../student-journey.md)

```

**04d-frontend-and-ux/refined-ux.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for UX design. Requires interaction scenarios, prototypes, user research.
    :school: **Staff:** Assessment rubric for UX quality.

    **Prerequisites:** UI design started. User personas defined.

    [← Adaptive UI](adaptive-ui.md) | [Next: CI/CD →](../04e-infrastructure/cicd.md) | [Full Journey](../../student-journey.md)

```

**04e-infrastructure/cicd.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for CI/CD pipelines. Automated build, test, and deploy.
    :school: **Staff:** Assessment rubric for CI/CD implementation.

    **Prerequisites:** Code repository set up. Build tools configured.

    [← Refined UX](../04d-frontend-and-ux/refined-ux.md) | [Next: Containerization →](containerization.md) | [Full Journey](../../student-journey.md)

```

**04e-infrastructure/containerization.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for containerization. Docker images, compose files, orchestration.
    :school: **Staff:** Assessment rubric for container-based deployment.

    **Prerequisites:** Application has deployable components.

    [← CI/CD](cicd.md) | [Next: Cloud →](cloud.md) | [Full Journey](../../student-journey.md)

```

**04e-infrastructure/cloud.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for cloud deployment. Cloud provider, scaling, monitoring.
    :school: **Staff:** Assessment rubric for cloud infrastructure.

    **Prerequisites:** Application ready for deployment. Cloud provider selected.

    [← Containerization](containerization.md) | [Next: Microservices →](microservices.md) | [Full Journey](../../student-journey.md)

```

**04e-infrastructure/microservices.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for microservices. Independent deployable services, async communication.
    :school: **Staff:** Assessment rubric for microservice architecture.

    **Prerequisites:** Architecture decision to use microservices (justified).

    [← Cloud](cloud.md) | [Next: Auto Tests →](../04f-testing/auto-tests.md) | [Full Journey](../../student-journey.md)

```

**04f-testing/auto-tests.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for automated test suites. Unit, integration, and E2E tests.
    :school: **Staff:** Assessment rubric for test automation.

    **Prerequisites:** Code written. Test framework configured.

    [← Microservices](../04e-infrastructure/microservices.md) | [Next: Testing →](testing.md) | [Full Journey](../../student-journey.md)

```

**04f-testing/testing.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for testing strategy. Test plans, quality metrics, coverage analysis.
    :school: **Staff:** Assessment rubric for overall testing quality.

    **Prerequisites:** Test suites written. Coverage tools configured.

    [← Auto Tests](auto-tests.md) | [Next: AI Assistant →](../04g-specialized/ai-assistant.md) | [Full Journey](../../student-journey.md)

```

**04g-specialized/ai-assistant.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for AI-powered features. Prompt engineering, evaluation, integration.
    :school: **Staff:** Assessment rubric for AI implementation.

    **Prerequisites:** AI use case defined in business analysis.

    [← Testing](../04f-testing/testing.md) | [Next: Cryptography →](cryptography.md) | [Full Journey](../../student-journey.md)

```

**04g-specialized/cryptography.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for cryptography. Encryption, digital signatures, secure protocols.
    :school: **Staff:** Assessment rubric for security implementation.

    **Prerequisites:** Security requirements defined. Crypto use case identified.

    [← AI Assistant](ai-assistant.md) | [Next: Machine Learning →](machine-learning.md) | [Full Journey](../../student-journey.md)

```

**04g-specialized/machine-learning.md:**
```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for ML models. Dataset handling, training, metrics, deployment.
    :school: **Staff:** Assessment rubric for machine learning implementation.

    **Prerequisites:** Prediction task defined. Dataset sourced.

    [← Cryptography](cryptography.md) | [Next: Official Requirements →](../../05-deliverables/official-requirements.md) | [Full Journey](../../student-journey.md)

```

**Step 2: Verify build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

**Step 3: Commit**

```bash
git add 04-technical-requirements/
git commit -m "docs: add stage 3 badges to all 17 technical requirement pages

Stage 3 (Build & Get Assessed, Weeks 4-18) badges with criterion-specific
guidance, prerequisites, and navigation links."
```

---

### Task 6: Add stage badges to Section 05 pages (Stages 3 and 5)

**Files:**
- Modify: `05-deliverables/official-requirements.md` (Stage 5)
- Modify: `05-deliverables/review-templates.md` (Stage 6)
- Modify: `05-deliverables/video-requirements.md` (Stage 5)
- Modify: `05-deliverables/presentation-requirements.md` (Stage 5)
- Modify: `05-deliverables/thesis-guide.md` (Stage 3)

**Step 1: Add badge to `official-requirements.md`**

```markdown

!!! abstract "Stage 5 of 7 — Prepare Deliverables | Weeks 16–18"
    :mortar_board: **Students:** Formatting rules for your thesis document. Reviewers evaluate ONLY from this document.
    :school: **Staff:** Official formatting requirements reference.

    **Prerequisites:** Read early (Week 1), apply when writing (Week 18).

    [← Machine Learning](../04-technical-requirements/04g-specialized/machine-learning.md) | [Next: Review Templates →](review-templates.md) | [Full Journey](../student-journey.md)

```

**Step 2: Add badge to `review-templates.md`**

```markdown

!!! abstract "Stage 6 of 7 — Pre-Defense | Week 19"
    :mortar_board: **Students:** Understand the two reviews you need and how to request them.
    :school: **Staff:** Review templates and process for supervisors and independent experts.

    **Prerequisites:** Thesis being written. Pre-defense approaching.

    [← Official Requirements](official-requirements.md) | [Next: Video Requirements →](video-requirements.md) | [Full Journey](../student-journey.md)

```

**Step 3: Add badge to `video-requirements.md`**

```markdown

!!! abstract "Stage 5 of 7 — Prepare Deliverables | Weeks 16–18"
    :mortar_board: **Students:** Record your demo video before pre-defense. 30 sec – 2 min, 1080p+, .mp4 format.
    :school: **Staff:** Video quality requirements for evaluation.

    **Prerequisites:** Application working and ready to be recorded.

    [← Review Templates](review-templates.md) | [Next: Presentation Requirements →](presentation-requirements.md) | [Full Journey](../student-journey.md)

```

**Step 4: Add badge to `presentation-requirements.md`**

```markdown

!!! abstract "Stage 5 of 7 — Prepare Deliverables | Weeks 16–18"
    :mortar_board: **Students:** Create your defense presentation. 12–18 slides + appendix. Lead with your elevator pitch.
    :school: **Staff:** Presentation quality requirements and slide structure.

    **Prerequisites:** Video recorded. Architecture clear. Key features implemented.

    [← Video Requirements](video-requirements.md) | [Next: Thesis Guide →](thesis-guide.md) | [Full Journey](../student-journey.md)

```

**Step 5: Add badge to `thesis-guide.md`**

```markdown

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Step-by-step guide for writing your thesis. Start early, write progressively.
    :school: **Staff:** Thesis structure and quality expectations.

    **Prerequisites:** Topic approved. Development started.

    [← Presentation Requirements](presentation-requirements.md) | [Next: Final Checklist →](../06-defense-and-completion/final-deliverables-checklist.md) | [Full Journey](../student-journey.md)

```

**Step 6: Verify build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

**Step 7: Commit**

```bash
git add 05-deliverables/official-requirements.md 05-deliverables/review-templates.md 05-deliverables/video-requirements.md 05-deliverables/presentation-requirements.md 05-deliverables/thesis-guide.md
git commit -m "docs: add stage badges to deliverables pages

Stage 5 (Prepare Deliverables), Stage 6 (Pre-Defense), and
Stage 3 (thesis-guide) badges."
```

---

### Task 7: Add stage badges to Section 06 pages (Stages 6 and 7)

**Files:**
- Modify: `06-defense-and-completion/final-deliverables-checklist.md` (Stage 7)
- Modify: `06-defense-and-completion/review-process.md` (Stage 7)
- Modify: `06-defense-and-completion/repository-upload.md` (Stage 7)
- Modify: `06-defense-and-completion/defense-preparation.md` (Stage 6)

**Step 1: Add badge to `final-deliverables-checklist.md`**

```markdown

!!! abstract "Stage 7 of 7 — Final Defense | Weeks 20–22"
    :mortar_board: **Students:** Verify ALL items on this list exist before final defense. No exceptions.
    :school: **Staff:** Final gate checklist for defense admission.

    **Prerequisites:** Pre-defense passed ([Stage 6](../student-journey.md#stage-6-pre-defense-week-19)).

    [← Thesis Guide](../05-deliverables/thesis-guide.md) | [Next: Review Process →](review-process.md) | [Full Journey](../student-journey.md)

```

**Step 2: Add badge to `review-process.md`**

```markdown

!!! abstract "Stage 7 of 7 — Final Defense | Weeks 20–22"
    :mortar_board: **Students:** How to get your independent review. Send materials promptly after pre-defense.
    :school: **Staff:** Review coordination process and deadlines.

    **Prerequisites:** Pre-defense passed. Reviewer contact received from administration.

    [← Final Checklist](final-deliverables-checklist.md) | [Next: Repository Upload →](repository-upload.md) | [Full Journey](../student-journey.md)

```

**Step 3: Add badge to `repository-upload.md`**

```markdown

!!! abstract "Stage 7 of 7 — Final Defense | Weeks 20–22"
    :mortar_board: **Students:** Upload your thesis to the national repository (talpykla.elaba.lt) before final defense.
    :school: **Staff:** Repository upload requirements and field values.

    **Prerequisites:** Thesis finalized. Pre-defense passed.

    [← Review Process](review-process.md) | [Next: Defense Preparation →](defense-preparation.md) | [Full Journey](../student-journey.md)

```

**Step 4: Add badge to `defense-preparation.md`**

```markdown

!!! abstract "Stage 6 of 7 — Pre-Defense | Week 19"
    :mortar_board: **Students:** How to prepare for defense. Practice your pitch, deploy your app, prepare for Q&A.
    :school: **Staff:** What to expect from student presentations.

    **Prerequisites:** All deliverables ready. Application deployed and accessible.

    [← Repository Upload](repository-upload.md) | [Full Journey](../student-journey.md)

```

**Step 5: Verify build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | head -20`

**Step 6: Commit**

```bash
git add 06-defense-and-completion/
git commit -m "docs: add stage badges to defense and completion pages

Stage 6 (Pre-Defense) and Stage 7 (Final Defense) badges with
navigation and prerequisite indicators."
```

---

### Task 8: Update `mkdocs.yml` nav and `index.md`

**Files:**
- Modify: `mkdocs.yml` (lines 73-85)
- Modify: `index.md` (lines 1-7)

**Step 1: Update `mkdocs.yml` nav**

Replace the nav section (starting at line 73) with:

```yaml
nav:
  - Home: index.md
  - Overview:
    - Course Overview: 01-overview/course-overview.md
    - Project Types and Criteria: 01-overview/project-types-and-criteria.md
  - Getting Started:
    - Student Journey: student-journey.md
    - Staff Guide: staff-guide.md
    - Team Rules: 02-getting-started/team-rules.md
    - Supervisor Role: 02-getting-started/supervisor-role.md
    - Topic Changes: 02-getting-started/topic-changes.md
  - Process and Timeline:
    - Diploma Lifecycle: 03-process-and-timeline/diploma-lifecycle.md
    - Timeline: 03-process-and-timeline/timeline.md
    - Expert Assessment: 03-process-and-timeline/expert-assessment.md
    - Booking Slots: 03-process-and-timeline/booking-slots.md
    - Admin Guide: 03-process-and-timeline/admin-guide.md
  - Technical Requirements:
    - Business and Docs:
      - Business Analysis: 04-technical-requirements/04a-business-and-docs/business-analysis.md
      - API Documentation: 04-technical-requirements/04a-business-and-docs/api-documentation.md
    - Data Layer:
      - Database: 04-technical-requirements/04b-data-layer/database.md
      - Real-time Analytics: 04-technical-requirements/04b-data-layer/real-time-analytics.md
    - Backend:
      - Backend: 04-technical-requirements/04c-backend/backend.md
    - Frontend and UX:
      - Frontend: 04-technical-requirements/04d-frontend-and-ux/frontend.md
      - Adaptive UI: 04-technical-requirements/04d-frontend-and-ux/adaptive-ui.md
      - Refined UX: 04-technical-requirements/04d-frontend-and-ux/refined-ux.md
    - Infrastructure:
      - CI/CD: 04-technical-requirements/04e-infrastructure/cicd.md
      - Containerization: 04-technical-requirements/04e-infrastructure/containerization.md
      - Cloud: 04-technical-requirements/04e-infrastructure/cloud.md
      - Microservices: 04-technical-requirements/04e-infrastructure/microservices.md
    - Testing:
      - Auto Tests: 04-technical-requirements/04f-testing/auto-tests.md
      - Testing: 04-technical-requirements/04f-testing/testing.md
    - Specialized:
      - AI Assistant: 04-technical-requirements/04g-specialized/ai-assistant.md
      - Cryptography: 04-technical-requirements/04g-specialized/cryptography.md
      - Machine Learning: 04-technical-requirements/04g-specialized/machine-learning.md
  - Deliverables:
    - Official Requirements: 05-deliverables/official-requirements.md
    - Review Templates: 05-deliverables/review-templates.md
    - Video Requirements: 05-deliverables/video-requirements.md
    - Presentation Requirements: 05-deliverables/presentation-requirements.md
    - Thesis Guide: 05-deliverables/thesis-guide.md
    - Thesis Template:
      - Home: 05-deliverables/thesis-template/docs/index.md
      - Project Overview:
        - Overview: 05-deliverables/thesis-template/docs/01-project-overview/index.md
        - Problem & Goals: 05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md
        - Stakeholders: 05-deliverables/thesis-template/docs/01-project-overview/stakeholders.md
        - Scope: 05-deliverables/thesis-template/docs/01-project-overview/scope.md
        - Features: 05-deliverables/thesis-template/docs/01-project-overview/features.md
      - Technical:
        - Architecture: 05-deliverables/thesis-template/docs/02-technical/index.md
        - Tech Stack: 05-deliverables/thesis-template/docs/02-technical/tech-stack.md
        - Deployment: 05-deliverables/thesis-template/docs/02-technical/deployment.md
        - Criteria Template: 05-deliverables/thesis-template/docs/02-technical/criteria/_template.md
      - User Guide:
        - Getting Started: 05-deliverables/thesis-template/docs/03-user-guide/index.md
        - Features: 05-deliverables/thesis-template/docs/03-user-guide/features.md
        - FAQ: 05-deliverables/thesis-template/docs/03-user-guide/faq.md
      - Retrospective: 05-deliverables/thesis-template/docs/04-retrospective/index.md
      - Appendices:
        - Glossary: 05-deliverables/thesis-template/docs/appendices/glossary.md
        - API Reference: 05-deliverables/thesis-template/docs/appendices/api-reference.md
        - Database Schema: 05-deliverables/thesis-template/docs/appendices/db-schema.md
  - Defense and Completion:
    - Final Deliverables Checklist: 06-defense-and-completion/final-deliverables-checklist.md
    - Review Process: 06-defense-and-completion/review-process.md
    - Repository Upload: 06-defense-and-completion/repository-upload.md
    - Defense Preparation: 06-defense-and-completion/defense-preparation.md
```

**Step 2: Update `index.md` — add role entry links**

Insert after line 2 (after the `# Diploma Project Knowledge Base` heading and before the paragraph), add:

```markdown

!!! tip "Start here"
    :mortar_board: **Are you a student?** Start with your [Journey Map](student-journey.md) — it shows every step from topic selection to final defense.

    :school: **Are you staff?** See the [Staff Guide](staff-guide.md) — responsibilities by role and stage.

```

**Step 3: Also add `onboarding-research.md` and `docs/plans/` to the `exclude_docs` list**

Add these lines to the `exclude_docs` block in `mkdocs.yml` so they don't appear in the site:

```yaml
  onboarding-research.md
  docs/
  course-feedback.md
```

**Step 4: Verify full build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build 2>&1 | tail -5`

Expected: Build succeeds. No warnings about missing pages.

**Step 5: Verify locally with serve**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs serve`

Manually verify:
- Home page shows role entry links
- "Getting Started" tab has Student Journey and Staff Guide
- "Process and Timeline" tab has Timeline and Admin Guide
- Student Journey page renders with collapsible stages
- Staff Guide page renders with working tabs
- Click through several stage badges on existing pages

**Step 6: Commit**

```bash
git add mkdocs.yml index.md
git commit -m "docs: update nav with onboarding pages and hidden pages

Add student-journey and staff-guide to Getting Started nav.
Add timeline and admin-guide to Process and Timeline nav.
Add role entry links to landing page.
Exclude research and plan files from site build."
```

---

### Task 9: Final verification and research file update

**Files:**
- Modify: `onboarding-research.md`

**Step 1: Run full build**

Run: `cd "C:\Users\mikal\IdeaProjects\course-diploma-projects-docs" && python -m mkdocs build --strict 2>&1`

Expected: Build succeeds with no warnings.

**Step 2: Verify all links work**

Check that the build output has no broken link warnings. If `--strict` mode fails on any links, fix them.

**Step 3: Update `onboarding-research.md` with what was built**

Append a "What Was Built" section to the end of the file:

```markdown

## What Was Built

### New Pages
1. **`student-journey.md`** — 7-stage journey map with collapsible checklists, all 17 criteria grouped by category, prerequisite indicators, and navigation links
2. **`staff-guide.md`** — Tabbed guide (Supervisor/Expert | Administrator) with responsibility matrices, key obligation callouts, communication checklist, and decision authority table

### Stage Badges Added
Added `!!! abstract` admonitions to 29 existing content pages:
- 5 pages tagged Stage 1 (Topic Selection)
- 1 page tagged Stage 2 (Topic Approval)
- 18 pages tagged Stage 3 (Build & Get Assessed) — 17 technical requirements + thesis guide
- 3 pages tagged Stage 4 (Build & Get Assessed — expert assessments)
- 3 pages tagged Stage 5 (Prepare Deliverables)
- 2 pages tagged Stage 6 (Pre-Defense)
- 3 pages tagged Stage 7 (Final Defense)
- 1 page tagged All Stages (admin guide)

### Navigation Changes
- Added Student Journey and Staff Guide to "Getting Started" tab
- Added Timeline and Admin Guide to "Process and Timeline" tab
- Added role-based entry links to landing page (index.md)
- Excluded research/plan files from site build

### MkDocs Elements Used
- Content tabs (`=== "Tab"`) for role switching in staff guide
- Collapsible blocks (`??? success`) for stage details in student journey
- Admonitions (`!!! abstract`) for stage badges on all pages
- Task lists (`- [ ]`) for checklists
- Tables for journey overview, criteria lists, and responsibility matrices
- Emoji (`:mortar_board:`, `:school:`) for role tags
```

**Step 4: Commit**

```bash
git add onboarding-research.md
git commit -m "docs: update onboarding research with build summary"
```
