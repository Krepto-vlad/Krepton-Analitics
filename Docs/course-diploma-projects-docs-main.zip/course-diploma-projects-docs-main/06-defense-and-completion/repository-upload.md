<!-- prev: review-process.md | next: defense-preparation.md -->

!!! abstract "Stage 7 of 7 — Final Defense | Weeks 20–22"
    :mortar_board: **Students:** Upload your thesis to the national repository (talpykla.elaba.lt) before final defense.

    :school: **Staff:** Repository upload requirements and field values.

    **Prerequisites:** Thesis finalized. Pre-defense passed.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Upload to the Lithuanian National Repository

## Where to Upload

Upload your work at: **[https://talpykla.elaba.lt](https://talpykla.elaba.lt)**

> The administration will provide upload instructions separately.

---

## Important Notes

- You do not have to attach the **advisor report**, but it is recommended

---

## Upload Settings

| Field | Value |
|-------|-------|
| **Work type** | `Bachelor thesis` |
| **Classification does not apply** | `Weight (%) 100%` |
| **Scientific Field** | `Informatikos mokslai - Informatika / Computer Science - Informatics` |

---

## Additional Resources

Attach links to your additional resources (GitHub, Figma, etc.) in the repository.
