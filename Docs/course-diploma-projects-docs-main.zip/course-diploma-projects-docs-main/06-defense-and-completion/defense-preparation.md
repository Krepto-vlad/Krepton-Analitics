<!-- prev: repository-upload.md | next: -->

!!! abstract "Stage 6 of 7 — Pre-Defense | Week 19"
    :mortar_board: **Students:** How to prepare for defense. Practice your pitch, deploy your app, prepare for Q&A.

    :school: **Staff:** What to expect from student presentations.

    **Prerequisites:** All deliverables ready. Application deployed and accessible.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Tips Before Attending the Defense (Pre-Defense)

## Elevator Pitch
Add an answer to this question on your first slide and at the start of your speech:
**"What does my application do — explained in 30 seconds to a person on the street? Why should they buy or use it?"**

## Goal and Tasks
State your goal and tasks clearly. The committee should understand the scope within the first minute.

## Database
Fill your database with realistic data (not `test`/`admin`/`123`).

## Research Projects

If your project is research-oriented (ML model, algorithm comparison, data analysis), you must present:

- **Hypothesis or research question** — what you set out to prove or investigate
- **Methodology** — how you structured the experiment (dataset, parameters, conditions)
- **Baseline** — what the starting point or comparison benchmark was
- **Results with metrics** — quantitative outcomes (accuracy, precision, F1, latency, throughput, etc.)
- **Success/failure criteria** — define in advance what constitutes a successful outcome vs. a failed one
- **Interpretation** — what the results mean and whether they support the hypothesis

A negative result (hypothesis disproven) is acceptable **if** the methodology was sound and the analysis is thorough. Do not hide negative results — present them honestly and explain what you learned.

## Deployment

Your application **must** be deployed and accessible via a public URL before the pre-defense. This is a hard requirement, not optional. If your application is not deployed, you will not be admitted to the defense.

- Verify the URL works from a different network (not your local machine)
- Ensure the deployment will remain live through the final defense date
- Have a backup plan (local demo) in case of cloud outage — but this does not replace the deployment requirement

---

## Speech
Practice your speech in English — out loud, with a timer.

## Thesis Document
The thesis document (пояснительная записка) is your responsibility. If the automated generation does not work, create it manually in Word.

---

## Presentation Strategy

### Focus on Strengths

Lead with what you did well. The committee forms their impression in the first 2-3 minutes. If you open with apologies ("I didn't have time for...", "this part is incomplete..."), you set a negative frame that colors everything after it.

**Do:**
- Open with your elevator pitch and strongest feature
- Show your best technical decisions with confidence
- Present challenges as "Problem → Solution" stories
- Acknowledge limitations briefly in the Results slide — don't dwell

**Don't:**
- Apologize for criteria you scored lower on
- Say "I know this isn't great, but..."
- Spend more time on what's missing than on what's done
- Read your slides word for word

### Time Allocation

Spend 70% of your time on your strongest 3-4 criteria and the product demo. Spend 30% on the remaining criteria. The committee will ask about weak areas in Q&A — that is the appropriate place to discuss limitations.
