<!-- prev: final-deliverables-checklist.md | next: repository-upload.md -->

!!! abstract "Stage 7 of 7 — Final Defense | Weeks 20–22"
    :mortar_board: **Students:** How to get your independent review. Send materials promptly after pre-defense.

    :school: **Staff:** Review coordination process and deadlines.

    **Prerequisites:** Pre-defense passed. Reviewer contact received from administration.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Review Template (Getting a Review from an Independent Expert)

## How to Get a Review

You will receive the reviewer's contact details **after** you upload the final, approved version of your thesis document (пояснительная записка) to the repository:

**[https://talpykla.elaba.lt](https://talpykla.elaba.lt)**

---

## What to Send to the Reviewer

You need to send the reviewer an email with:

1. **Your thesis document** (as a PDF — check the file size)
2. **Links to your repositories** (make sure all resources are publicly accessible)
3. **The review template** (we recommend that you pre-fill it with your personal details and project information)

> The review template is available as a separate file:
> [`Review Templates`](../05-deliverables/review-templates.md)

---

## Cover Letter

In your cover letter, make sure to:

1. **Ask the reviewer to confirm** that they received your email
2. **Remind them** that the review must be sent no later than `<the administration will provide the date>`:
   - by email to your address
   - with the administration in CC
3. **Write in English** and follow standard business email etiquette

---

## Stay Available

Check your email regularly. The reviewer may want to ask you follow-up questions.

---

## After You Receive the Review

1. **Make sure** the administration also received the review
2. **Read it carefully**, especially the section with comments and concerns
   - You should be ready to respond to these comments during the defense
3. **Discuss the review and its comments** with your advisor
