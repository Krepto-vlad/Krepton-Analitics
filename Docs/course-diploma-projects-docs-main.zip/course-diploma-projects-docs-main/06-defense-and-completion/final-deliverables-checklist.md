<!-- prev: ../05-deliverables/thesis-guide.md | next: review-process.md -->

!!! abstract "Stage 7 of 7 — Final Defense | Weeks 20–22"
    :mortar_board: **Students:** Verify ALL items on this list exist before final defense. No exceptions.

    :school: **Staff:** Final gate checklist for defense admission.

    **Prerequisites:** Pre-defense passed ([Stage 6](../student-journey.md)).

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# What You Need Before the Defense

You must have the following materials ready before the defense:

| # | Document | Description |
|---|----------|-------------|
| 1 | **Thesis document (пояснительная записка)** | A PDF file with the full text of your diploma project, formatted according to the requirements |
| 2 | **Abstract** | A short summary of your work (usually 1 page) in English |
| 3 | **Presentation** | Slides for the defense (PowerPoint, Google Slides, or PDF) |
| 4 | **Demo video** | A video that shows how your application works (30 seconds – 2 minutes) |
| 5 | **Advisor report** | Evaluation and comments from your academic advisor |
| 6 | **Review** | Evaluation and comments from an independent reviewer |
| 7 | **Live deployment** | Application accessible via a public URL. Must be running at the time of defense. **No deployment = not admitted to defense.** |

---

## Blockers

The following items are **hard blockers** — without them, you will not be admitted to the defense:

| Blocker | Why |
|---------|-----|
| No live deployment | The committee must be able to open and use your application during the defense |
| No demo video | Required for portfolio and institutional records |
| No thesis document | The reviewer cannot write a review without it |

---

## Diagram Requirements

The defense committee expects all technical submissions (thesis, presentation, and ZIP archive) to include **diagrams and schemas** for the technical parts of your application. At minimum, include:

- **Architecture / component diagram** — showing how the system components interact
- **Database schema (ER diagram)** — if your project uses a database
- **Any criterion-specific diagrams** — sequence diagrams, deployment diagrams, etc.

Submissions without technical diagrams receive significantly lower evaluations from the committee.

---

## Important

All documents must be ready **before the defense date**. They must follow the requirements described in the corresponding sections of the documentation.

> **Note:** The demo video and live deployment must be ready **before the pre-defense**, not just the final defense. The pre-defense committee evaluates these items.
