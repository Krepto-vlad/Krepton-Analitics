# Deliverables Section — Improvement Plan

## Current vs. Proposed Page Order

| # | Current Order | Proposed Order | Reason |
|---|--------------|----------------|--------|
| 1 | Thesis Guide | **Official Requirements** | Students must understand formal formatting rules before writing anything. This is the "read the rules" step. |
| 2 | Official Requirements | **Review Templates** | Knowing what reviewers evaluate helps students focus their work from the start. Early awareness of evaluation criteria. |
| 3 | Presentation Requirements | **Video Requirements** | Video has the earliest hard deadline — must be ready **before pre-defense**. Students need to plan recording while the app is stable. |
| 4 | Video Requirements | **Presentation Requirements** | Presentation is needed for both pre-defense and final defense. Students often refine it after pre-defense feedback. |
| 5 | Review Templates | **Thesis Guide** | The thesis documentation is the largest deliverable and the last one students finalize. The guide walks through the full writing process — most useful when students are ready to compile everything. |

## Timeline Dependencies

```
Official Requirements ──→ Review Templates ──→ Video Requirements ──→ Presentation Requirements ──→ Thesis Guide
  (read rules)            (know evaluation)     (record before          (create for                  (finalize
                                                  pre-defense)            pre-defense)                 documentation)
```

- **Official Requirements** depends on: nothing (pure reference)
- **Review Templates** depends on: nothing (pure reference, but benefits from knowing official rules)
- **Video Requirements** depends on: working application (external), benefits from knowing what reviewers look for
- **Presentation Requirements** depends on: working application, video exists for reference
- **Thesis Guide** depends on: all above (references official formatting, criteria from review templates, includes video/presentation in submission archive)

## Planned Content Changes Per File

### 1. official-requirements.md (Step 1 of 5)
- Add step position indicator at top
- Add `!!! warning` admonition for the key insight (reviewers judge ONLY from this document)
- Restructure into What → Why → How flow
- Add cross-links to: thesis-guide.md, review-templates.md
- Simplify language
- Add "Next steps" section

### 2. review-templates.md (Step 2 of 5)
- Add step position indicator at top
- Expand content: explain the purpose of each review type, what reviewers look for
- Add `!!! tip` for pre-filling the template
- Add `!!! info` explaining the timeline for when reviews happen
- Cross-link to: review-process.md (section 06), official-requirements.md
- Add "Next steps" section

### 3. video-requirements.md (Step 3 of 5)
- Add step position indicator at top
- Add `!!! warning` for the pre-defense deadline
- Move production tips into `??? note` collapsible sections (optional/advanced detail)
- Simplify language throughout
- Add cross-links to: presentation-requirements.md, defense-preparation.md
- Add "Next steps" section

### 4. presentation-requirements.md (Step 4 of 5)
- Add step position indicator at top
- Add TL;DR summary box (page is long)
- Move detailed per-slide specs into collapsible sections
- Add `!!! warning` for common mistakes
- Simplify language — shorter sentences, active voice
- Add cross-links to: video-requirements.md, thesis-guide.md, defense-preparation.md
- Add "Next steps" section

### 5. thesis-guide.md (Step 5 of 5)
- Add step position indicator at top
- Add TL;DR summary box
- Move PDF generation options into content tabs (`=== "VS Code"` / `=== "Pandoc"` / `=== "MkDocs"`)
- Move FAQ into `??? note` collapsible items
- Simplify language throughout
- Move submission format details into collapsible section
- Add cross-links to: official-requirements.md, review-templates.md, final-deliverables-checklist.md
- Add "Next steps" section pointing to Section 6

### 6. mkdocs.yml
- Reorder Deliverables nav entries to match new timeline order
- No other changes needed

### 7. index.md (site home)
- Update reading path link for Section 5 to point to new first page (official-requirements.md)

### 8. Cross-link fixes
- Update all `<!-- prev: ... | next: ... -->` comments in affected files
- Update prev/next links in Section 04 last file (machine-learning.md → now points to official-requirements.md)
- Update prev/next links in Section 06 first file (final-deliverables-checklist.md → now points from thesis-guide.md)

## Terminology Standardization

| Current (inconsistent) | Standardized Term |
|----------------------|-------------------|
| "thesis document", "explanatory note", "пояснительная записка" | **thesis document** (with "(пояснительная записка)" on first use only) |
| "supervisor", "advisor", "научный руководитель" | **supervisor** (with "(научный руководитель)" on first use only) |
| "reviewer", "external expert", "рецензент" | **independent reviewer** (with "(рецензент)" on first use only) |
| "pre-defense", "предзащита" | **pre-defense** (with "(предзащита)" on first use only) |
| "criteria", "checkmarks", "complexity items" | **evaluation criteria** |

## Execution Log

| Step | Status | Notes |
|------|--------|-------|
| Read all files + mkdocs.yml | Done | — |
| Build timeline map | Done | See table above |
| Update mkdocs.yml | Done | Nav reordered, docs-improvement-plan.md added to exclude_docs |
| Rewrite official-requirements.md | Done | Step 1 of 5. Added warning admonition, step indicator, cross-links, next steps |
| Rewrite review-templates.md | Done | Step 2 of 5. Expanded content, added timeline info admonition, pre-fill tip, cross-links |
| Rewrite video-requirements.md | Done | Step 3 of 5. Added deadline warning, collapsible production tips, content tabs for examples, do/don't table |
| Rewrite presentation-requirements.md | Done | Step 4 of 5. Added TL;DR box, collapsible slide-by-slide details, common mistake warning |
| Rewrite thesis-guide.md | Done | Step 5 of 5. Added TL;DR box, content tabs for PDF generation, collapsible FAQ, ADR tip admonition |
| Fix cross-links | Done | Updated machine-learning.md next link, final-deliverables-checklist.md prev link, index.md reading path |
| Final verification | Done | `mkdocs build --strict` passes, all prev/next chains verified |
