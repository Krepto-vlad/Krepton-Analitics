# Onboarding Research

## Timeline Map

| Stage | When | Pages | Student Needs | Teacher/Admin Needs |
|-------|------|-------|---------------|---------------------|
| 1. Topic Selection | Weeks 1-2 | course-overview, project-types-and-criteria, team-rules, supervisor-role, topic-changes | Understand project types, select 7+ criteria, find supervisor, verify no prohibited topics | Verify criteria selection, sign application |
| 2. Topic Approval | Week 3 | diploma-lifecycle | Await admin decision (expulsion if rejected) | Review applications, approve/reject topics |
| 3. Plan & Start Building | Weeks 4-6 | All 17 technical requirement pages, thesis-guide | Set up repo, start coding, Progress Review 1 | Weekly standups, track progress |
| 4. Build & Get Assessed | Weeks 7-15 | expert-assessment, booking-slots, timeline | Book expert slots, submit materials 1 week early, Progress Reviews 2-3, complexity check at Week 10 | Run expert assessments (max 2 meetings), grade on 10-point scale, complexity warning at checkpoint 2 |
| 5. Prepare Deliverables | Weeks 16-18 | video-requirements, presentation-requirements, official-requirements | Record video, create presentation, write thesis, deploy app, Progress Review 4 | Proofread thesis (5 days before pre-defense), sign admission |
| 6. Pre-Defense | Week 19 | defense-preparation, review-templates | Present to committee, get reviewer contact | Organize pre-defense (2 weeks notice), provide reviewer contacts within 3 days |
| 7. Final Defense | Weeks 20-22 | final-deliverables-checklist, review-process, repository-upload | Get reviews, upload to talpykla.elaba.lt, defend | Confirm reviews received, organize final defense, collect materials |

## Content Gaps

1. **No role-based entry points** — Students and staff share the same landing page with no guidance for who should read what
2. **Hidden pages** — `timeline.md` and `admin-guide.md` exist but are not in the nav
3. **No "you are here" indicators** — Pages have invisible `<!-- prev/next -->` comments but no visible stage/progress context
4. **No consolidated staff reference** — Supervisor duties spread across supervisor-role.md, expert-assessment.md, diploma-lifecycle.md; admin duties only in admin-guide.md (hidden)
5. **No journey overview** — Students must read all 34 chapters linearly; no way to see which stage they're in or skip ahead
6. **No prerequisite indicators** — Pages don't show what must be done before the page becomes relevant
7. **Mermaid not configured** — Cannot use diagram-based journey maps without adding custom_fences config

## Brainstorm Results

### Discovery Findings
- 22-week semester, 6 sections, 34 chapters, ~106 min total read time
- 3 audience types: students (primary), supervisors/experts, administrators
- Strong sequential content but no role-based filtering
- Confirmed MkDocs extensions: tabbed, details, admonition, tasklist, emoji, tables

### Approaches Considered
1. **Role-based landing pages + stage badges** (CHOSEN) — 2 new pages + badges on all existing pages
2. **Single onboarding hub page** — One page with role tabs; too long for the content volume
3. **Section-level onboarding boxes** — No new pages, distributed onboarding; lacks consolidated journey view

### Design Approved
- `student-journey.md` — 7-stage journey map with collapsible checklists, all 17 criteria grouped
- `staff-guide.md` — Tabbed page (Supervisor/Expert | Administrator) with responsibility matrices
- Stage badges on ~30 existing pages — admonition with stage number, role tags, prerequisites, navigation
- Nav updates — add both new pages + unhide timeline.md and admin-guide.md
- Landing page update — role-based entry links on index.md

See `docs/plans/2026-03-01-onboarding-design.md` for full design specification.

## What Was Built

### New Pages
1. **`student-journey.md`** — 7-stage journey map with collapsible checklists, all 17 criteria grouped by category, prerequisite indicators, and navigation links
2. **`staff-guide.md`** — Tabbed guide (Supervisor/Expert | Administrator) with responsibility matrices, key obligation callouts, communication checklist, and decision authority table

### Stage Badges Added
Added `!!! abstract` admonitions to 31 existing content pages:
- 5 pages tagged Stage 1 (Topic Selection, Weeks 1-2)
- 1 page tagged Stage 2 (Topic Approval, Week 3)
- 18 pages tagged Stage 3 (Build & Get Assessed, Weeks 4-18) — 17 technical requirements + thesis guide
- 3 pages tagged Stage 4 (Build & Get Assessed, Weeks 7-15) — expert assessment, booking slots, timeline
- 3 pages tagged Stage 5 (Prepare Deliverables, Weeks 16-18)
- 2 pages tagged Stage 6 (Pre-Defense, Week 19)
- 3 pages tagged Stage 7 (Final Defense, Weeks 20-22)
- 1 page tagged All Stages (admin guide)

Each badge includes: stage number, role-specific guidance (:mortar_board: Students / :school: Staff), prerequisites, and prev/next navigation links with a "Full Journey" link back to student-journey.md.

### Navigation Changes
- Added Student Journey and Staff Guide to "Getting Started" tab in mkdocs.yml
- Timeline and Admin Guide were already in "Process and Timeline" tab
- Added role-based entry tip box to landing page (index.md)

### MkDocs Elements Used
- Content tabs (`=== "Tab"`) for role switching in staff guide
- Collapsible blocks (`??? success`) for stage details in student journey
- Admonitions (`!!! abstract`, `!!! warning`, `!!! danger`, `!!! tip`, `!!! info`) for badges and callouts
- Task lists (`- [ ]`) for checklists
- Tables for journey overview, criteria lists, and responsibility matrices
- Emoji (`:mortar_board:`, `:school:`, `:arrow_right:`, `:white_check_mark:`, `:x:`) for role tags and indicators

### Verification
- `mkdocs build --strict` passes with zero warnings
- All internal links resolve correctly
- Stage badges render with correct formatting on all pages
