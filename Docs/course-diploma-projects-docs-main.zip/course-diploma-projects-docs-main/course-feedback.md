# Course Feedback Report

*Based on pre-defense observations (Days 1-3) and instructor recommendations.*

## Summary

- **Total suggestions processed:** 19
- **Files affected:** 12
  - `05-deliverables/presentation-requirements.md`
  - `05-deliverables/video-requirements.md`
  - `06-defense-and-completion/defense-preparation.md`
  - `06-defense-and-completion/final-deliverables-checklist.md`
  - `03-process-and-timeline/diploma-lifecycle.md`
  - `03-process-and-timeline/expert-assessment.md`
  - `02-getting-started/supervisor-role.md`
  - `01-overview/project-types-and-criteria.md`
  - `04-technical-requirements/04e-infrastructure/microservices.md`
  - `04-technical-requirements/04a-business-and-docs/business-analysis.md`
  - `05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md`
  - `01-overview/course-overview.md`
- **New files needed:** 2
  - `03-process-and-timeline/timeline.md` (course timeline with key dates)
  - `03-process-and-timeline/admin-guide.md` (administration how-to)
- **Issues by type:** content gap (10), clarity (4), structure (3), accuracy (1), depth (1)

---

## Detailed Findings

---

### 1 — Missing "elevator pitch" across key documents

*Source: Day 1, Insight 1 (Critical); Day 2, Insight 2 (Critical)*

- **File:** `05-deliverables/presentation-requirements.md` (lines 28-35)
- **Type:** content gap
- **Current:**
  > ### Problem (1–2 slides)
  >
  > You must answer:
  > - What problem are you solving?
  > - Who has this problem? (target audience)
  > - Why is it important? (consequences of not solving)
  >
  > **Format:** Use pain points, statistics, or user quotes if available.

  No mention of an "elevator pitch" or the "why should someone buy/use this" framing. The concept exists in `defense-preparation.md` (line 6) and `business-analysis.md` (line 17, "Vision Statement like an elevator pitch"), but it is absent from the presentation requirements where students actually build their slides.

- **Proposed:** Replace the Problem section with a combined Elevator Pitch + Problem block:

  ```markdown
  ### Elevator Pitch + Problem (1–2 slides)

  **Slide 1 must open with a 30-second elevator pitch:**
  > "What does my application do — explained to a non-technical person? Why would someone want to use or buy it?"

  You must answer:
  - What problem are you solving? Show the **before** state (how things work without your product)
  - Who has this problem? (target audience)
  - Why is it important? (consequences of not solving — pain points, time/money lost, statistics)

  **Format:** Use a before/after comparison, pain-point statistics, or a real user quote. The committee must understand the product's value within the first 30 seconds.
  ```

- **Rationale:** The most consistent pre-defense finding was that students could not articulate product value. Embedding the elevator pitch requirement directly into the presentation structure — where students actually build slides — ensures it is not overlooked. The before/after framing (Day 2, Insight 2) makes value demonstration concrete.

---

### 2 — Presentation lacks purpose guidance (form vs. content)

*Source: Day 1, Insight 2 (Critical)*

- **File:** `05-deliverables/presentation-requirements.md` (lines 1-5)
- **Type:** clarity
- **Current:**
  > # Diploma Project Presentation Requirements
  >
  > ## Format
  >
  > | Parameter | Requirement |

  The document jumps directly into format and structure without explaining *why* the presentation exists and what it should accomplish. Students copy the slide structure mechanically without understanding its purpose.

- **Proposed:** Add a "Purpose" section immediately after the title:

  ```markdown
  # Diploma Project Presentation Requirements

  ## Purpose

  Your presentation is not a report — it is a **sales pitch for your engineering work**. The committee evaluates:

  1. **Can you explain your product's value?** (first 30 seconds)
  2. **Did you make informed technical decisions?** (not "I picked X because I had to")
  3. **Does the project work as a real product?** (live deployment, real data)

  Every slide must serve one of these goals. If a slide does not help you convince the committee, it does not belong in your main presentation.

  ---

  ## Format
  ```

- **Rationale:** Students treat the slide template as a checklist rather than a communication tool. An explicit "Purpose" section reframes the presentation as a persuasive argument, reducing mindless form-copying.

---

### 3 — Supervisor must review the latest version of the thesis

*Source: Day 1, Insight 3 (Important)*

- **File:** `02-getting-started/supervisor-role.md` (lines 36-38)
- **Type:** clarity
- **Current:**
  > ### Review the Explanatory Note
  >
  > - **Mandatory proofreading** of the explanatory note in English.
  >   - Check the structure, terminology, language, and logical flow.

  No mention of version control, deadlines for submission to the supervisor, or a mechanism ensuring the supervisor reviews the *current* version (not an outdated draft).

- **Proposed:**

  ```markdown
  ### Review the Explanatory Note

  - **Mandatory proofreading** of the explanatory note in English.
    - Check the structure, terminology, language, and logical flow.
  - The student must send the **final version** of the explanatory note to the supervisor **at least 5 working days** before the pre-defense.
  - The supervisor reviews and signs off on the submitted version. If the student makes changes after sign-off, a new review cycle is required.
  - **Versioning:** The supervisor should confirm which version (by date or commit hash) was reviewed.
  ```

- **Rationale:** Pre-defense revealed that supervisors sometimes reviewed outdated drafts. A clear submission deadline and version-tracking requirement prevents the gap between what was reviewed and what is presented.

---

### 4 — No timeline document exists

*Source: Day 1, Insight 4 (Important); Additional feedback ("Need to add timeline")*

- **File:** `03-process-and-timeline/diploma-lifecycle.md` (entire file)
- **Type:** content gap
- **Current:**
  > `diploma-lifecycle.md` describes stages (topic selection → approval → standups → progress reviews → expert submissions → pre-defense → final defense) but contains **no specific dates, week numbers, or calendar deadlines**. No separate timeline document exists anywhere in the repository.

- **Proposed:** Create a new file `03-process-and-timeline/timeline.md` with a week-by-week schedule:

  ```markdown
  <!-- prev: booking-slots.md | next: ../04-technical-requirements/04a-business-and-docs/business-analysis.md -->

  # Diploma Project Timeline

  ## Overview

  This timeline defines the key milestones and deadlines for the diploma project. All dates are approximate and will be confirmed by the administration at the start of each semester.

  ---

  ## Week-by-Week Schedule

  | Week | Milestone | Deliverable | Responsible |
  |------|-----------|-------------|-------------|
  | 1-2 | Topic selection and supervisor assignment | Signed application form | Student + Supervisor |
  | 3 | Topic approval by administration | Approved application | Administration |
  | 4-6 | Progress Review 1 (опроцентовка 1) | Initial prototype / architecture | Student → Supervisor |
  | 7-9 | Expert submissions begin | Materials sent to experts 1 week before slot | Student → Expert |
  | 10-12 | Progress Review 2 (опроцентовка 2) | Working MVP with core features | Student → Supervisor |
  | 13-15 | Progress Review 3 (опроцентовка 3) | Feature-complete build | Student → Supervisor |
  | 16-17 | **Video deadline** | Demo video (.mp4) finalized | Student |
  | 17-18 | Progress Review 4 (опроцентовка 4) | Final version, thesis draft complete | Student → Supervisor |
  | 18 | **Thesis submitted to supervisor** | Final explanatory note (5 working days before pre-defense) | Student → Supervisor |
  | 19 | **Pre-defense** | Presentation + deployed application + video | Student → Committee |
  | 20 | Reviews obtained | Supervisor review + independent review | Student |
  | 21 | Repository upload | Upload to talpykla.elaba.lt | Student |
  | 22 | **Final defense** | All deliverables complete | Student → Committee |

  > **Note:** The administration will publish exact dates at the beginning of each semester. This table shows the relative sequence and spacing.

  ---

  ## Critical Deadlines

  | Deadline | Rule |
  |----------|------|
  | Video | Must be completed **before** pre-defense |
  | Deployment | Application must be live and accessible **before** pre-defense |
  | Thesis to supervisor | At least **5 working days** before pre-defense |
  | Expert submissions | Materials sent **1 week** before the booked slot |
  | Review requests | Sent immediately after successful pre-defense |

  ---

  ## What Happens If You Miss a Deadline

  | Missed Deadline | Consequence |
  |-----------------|-------------|
  | Topic approval | Automatic expulsion |
  | Expert submission | Not admitted to assessment; may lose the slot |
  | Pre-defense materials | Not admitted to pre-defense |
  | Final defense materials | Not admitted to final defense |
  ```

  Also update `diploma-lifecycle.md` to add a cross-reference:

  ```markdown
  > For specific dates and week numbers, see [Timeline](timeline.md).
  ```

- **Rationale:** The absence of any timeline document was cited as a gap. Students and supervisors need a single reference for all deadlines to plan review cycles realistically.

---

### 5 — Research projects lack metrics guidance

*Source: Day 1, Insight 5 (Important)*

- **File:** `06-defense-and-completion/defense-preparation.md` (line 15-16)
- **Type:** depth
- **Current:**
  > ## Research Projects
  > Show your metrics and results.

  This is a two-line section with no guidance on *what* metrics to show, how to define success/failure for research projects, or how to present inconclusive results.

- **Proposed:**

  ```markdown
  ## Research Projects

  If your project is research-oriented (ML model, algorithm comparison, data analysis), you must present:

  - **Hypothesis or research question** — what you set out to prove or investigate
  - **Methodology** — how you structured the experiment (dataset, parameters, conditions)
  - **Baseline** — what the starting point or comparison benchmark was
  - **Results with metrics** — quantitative outcomes (accuracy, precision, F1, latency, throughput, etc.)
  - **Success/failure criteria** — define in advance what constitutes a successful outcome vs. a failed one
  - **Interpretation** — what the results mean and whether they support the hypothesis

  A negative result (hypothesis disproven) is acceptable **if** the methodology was sound and the analysis is thorough. Do not hide negative results — present them honestly and explain what you learned.
  ```

- **Rationale:** Pre-defense showed students with research projects could not articulate whether their results were good or bad. Explicit guidance on hypothesis, baseline, and success/failure criteria gives research-track students the same structural clarity that product-track students get from the feature checklist.

---

### 6 — Students justify criteria choices poorly ("I had to pick something")

*Source: Day 2, Insight 3 (Critical)*

- **File:** `05-deliverables/presentation-requirements.md` (lines 72-101)
- **Type:** clarity
- **Current:**
  > ### Evaluation Criteria (7 slides)
  >
  > You will prepare **one slide per criterion.** Each slide must include:
  > | Element | Description |
  > | **Why this approach** | 1–2 sentences on decision rationale |

  The "Why this approach" element exists but is not specific enough. Students interpret it as "why I used this technology" rather than "why this criterion was necessary for my product."

- **Proposed:** Rewrite the criteria slide guidance:

  ```markdown
  ### Evaluation Criteria (7 slides)

  You will prepare **one slide per criterion.** Each slide must include:

  | Element | Description |
  |---------|-------------|
  | **Criterion name** | Clear title |
  | **Business justification** | Why does your product **need** this? Link to a business requirement, user need, or architectural constraint — not "I had to choose 7 criteria" |
  | **What was implemented** | Key features/components (3–5 bullet points) |
  | **Technologies used** | Specific tools, libraries, frameworks |
  | **Diagram/Schema** | Visual representation (architecture, flow, schema, screenshot) |

  > **Common mistake:** Do not say "I chose this criterion because I needed 7 checkmarks." Instead, explain which business requirement or user problem demanded this technology. For example: "My application handles financial transactions from multiple regions, so I needed a database with ACID compliance and partitioning — this drove the Database criterion."

  **Example slide content:**
  ```
  Criterion: Database (OLTP)

  BUSINESS NEED: The platform processes 500+ orders/day with complex inventory
  relations — data integrity failures cost the business real money.

  WHAT:
  • PostgreSQL with 12 tables, 3NF normalized
  • Migrations via Flyway
  • Role-based access (app_read, app_write, admin)
  • Indexes on frequently queried columns

  TECH: PostgreSQL 15, Flyway, pgAdmin

  [ER Diagram]
  ```
  ```

- **Also update:** `05-deliverables/thesis-template/docs/02-technical/criteria/_template.md` (line 15) — change the Context prompt:

  **Current:**
  > [Describe the problem or requirement this criterion addresses. What forces are at play? What constraints exist?]

  **Proposed:**
  > [Describe the business requirement or user problem that made this criterion necessary for your project. Do not write "I chose this because I needed N checkmarks." Explain what product need or architectural constraint drove this decision. What forces are at play? What constraints exist?]

- **Rationale:** The most effective fix is to change the prompt text students encounter when writing. Explicit anti-patterns ("do not say X") address the exact behavior observed at pre-defense.

---

### 7 — No presentation strategy guidance (focus on strengths, not apologies)

*Source: Day 2, Insight 4 (Critical)*

- **File:** `06-defense-and-completion/defense-preparation.md` (entire file)
- **Type:** content gap
- **Current:** The file contains 6 short tips (elevator pitch, goals, database, research, speech, thesis document) but nothing about presentation *strategy* — how to structure the narrative, what to emphasize, and what to avoid.

- **Proposed:** Add a new section:

  ```markdown
  ## Presentation Strategy

  ### Focus on Strengths

  Lead with what you did well. The committee forms their impression in the first 2-3 minutes. If you open with apologies ("I didn't have time for...", "this part is incomplete..."), you set a negative frame that colors everything after it.

  **Do:**
  - Open with your elevator pitch and strongest feature
  - Show your best technical decisions with confidence
  - Present challenges as "Problem → Solution" stories
  - Acknowledge limitations briefly in the Results slide — don't dwell

  **Don't:**
  - Apologize for criteria you scored lower on
  - Say "I know this isn't great, but..."
  - Spend more time on what's missing than on what's done
  - Read your slides word for word

  ### Time Allocation

  Spend 70% of your time on your strongest 3-4 criteria and the product demo. Spend 30% on the remaining criteria. The committee will ask about weak areas in Q&A — that is the appropriate place to discuss limitations.
  ```

- **Rationale:** Students were observed apologizing for weak areas instead of showcasing strengths. This is a presentation skill gap, not a content gap — it requires explicit coaching in the preparation document.

---

### 8 — Deployment must be a blocker for defense admission

*Source: Day 3, Insight 1 (Blocker)*

- **File:** `06-defense-and-completion/final-deliverables-checklist.md` (lines 5-15)
- **Type:** content gap
- **Current:**
  > | # | Document | Description |
  > | 1 | **Thesis document** | ... |
  > | 2 | **Abstract** | ... |
  > | 3 | **Presentation** | ... |
  > | 4 | **Demo video** | ... |
  > | 5 | **Advisor report** | ... |
  > | 6 | **Review** | ... |

  No mention of a **live deployed application** as a required deliverable. Deployment requirements exist in `cloud.md` as a grading criterion, but they are not listed as a gate to defense admission.

- **Proposed:**

  ```markdown
  | # | Document | Description |
  |---|----------|-------------|
  | 1 | **Thesis document (пояснительная записка)** | A PDF file with the full text of your diploma project, formatted according to the requirements |
  | 2 | **Abstract** | A short summary of your work (usually 1 page) in English |
  | 3 | **Presentation** | Slides for the defense (PowerPoint, Google Slides, or PDF) |
  | 4 | **Demo video** | A video that shows how your application works (30 seconds – 2 minutes) |
  | 5 | **Advisor report** | Evaluation and comments from your academic advisor |
  | 6 | **Review** | Evaluation and comments from an independent reviewer |
  | 7 | **Live deployment** | Application accessible via a public URL. Must be running at the time of defense. **No deployment = not admitted to defense.** |

  ---

  ## Blockers

  The following items are **hard blockers** — without them, you will not be admitted to the defense:

  | Blocker | Why |
  |---------|-----|
  | No live deployment | The committee must be able to open and use your application during the defense |
  | No demo video | Required for portfolio and institutional records |
  | No thesis document | The reviewer cannot write a review without it |
  ```

- **Also update:** `06-defense-and-completion/defense-preparation.md` — add a deployment check:

  ```markdown
  ## Deployment

  Your application **must** be deployed and accessible via a public URL before the pre-defense. This is a hard requirement, not optional. If your application is not deployed, you will not be admitted to the defense.

  - Verify the URL works from a different network (not your local machine)
  - Ensure the deployment will remain live through the final defense date
  - Have a backup plan (local demo) in case of cloud outage — but this does not replace the deployment requirement
  ```

- **Rationale:** Day 3 identified deployment as a blocker, but the course materials never state this explicitly as a gate condition. The checklist only mentions documents. Adding "live deployment" as item 7 and a separate "Blockers" table makes the requirement unambiguous.

---

### 9 — Video must be ready before pre-defense

*Source: Day 3, Insight 2 (Blocker)*

- **File:** `05-deliverables/video-requirements.md` (lines 109-137)
- **Type:** content gap
- **Current:**
  > ## Submission
  >
  > ### File Delivery
  >
  > Upload to Google Drive and include in your final submission archive:

  No deadline is specified for the video. The submission section only describes the file format and delivery method, not *when* it must be completed. `final-deliverables-checklist.md` says "before the defense date" — which students interpret as the *final* defense, not the pre-defense.

- **Proposed:** Add a deadline section to `video-requirements.md`:

  ```markdown
  ## Deadline

  > Your demo video must be completed and accessible **before the pre-defense**, not before the final defense.

  The pre-defense committee uses the video as part of their evaluation. If you do not have a finished video at the time of pre-defense, you may not be admitted.

  Plan to finish recording and editing your video **at least 1 week before the pre-defense** to allow time for review and re-recording if needed.
  ```

  Also update `06-defense-and-completion/final-deliverables-checklist.md`:

  ```markdown
  ## Important

  All documents must be ready **before the defense date**. They must follow the requirements described in the corresponding sections of the documentation.

  > **Note:** The demo video and live deployment must be ready **before the pre-defense**, not just the final defense. The pre-defense committee evaluates these items.
  ```

- **Rationale:** Day 3 identified that students arrive at pre-defense without a video. The video requirements document has no deadline, and the checklist is ambiguous about which defense it refers to.

---

### 10 — Rate limiting should be mandatory for Microservices criterion

*Source: Day 3, Insight 3*

- **File:** `04-technical-requirements/04e-infrastructure/microservices.md` (lines 89-95)
- **Type:** accuracy
- **Current:**
  > Rate limiting appears only under **Direction 2: Resilience Patterns** in the Maximum Requirements section (line 93):
  > - Rate limiting between services

  It is not mentioned anywhere in the Minimum Requirements (lines 12-73).

- **Proposed:** Add rate limiting to the Minimum Requirements under "Communication" (after line 36):

  ```markdown
  **Communication:**
  - Synchronous: REST API or gRPC between services
  - Clear interaction contracts (versioned APIs)
  - Timeouts and retry policies for all calls
  - Handling of unavailable dependent services
  - **Rate limiting** on API Gateway or service entry points (basic request throttling to prevent cascade failures)
  ```

  Update the "API Gateway or entry point" section (after line 51):

  ```markdown
  **API Gateway or entry point:**
  - Single entry point for external clients
  - Request routing to services
  - Basic authentication/authorization
  - Rate limiting (requests per second/minute per client)
  ```

- **Rationale:** In a microservice architecture, rate limiting is a fundamental protection against cascade failures. Moving it from "advanced" to "minimum" aligns with industry practice where any production-grade distributed system requires basic rate limiting.

---

### 11 — Criteria are help, not guarantee — communicate purpose

*Source: General feedback, item 1*

- **File:** `01-overview/project-types-and-criteria.md` (lines 40-46)
- **Type:** clarity
- **Current:**
  > ## How a "Complete Diploma" Is Calculated
  >
  > | Level | Min. total checkmarks | Restrictions |
  > | **Standard** | 7 | You need at least 1 from each category ... |
  > | **Team** | 10 | When working in a team, each student must choose their own 5 checkmarks |

  The section describes the *mechanics* of checkmark counting but does not explain the *purpose* or communicate that meeting criteria is a minimum threshold, not a guarantee.

- **Proposed:** Add a framing paragraph before the table:

  ```markdown
  ## How a "Complete Diploma" Is Calculated

  The complexity criteria exist to help you verify that your project is sufficiently complex for a diploma. Think of them as a **minimum threshold**, not a guarantee:

  - **If your project does not meet the criteria** → it will not be admitted to the defense (with rare exceptions).
  - **If your project meets the criteria** → it satisfies the minimum complexity requirement, but admission also depends on implementation quality, defense performance, and expert evaluations.

  > Meeting all checkmarks is necessary but not sufficient for a successful defense.

  | Level | Min. total checkmarks | Restrictions |
  ```

- **Rationale:** The instructor explicitly noted that students misunderstand the criteria system — they believe meeting checkmarks guarantees admission. A clear "necessary but not sufficient" statement sets expectations early.

---

### 12 — Complexity assessment should evaluate component difficulty, not just completion

*Source: General feedback, item 2*

- **File:** `03-process-and-timeline/expert-assessment.md` (lines 33-38)
- **Type:** content gap
- **Current:**
  > ## Grading and Pass/Fail
  >
  > - After the meeting:
  >   - A **grade on a 10-point scale** is assigned.
  >   - The item is marked as **passed or not passed**.
  >   - If the grade is **below 5** or the item is **not passed**: You **are not admitted** to the final diploma defense.

  The grading system evaluates whether a component is *done* and assigns a grade, but there is no concept of **overall project complexity scoring**. A student can complete the required number of components at a shallow level and still technically pass all gates.

- **Also relevant:** `01-overview/project-types-and-criteria.md` — the checkmark system counts criteria but not their depth.

- **Proposed:** Add to `03-process-and-timeline/expert-assessment.md`:

  ```markdown
  ## Complexity Evaluation

  In addition to individual criterion grades, the pre-defense committee evaluates the **overall project complexity**. This considers:

  - **Depth of each component** — a criterion implemented at a basic level contributes less to overall complexity than one implemented with advanced patterns
  - **Integration complexity** — how components interact and whether the system demonstrates real distributed/full-stack behavior
  - **Novelty** — whether the project goes beyond tutorial-level implementations

  A project that passes all individual criteria at minimum level but lacks overall complexity may not be admitted to the final defense. The pre-defense committee makes this determination.

  > This applies particularly to non-standard projects (e.g., a framework or library with no frontend) where the depth of a single domain may compensate for missing breadth.
  ```

  Also add to `01-overview/project-types-and-criteria.md` after the checkmarks table:

  ```markdown
  > **Important:** Checkmarks measure breadth (how many areas you cover). The pre-defense committee also evaluates **depth** (how complex each component is). A project with 7 checkmarks at surface level may still be deemed insufficient. Conversely, a highly specialized project (e.g., a Rust framework) with fewer UI components but deep backend complexity may be accepted — discuss with your supervisor early.
  ```

- **Rationale:** The instructor described a case where a student met the checkmark count but had insufficient overall complexity. The current system cannot catch this because it only measures breadth. Adding a complexity dimension allows the committee to evaluate non-standard projects fairly.

---

### 13 — Early warning about insufficient project complexity

*Source: General feedback, item 3*

- **File:** `03-process-and-timeline/diploma-lifecycle.md` (lines 26-30)
- **Type:** content gap
- **Current:**
  > ### Working with Your Supervisor
  >
  > - Weekly standup meetings ...
  > - Reports follow the format: what was done, what is planned, blockers.
  > - You must pass 4 progress checkpoints (опроцентовки) ...

  No mention of complexity risk assessment at any stage. Students can reach pre-defense before learning their project is not complex enough.

- **Proposed:** Add complexity review to the progress checkpoints:

  ```markdown
  - You must pass 4 progress checkpoints (опроцентовки) — stages where your work is reviewed and accepted.
    - **At checkpoint 2 (midpoint)**, the supervisor must explicitly assess whether the project is on track to meet the required complexity level. If there is a risk that the project may not be complex enough for the diploma, the student must be informed **in writing** at this stage — not at pre-defense.
    - If the supervisor identifies a complexity risk, the student must either:
      - Add scope to increase complexity, or
      - Adjust the topic (see [Topic Changes](../02-getting-started/topic-changes.md))
  ```

- **Rationale:** Instructor feedback explicitly stated: "avoid the situation where it becomes a complete surprise for students that their project is not complex enough." The fix is to mandate a complexity check at the midpoint, not at the end.

---

### 14 — Pre-defense must be treated as seriously as final defense

*Source: General feedback, item 4*

- **File:** `03-process-and-timeline/diploma-lifecycle.md` (lines 42-46)
- **Type:** clarity
- **Current:**
  > ### Pre-defense and Final Defense
  >
  > - The pre-defense (предзащита) takes place with a working committee. After the pre-defense, you receive permission to proceed to the final defense and a referral for review.
  > - The review becomes available to you after a successful pre-defense. You need to get 2 reviews ...
  > - The final defense takes place with a committee and external experts.

  The pre-defense is described in neutral, administrative language. There is no emphasis on its importance or consequences of poor performance.

- **Proposed:**

  ```markdown
  ### Pre-defense and Final Defense

  - The **pre-defense (предзащита)** is a formal evaluation with a working committee. It carries the same weight as the final defense — treat it accordingly:
    - You must have a **deployed application**, **finished demo video**, and **complete presentation**
    - The committee evaluates your project's complexity, your ability to present, and your technical decisions
    - A poor pre-defense can result in **denial of admission** to the final defense
    - You may receive binding feedback that requires changes before the final defense
  - After a successful pre-defense, you receive permission to proceed to the final defense and a referral for review.
  - You need to get 2 reviews — one from your supervisor and one from an external expert.
  - The final defense takes place with a committee and external experts.
  ```

- **Rationale:** Instructors observed that early pre-defense slots had students who did not take the event seriously. Stronger language in the documentation sets the right expectations before students encounter the committee.

---

### 15 — Move criteria slides to appendix (optional), reduce mandatory count

*Source: General feedback, item 5*

- **File:** `05-deliverables/presentation-requirements.md` (lines 72-101, 137-150)
- **Type:** structure
- **Current:**
  > ### Evaluation Criteria (7 slides)
  >
  > You will prepare **one slide per criterion.**

  The current structure dedicates 7 out of 18-24 slides (33-39%) to individual criteria. This leaves little room for the narrative (problem, solution, demo). The instructor suggested moving detailed criteria to an appendix.

- **Proposed:** Restructure to focus the main presentation and move detail to appendix:

  ```markdown
  ### Evaluation Criteria — Summary (2–3 slides)

  Present your **top 3–4 strongest criteria** in the main presentation. For each:

  | Element | Description |
  |---------|-------------|
  | **Criterion name** | Clear title |
  | **Business justification** | Why your product needs this |
  | **Key implementation highlight** | The most interesting technical decision (1–2 bullet points) |
  | **Visual** | Diagram, screenshot, or code snippet |

  > Focus on criteria where you did the most interesting or complex work. Do not give equal time to all 7.

  ### Criteria Appendix (optional, 7 slides at the end)

  If required by the administration, prepare one slide per criterion in the appendix section of your presentation. These slides follow the full format (criterion name, rationale, implementation details, technologies, diagram) but are **not part of your spoken presentation** — they serve as reference material for the committee.

  **Updated slide count:**

  | Section | Slides |
  |---------|--------|
  | Title | 1 |
  | Elevator Pitch + Problem | 1–2 |
  | Solution | 1–2 |
  | Demo | 2–3 |
  | Architecture | 1–2 |
  | **Criteria (summary)** | **2–3** |
  | Challenges | 1 |
  | Results | 1 |
  | Q&A | 1 |
  | **Subtotal (spoken)** | **12–18** |
  | Criteria Appendix (optional) | 7 |
  | **Total** | **12–25** |
  ```

- **Rationale:** 7 criteria slides consume a disproportionate share of a 15-minute presentation, forcing students to rush through the most important sections (problem, demo, architecture). A summary approach lets students focus on their strongest work while keeping detailed criteria available as reference.

---

### 16 — Before/after problem demonstration in thesis template

*Source: Day 2, Insight 2 (Critical)*

- **File:** `05-deliverables/thesis-template/docs/01-project-overview/problem-and-goals.md` (lines 1-21)
- **Type:** content gap
- **Current:**
  > ## Problem Statement
  >
  > **Who:** [Target user/customer segment]
  > **What:** [The specific problem they face]
  > **Why:** [Why this problem matters and needs to be solved]

  The template asks students to describe the problem but does not prompt for a **before/after comparison** showing the value their solution creates.

- **Proposed:** Add a "Before/After" section after the Pain Points table:

  ```markdown
  ### Pain Points

  | # | Pain Point | Severity | Current Workaround |
  |---|------------|----------|-------------------|
  | 1 | [What frustrates users] | High/Medium/Low | [How they cope now] |
  | 2 | [What inefficiencies exist] | High/Medium/Low | [How they cope now] |
  | 3 | [What needs are unmet] | High/Medium/Low | [How they cope now] |

  ### Before / After

  Show the concrete difference your product makes:

  | Aspect | Before (without your product) | After (with your product) |
  |--------|-------------------------------|---------------------------|
  | [Key workflow or metric] | [Current state — slow, manual, error-prone] | [Improved state — fast, automated, reliable] |
  | [Key workflow or metric] | [Current state] | [Improved state] |
  | [Key workflow or metric] | [Current state] | [Improved state] |

  > This table should make the product's value obvious at a glance. Use specific numbers where possible (e.g., "30 min manual process → 2 min automated").
  ```

- **Rationale:** Day 2 observation: "students don't show the problem before/after — don't demonstrate value visually." Adding a structured before/after table to the thesis template ensures students articulate value concretely, which then feeds into both the thesis and the presentation.

---

### 17 — Admin-facing "how-to and when-to" guide

*Source: Additional feedback ("Need admin document")*

- **File:** (new file needed)
- **Type:** content gap
- **Current:** No document exists that addresses the administration's responsibilities, timeline of actions, or procedures. All existing documents are student-facing or supervisor-facing.

- **Proposed:** Create `03-process-and-timeline/admin-guide.md`:

  ```markdown
  <!-- prev: timeline.md | next: ../04-technical-requirements/04a-business-and-docs/business-analysis.md -->

  # Administration Guide — Diploma Project Process

  ## Purpose

  This document describes the administrative actions, responsibilities, and timing for managing the diploma project process.

  ---

  ## Key Responsibilities

  | Responsibility | When | Action |
  |---------------|------|--------|
  | Publish semester timeline | Semester start (week 1) | Post exact dates for all milestones in the timeline |
  | Topic approval | Week 2-3 | Review and approve/reject student applications |
  | Assign expert slots | After topic approval | Coordinate with experts to set assessment slots |
  | Monitor progress reviews | Weeks 4-17 | Verify supervisors conduct 4 progress checkpoints |
  | Organize pre-defense | Week 19 (per timeline) | Schedule rooms, committees, notify students |
  | Provide reviewer contacts | After successful pre-defense | Send reviewer contact to student |
  | Confirm review receipt | Before final defense | Verify both reviews (advisor + independent) received |
  | Organize final defense | Week 22 (per timeline) | Schedule rooms, committee, external experts |
  | Collect final materials | After defense | Confirm repository upload, archive deliverables |

  ---

  ## Decision Points

  | Decision | Who Decides | Criteria |
  |----------|-------------|----------|
  | Topic approval | Administration | Meets complexity requirements, no prohibited categories |
  | Admission to pre-defense | Supervisor | All criteria submitted to experts, thesis draft reviewed |
  | Admission to final defense | Pre-defense committee | Project complexity sufficient, presentation adequate, deployment live |
  | Final grade | Defense committee | Cumulative evaluation of all components |

  ---

  ## Communication Checklist

  - [ ] Timeline published and distributed to all students, supervisors, and experts
  - [ ] Expert assessment slots announced with sign-up instructions
  - [ ] Pre-defense schedule sent at least 2 weeks in advance
  - [ ] Reviewer contacts distributed within 3 working days of successful pre-defense
  - [ ] Final defense schedule confirmed at least 2 weeks in advance
  ```

- **Rationale:** The instructor explicitly requested an admin-facing guide. Currently, all process documentation assumes the reader is a student or supervisor, leaving administrative procedures undocumented and inconsistent.

---

### 18 — BA criterion should be mandatory with committee defense

*Source: Additional feedback*

- **File:** `04-technical-requirements/04a-business-and-docs/business-analysis.md` (lines 1-9)
- **Type:** structure
- **Current:**
  > # Business Analysis Requirements for Passing the BA Stage of Diploma Preparation
  >
  > You will use this document to understand what is expected of you to pass the BA stage of diploma preparation.

  BA is currently listed as a regular criterion that students may or may not choose. There is no indication it is (or should be) mandatory or that it requires committee-level defense.

- **Also relevant:** `01-overview/project-types-and-criteria.md` (lines 19-36) — BA is not listed in the complexity criteria table at all. It exists only as a separate assessment document.

- **Proposed:** Add to `04-technical-requirements/04a-business-and-docs/business-analysis.md`:

  ```markdown
  # Business Analysis Requirements for Passing the BA Stage of Diploma Preparation

  > **Status: Mandatory criterion.** Unlike other criteria, Business Analysis must be completed and defended before a committee — not just with an individual expert. This is a prerequisite for continuing with the diploma project.

  > **Topic change policy:** After successfully defending the BA criterion, you may change your project topic. If you change your topic, you must re-defend the BA criterion for the new topic.

  You will use this document to understand what is expected of you to pass the BA stage of diploma preparation.
  ```

  Update `01-overview/project-types-and-criteria.md` to mark BA as mandatory:

  ```markdown
  | **Business Analysis** (required) | vision, problem, stakeholders, scope, features — **defended before committee** |
  ```

- **Rationale:** The instructor recommended making BA mandatory with committee defense. This ensures every student has a validated business case before proceeding to technical implementation, preventing the "I chose criteria without business justification" problem observed on Day 2.

---

### 19 — Need for a "pre-pre-defense" checkpoint

*Source: Day 2, Insight 1 (Discuss)*

- **File:** `03-process-and-timeline/diploma-lifecycle.md` (lines 26-30)
- **Type:** structure
- **Current:** The lifecycle includes 4 progress checkpoints and 1 pre-defense, but no intermediate formal checkpoint where students present to a committee before the pre-defense.

- **Proposed:** This was flagged as "for discussion" (🟡), not as an actionable requirement. However, the related suggestions (early complexity warning at checkpoint 2, BA defense before committee) effectively create the "pre-pre-defense" through existing mechanisms. Specifically:

  - **Checkpoint 2 complexity review** (Finding #13) — serves as an early project viability check
  - **BA committee defense** (Finding #18) — serves as a mandatory presentation milestone before pre-defense
  - **Video deadline before pre-defense** (Finding #9) — forces earlier preparation

  **Recommendation:** Rather than adding a formal "pre-pre-defense" event, implement findings #9, #13, and #18. Together, they create multiple earlier checkpoints that address the underlying concern. Revisit after one semester — if students still arrive at pre-defense unprepared, formalize a mid-semester committee review.

- **Rationale:** Adding another formal event increases administrative burden. The three specific fixes above address the root causes (late complexity discovery, no formal BA gate, no video deadline) more surgically.

---

## Cross-Cutting Observations

### Navigation links need updating

If new files are created (`timeline.md`, `admin-guide.md`), the `<!-- prev: ... | next: ... -->` comment chain must be updated across affected files. Specifically:

- `booking-slots.md` currently points `next:` to `business-analysis.md` — this should point to `timeline.md`
- `timeline.md` should point `next:` to `admin-guide.md` (or directly to the technical requirements, depending on reading order)
- `README.md` Section 3 table needs new rows for the timeline and admin guide

### Consistency of "blocker" language

The term "blocker" is used informally in Day 3 feedback but does not appear in any course document. Consider establishing a formal vocabulary:

| Term | Meaning |
|------|---------|
| **Blocker** | Missing this item = not admitted to defense |
| **Required** | Must be completed but failure is graded, not blocking |
| **Recommended** | Best practice but not enforced |

### File count impact

Implementing all findings adds 2 new files and modifies 12 existing files. No files are deleted.
