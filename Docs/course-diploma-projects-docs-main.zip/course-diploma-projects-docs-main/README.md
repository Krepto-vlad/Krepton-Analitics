# Diploma Project Documentation — Learning Path

This knowledge base contains all course documentation for the diploma project, organized as a progressive learning arc. Start at Section 1 and work forward; each section builds on the ones before it.

---

## Section 1: Overview

Understand what this course covers, which project types are accepted, and how complexity criteria work.

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 1 | [Course Overview](01-overview/course-overview.md) | 3 min | None |
| 2 | [Project Types and Criteria](01-overview/project-types-and-criteria.md) | 3 min | None |

---

## Section 2: Getting Started

Form your team, choose a supervisor, select a topic, and understand topic change rules.

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 3 | [Team Rules](02-getting-started/team-rules.md) | 1 min | Section 1 |
| 4 | [Supervisor Role](02-getting-started/supervisor-role.md) | 2 min | Section 1 |
| 5 | [Topic Changes](02-getting-started/topic-changes.md) | 1 min | Section 1 |

---

## Section 3: Process and Timeline

Walk through the full diploma lifecycle — milestones, expert assessments, and slot booking.

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 6 | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) | 2 min | Section 2 |
| 7 | [Expert Assessment](03-process-and-timeline/expert-assessment.md) | 1 min | Section 2 |
| 8 | [Booking Slots](03-process-and-timeline/booking-slots.md) | 1 min | Section 2 |
| 9 | [Timeline](03-process-and-timeline/timeline.md) | 2 min | Section 2 |
| 10 | [Administration Guide](03-process-and-timeline/admin-guide.md) | 2 min | Section 2 |

---

## Section 4: Technical Requirements

Grading rubrics for all 17 discipline criteria, organized by domain. Each file defines minimum (grade 5) and maximum (grade 10) requirements.

### 4A: Business Analysis and Documentation

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 11 | [Business Analysis](04-technical-requirements/04a-business-and-docs/business-analysis.md) | 4 min | Sections 1-3 |
| 12 | [API Documentation](04-technical-requirements/04a-business-and-docs/api-documentation.md) | 4 min | Sections 1-3 |

### 4B: Data Layer

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 13 | [Database](04-technical-requirements/04b-data-layer/database.md) | 6 min | Sections 1-3 |
| 14 | [Real-time Analytics](04-technical-requirements/04b-data-layer/real-time-analytics.md) | 3 min | Sections 1-3 |

### 4C: Backend

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 15 | [Backend](04-technical-requirements/04c-backend/backend.md) | 8 min | Sections 1-3 |

### 4D: Frontend and UX/UI

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 16 | [Frontend](04-technical-requirements/04d-frontend-and-ux/frontend.md) | 3 min | Sections 1-3 |
| 17 | [Adaptive UI](04-technical-requirements/04d-frontend-and-ux/adaptive-ui.md) | 3 min | Sections 1-3 |
| 18 | [Refined UX](04-technical-requirements/04d-frontend-and-ux/refined-ux.md) | 4 min | Sections 1-3 |

### 4E: Infrastructure and DevOps

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 19 | [CI/CD](04-technical-requirements/04e-infrastructure/cicd.md) | 4 min | Sections 1-3 |
| 20 | [Containerization](04-technical-requirements/04e-infrastructure/containerization.md) | 4 min | Sections 1-3 |
| 21 | [Cloud](04-technical-requirements/04e-infrastructure/cloud.md) | 3 min | Sections 1-3 |
| 22 | [Microservices](04-technical-requirements/04e-infrastructure/microservices.md) | 3 min | Sections 1-3 |

### 4F: Testing and Quality

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 23 | [Auto Tests](04-technical-requirements/04f-testing/auto-tests.md) | 4 min | Sections 1-3 |
| 24 | [Testing](04-technical-requirements/04f-testing/testing.md) | 4 min | Sections 1-3 |

### 4G: Specialized Domains

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 25 | [AI Assistant](04-technical-requirements/04g-specialized/ai-assistant.md) | 6 min | Sections 1-3 |
| 26 | [Cryptography](04-technical-requirements/04g-specialized/cryptography.md) | 3 min | Sections 1-3 |
| 27 | [Machine Learning](04-technical-requirements/04g-specialized/machine-learning.md) | 4 min | Sections 1-3 |

---

## Section 5: Deliverables

Exactly what you must produce: thesis documentation, presentation, demo video, and review forms.

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 28 | [Thesis Guide](05-deliverables/thesis-guide.md) | 8 min | Sections 3-4 |
| 29 | [Official Requirements](05-deliverables/official-requirements.md) | 1 min | Chapter 28 |
| — | [Official Rules PDF](05-deliverables/official-rules.pdf) | — | Chapter 29 |
| 30 | [Presentation Requirements](05-deliverables/presentation-requirements.md) | 4 min | Section 3 |
| 31 | [Video Requirements](05-deliverables/video-requirements.md) | 4 min | Section 3 |
| 32 | [Review Templates](05-deliverables/review-templates.md) | 1 min | Chapters 28, 30, 31 |

The complete thesis template is available at [`05-deliverables/thesis-template/`](05-deliverables/thesis-template/) (22 files — copy this directory to start your documentation).

---

## Section 6: Defense and Completion

Final steps: deliverables checklist, obtaining reviews, repository upload, and defense preparation.

| # | Chapter | Reading Time | Prerequisites |
|---|---------|-------------|---------------|
| 33 | [Final Deliverables Checklist](06-defense-and-completion/final-deliverables-checklist.md) | 1 min | Section 5 |
| 34 | [Review Process](06-defense-and-completion/review-process.md) | 1 min | Chapters 32, 33 |
| 35 | [Repository Upload](06-defense-and-completion/repository-upload.md) | 1 min | Chapter 33 |
| 36 | [Defense Preparation](06-defense-and-completion/defense-preparation.md) | 1 min | Chapters 33, 34, 35 |

---

## Total Reading Time

| Section | Chapters | Time |
|---------|----------|------|
| 1. Overview | 2 | 6 min |
| 2. Getting Started | 3 | 4 min |
| 3. Process and Timeline | 5 | 8 min |
| 4. Technical Requirements | 17 | 70 min |
| 5. Deliverables | 5 + template | 18 min |
| 6. Defense and Completion | 4 | 4 min |
| **Total** | **36 + template** | **~110 min** |
