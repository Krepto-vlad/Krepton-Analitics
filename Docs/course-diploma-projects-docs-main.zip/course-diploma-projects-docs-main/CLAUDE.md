# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a **diploma project knowledge base** for a course. MkDocs Material serves the **entire repository** as a documentation site (`docs_dir: .` in `mkdocs.yml`), with 7 navigation tabs covering all sections:

1. **Root knowledge base** (sections `01-06`) — course requirements, grading rubrics, organizational procedures, and deliverable specs.
2. **Thesis template** (`05-deliverables/thesis-template/`) — nested under the Deliverables tab. Students copy this directory into their own repos to document their diploma projects.

All content must be in **English**.

## Key Commands

```bash
# Install dependencies
pip install mkdocs-material pymdown-extensions mkdocs-same-dir

# Serve full knowledge base locally with hot reload
mkdocs serve

# Build full knowledge base static site to site/
mkdocs build

# Generate combined PDF via pandoc (requires pandoc + xelatex)
pandoc 05-deliverables/thesis-template/docs/**/*.md -o dist/diploma-docs-full.pdf \
  --pdf-engine=xelatex --toc \
  -V mainfont="Noto Sans" -V monofont="Noto Sans Mono" -V geometry:margin=2.5cm
```

## Architecture

### Root Knowledge Base (sections `01-06`)

Six numbered sections form a progressive learning path (see `README.md` for the full reading order):

- **`01-overview/`** — Course overview, project types, complexity criteria
- **`02-getting-started/`** — Topic selection, supervisor role, team rules
- **`03-process-and-timeline/`** — Diploma lifecycle, expert assessments, booking slots
- **`04-technical-requirements/`** — Grading rubrics for 17 disciplines, in subdirectories: `04a-business-and-docs`, `04b-data-layer`, `04c-backend`, `04d-frontend-and-ux`, `04e-infrastructure`, `04f-testing`, `04g-specialized`
- **`05-deliverables/`** — Thesis guide, official requirements, presentation/video specs, review templates, plus the `thesis-template/` subfolder
- **`06-defense-and-completion/`** — Final checklist, defense registration, review process, repository upload

### MkDocs Site Structure

`docs_dir: .` serves the entire repo. The `nav` in `mkdocs.yml` defines 7 top-level tabs:

- **Home** — `index.md` (landing page with reading path)
- **Overview** — `01-overview/` (2 files)
- **Getting Started** — `02-getting-started/` (3 files)
- **Process and Timeline** — `03-process-and-timeline/` (3 files)
- **Technical Requirements** — `04-technical-requirements/` (17 files, grouped 04a–04g)
- **Deliverables** — `05-deliverables/` (5 files) + **Thesis Template** subsection (`05-deliverables/thesis-template/docs/`, 17 files)
- **Defense and Completion** — `06-defense-and-completion/` (4 files)

`exclude_docs` in `mkdocs.yml` skips `.git/`, `.github/`, `.claude/`, `.idea/`, `site/`, `dist/`, `CLAUDE.md`, and `README.md`.

### Content Relationship

`04-technical-requirements/` defines the **grading rubrics** (what examiners evaluate). Students then write **self-evaluations** against those rubrics in `05-deliverables/thesis-template/docs/02-technical/criteria/` using the ADR template at `criteria/_template.md`.

## CI/CD

Two GitHub Actions workflows in `.github/workflows/`:

- **`deploy-pages.yml`** — Deploys the full knowledge base MkDocs site to GitHub Pages on push to `main`
- **`build-pdf.yml`** — On GitHub Release publish: builds individual PDFs per page + a combined PDF, uploads all as release assets

## Conventions

- Files are linked sequentially via comments at the top: `<!-- prev: ../path/prev-file.md | next: ../path/next-file.md -->`
- Each technical requirement file in `04-technical-requirements/` defines minimum (grade 5) and maximum (grade 10) criteria
- Thesis template evaluation criteria use ADR format (Status, Context, Decision, Alternatives Considered, Consequences)
- Status indicators: ✅ (fully implemented), ⚠️ (partial), ❌ (not implemented)
- Template placeholders use `[bracket notation]` — all must be replaced before submission
