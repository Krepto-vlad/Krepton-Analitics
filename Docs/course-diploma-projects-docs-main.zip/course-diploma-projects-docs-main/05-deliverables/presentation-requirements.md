<!-- prev: video-requirements.md | next: thesis-guide.md -->

!!! abstract "Stage 5 of 7 — Prepare Deliverables | Weeks 16–18"
    :mortar_board: **Students:** Create your defense presentation. 12–18 slides + appendix. Lead with your elevator pitch.

    :school: **Staff:** Presentation quality requirements and slide structure.

    **Prerequisites:** Video recorded. Architecture clear. Key features implemented.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Presentation Requirements

**Step 4 of 5** in the Deliverables section. You should have your [demo video](video-requirements.md) ready from the previous step.

!!! info "TL;DR"
    12–18 spoken slides + up to 7 appendix slides. Format: `.pptx` or `.pdf`, 16:9, English. Your presentation is a sales pitch for your engineering work — every slide must prove your product's value, your technical decisions, or that the project works as a real product.

---

## Purpose

Your presentation is not a report. It is a **sales pitch for your engineering work**. The committee evaluates three things:

1. **Can you explain your product's value?** (first 30 seconds)
2. **Did you make informed technical decisions?** (not "I picked X because I had to")
3. **Does the project work as a real product?** (live deployment, real data)

Every slide must serve one of these goals. If a slide does not help convince the committee, it does not belong in your main presentation.

---

## Format

| Parameter | Requirement |
|-----------|-------------|
| **File format** | `.pptx` (PowerPoint) or `.pdf` |
| **Slides** | 12–18 spoken + up to 7 appendix |
| **Language** | English |
| **Aspect ratio** | 16:9 |
| **File naming** | `[LastName]_Presentation.pptx` |

---

## Slide Structure

### Slide Count Summary

| Section | Slides |
|---------|--------|
| Title | 1 |
| Elevator Pitch + Problem | 1–2 |
| Solution | 1–2 |
| Demo | 2–3 |
| Architecture | 1–2 |
| Evaluation criteria (summary) | 2–3 |
| Challenges | 1 |
| Results | 1 |
| Q&A | 1 |
| **Subtotal (spoken)** | **12–18** |
| Criteria appendix (optional) | 7 |
| **Total** | **12–25** |

---

### Slide-by-Slide Details

??? note "Title slide (1 slide)"
    Include:

    - Project name
    - Student name, group
    - Supervisor name
    - Date

??? note "Elevator Pitch + Problem (1–2 slides)"
    **Slide 1 must open with a 30-second elevator pitch:**

    > "What does my application do — explained to a non-technical person? Why would someone want to use or buy it?"

    You must answer:

    - What problem are you solving? Show the **before** state (how things work without your product)
    - Who has this problem? (target audience)
    - Why is it important? (consequences of not solving — pain points, time/money lost, statistics)

    **Format:** Use a before/after comparison, pain-point statistics, or a real user quote. The committee must understand the product's value within the first 30 seconds.

??? note "Solution (1–2 slides)"
    Include:

    - How does your product solve the problem?
    - Key features (3–5 main capabilities)
    - What makes it different from alternatives?

    Keep it brief and visual. No walls of text.

??? note "Demo screenshots (2–3 slides)"
    Show:

    - Main screens of the application
    - Key user flow (e.g., registration → main action → result)
    - UI states (empty, filled, error) — optional

    Use actual screenshots, not mockups. Annotate if needed. GIFs are welcome.

??? note "Architecture (1–2 slides)"
    Include:

    - High-level architecture diagram (components and connections)
    - Technology stack (brief list or visual)
    - Database schema (simplified) — optional

    A diagram is required. Keep it readable (not too detailed).

    !!! warning "Diagrams are mandatory"
        The committee expects **at least one architectural diagram** (e.g., component diagram, deployment diagram, or integration landscape). Presentations without technical diagrams receive significantly lower evaluations. Use UML component diagrams, C4 model diagrams, or clear box-and-arrow diagrams — not just bullet-point lists of technologies.

??? note "Evaluation criteria — summary (2–3 slides)"
    Present your **top 3–4 strongest criteria** in the main presentation. For each criterion:

    | Element | Description |
    |---------|-------------|
    | **Criterion name** | Clear title |
    | **Business justification** | Why does your product **need** this? Link to a business requirement, user need, or architectural constraint |
    | **Key implementation highlight** | The most interesting technical decision (1–2 bullet points) |
    | **Visual** | Diagram, screenshot, or code snippet |

    Focus on criteria where you did the most interesting or complex work. Do not give equal time to all 7.

    !!! warning "Common mistake"
        Do not say "I chose this criterion because I needed 7 checkmarks." Instead, explain which business requirement or user problem demanded this technology.

        **Good example:** "My application handles financial transactions from multiple regions, so I needed a database with ACID compliance and partitioning — this drove the Database criterion."

    **Example slide content:**

    ```
    Criterion: Database (OLTP)

    BUSINESS NEED: The platform processes 500+ orders/day with complex inventory
    relations — data integrity failures cost the business real money.

    WHAT:
    • PostgreSQL with 12 tables, 3NF normalized
    • Migrations via Flyway
    • Role-based access (app_read, app_write, admin)
    • Indexes on frequently queried columns

    TECH: PostgreSQL 15, Flyway, pgAdmin

    [ER Diagram]
    ```

    Each criterion slide **must** have at least one diagram, schema, screenshot, or code snippet. The committee strongly prefers **technical diagrams** (UML, component diagrams, ER diagrams, sequence diagrams) over plain screenshots for criteria involving architecture, database, API, or infrastructure.

??? note "Criteria appendix (optional, 7 slides at the end)"
    If required by the administration, prepare one slide per criterion in the appendix. These slides follow the full format (criterion name, business justification, implementation details, technologies, diagram) but are **not part of your spoken presentation**. They serve as reference material for the committee.

??? note "Challenges and solutions (1 slide)"
    Include:

    - 2–3 significant technical challenges faced
    - How each was solved
    - What was learned

    Use a table or bullet points with "Problem → Solution" structure.

??? note "Results (1 slide)"
    Include:

    - Checklist of completed features (with status indicators)
    - Current version vs. future backlog
    - Link to deployed application
    - Key metrics (test coverage, performance) — if available

??? note "Q&A (1 slide)"
    Include:

    - Production URL
    - Repository link
    - API documentation link (Swagger)
    - Design link (Figma) — if applicable
    - QR code to production — optional

---

## Quality Checklist

### Content

- [ ] All text in English
- [ ] No placeholder text (`[description]`, `Lorem ipsum`)
- [ ] All links work
- [ ] Screenshots are from the actual application (not mockups)
- [ ] Diagrams are readable and labeled

### Design

- [ ] Consistent visual style throughout
- [ ] Readable font size (minimum 18pt for body text)
- [ ] Sufficient contrast (text vs. background)
- [ ] No walls of text (max 6–7 bullet points per slide)
- [ ] Images and diagrams are high quality (not blurry)

### Technical

- [ ] File opens without errors
- [ ] No missing fonts or broken elements
- [ ] File size reasonable (< 50 MB)

---

## Common Mistakes

| Don't | Do |
|-------|-----|
| Read slides word-by-word | Use slides as visual support |
| Put entire paragraphs on slides | Use short bullet points (5–7 words) |
| Use tiny fonts | Minimum 18pt body, 24pt+ headers |
| Show raw code (20+ lines) | Show key snippets (5–10 lines) or pseudocode |
| Skip the "why" | Always explain your decisions |
| Use generic diagrams from the internet | Create diagrams specific to your project |
| Leave empty sections | Mark N/A with explanation if something does not apply |
| Present technical criteria without diagrams | Include UML, component, sequence, or ER diagrams for every technical criterion |

---

## Next Steps

- **Next:** [Thesis Guide](thesis-guide.md) — write and finalize your thesis documentation
- **Related:** [Video Requirements](video-requirements.md) — your demo video (should already be done)
- **Related:** [Defense Preparation](../06-defense-and-completion/defense-preparation.md) — tips for presenting at the defense
