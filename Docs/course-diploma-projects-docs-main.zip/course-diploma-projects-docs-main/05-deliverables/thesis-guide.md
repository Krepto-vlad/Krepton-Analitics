<!-- prev: presentation-requirements.md | next: ../06-defense-and-completion/final-deliverables-checklist.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Step-by-step guide for writing your thesis. Start early, write progressively.

    :school: **Staff:** Thesis structure and quality expectations.

    **Prerequisites:** Topic approved. Development started.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Thesis Guide

**Step 5 of 5** in the Deliverables section. You should have your [presentation](presentation-requirements.md) ready from the previous step. Now it is time to compile and finalize your thesis documentation.

!!! info "TL;DR"
    Your thesis is a set of Markdown files that you convert to PDF. Download the template, fill in each section with content about **your** project, generate the PDF, and submit it in a ZIP archive. Total length: 32,000–51,500 characters (~17–25 A4 pages).

---

## What Is This

Your project documentation is a technical document describing your diploma project in an industry-standard format. This is not an academic essay — it is a real document that could be used in an IT company: problem description, architectural decisions, user manual, and honest analysis of results.

**Format:** Markdown (.md files) → PDF

**Why Markdown:**

- Stored in Git alongside your code
- Easy to edit and version control
- Works well with AI assistants
- Automatic PDF generation

---

## Template

**Download template:** [GitHub repository link]

The template has a ready-made folder structure and files with placeholders. Fill them with your content.

---

## Document Structure

```
docs/
├── index.md                    # Title page
├── 01-project-overview/        # Section 1: Project Overview (BA)
│   ├── index.md
│   ├── problem-and-goals.md
│   ├── stakeholders.md
│   ├── scope.md
│   └── features.md
├── 02-technical/               # Section 2: Technical Implementation
│   ├── index.md
│   ├── tech-stack.md
│   ├── criteria/               # Your 7 evaluation criteria
│   │   ├── [criterion-1].md
│   │   ├── [criterion-2].md
│   │   └── ...
│   └── deployment.md
├── 03-user-guide/              # Section 3: User Guide
│   ├── index.md
│   ├── features.md
│   └── faq.md
├── 04-retrospective/           # Section 4: Retrospective
│   └── index.md
└── assets/                     # Images and diagrams
    └── images/
```

---

## Step-by-Step Workflow

### Step 1: Preparation

1. Download the template from GitHub
2. Create your own repository or folder for documentation
3. Copy the template structure
4. Install PDF generation tools (see "PDF Generation" below)

### Step 2: Title page

Fill in `index.md`:

- Project name
- Your details (full name, group, supervisor)
- Links to production, repository, Figma
- List of selected evaluation criteria

### Step 3: Project overview

Fill in the `01-project-overview/` section:

| File | What to write |
|------|---------------|
| `index.md` | Executive summary, links |
| `problem-and-goals.md` | Problem, user pain points, goals and KPIs |
| `stakeholders.md` | Target audience, personas |
| `scope.md` | In/Out scope, constraints, assumptions |
| `features.md` | Epics, user stories, use case diagram |

### Step 4: Technical implementation

Fill in the `02-technical/` section:

| File | What to write |
|------|---------------|
| `index.md` | Architecture diagram, component overview |
| `tech-stack.md` | Technology table with justification |
| `criteria/*.md` | 1 file for each of your 7 evaluation criteria |
| `deployment.md` | CI/CD pipeline, how to run the project |

!!! tip "Use the ADR structure for each criterion"
    - **Context** — what problem you were solving
    - **Decision** — what you chose
    - **Alternatives** — what else you considered
    - **Requirements compliance checklist** — how you meet the grading rubric

    See the [Criteria Template](thesis-template/docs/02-technical/criteria/_template.md) for the exact format.

!!! warning "Include diagrams for technical criteria"
    The defense committee expects **UML or architectural diagrams** (component diagrams, sequence diagrams, ER diagrams, deployment diagrams) for technical criteria such as Database, Backend, Frontend, Containerization, Microservices, and API Documentation. Submissions without diagrams about the technical parts of the application are viewed unfavorably. Place diagram source files in `assets/diagrams/`.

### Step 5: User guide

Fill in the `03-user-guide/` section:

- **Getting Started** — how to start using the app
- **Features** — step-by-step scenarios with screenshots
- **FAQ** — common problems and solutions

### Step 6: Retrospective

Fill in `04-retrospective/index.md`:

- What went well
- What did not work and why (be honest)
- Technical debt — known issues
- Lessons learned — conclusions and takeaways

### Step 7: Finalization

1. Check all links and images
2. Make sure all placeholders are filled in
3. Generate PDF
4. Check PDF for readability
5. Prepare the submission archive

---

## Volume Recommendations

Focus on **character count**, not pages.

| Section | Characters | ~A4 Pages |
|---------|------------|-----------|
| Title page | 1,000–1,500 | 0.5 |
| Project overview | 8,000–12,000 | 4–6 |
| Technical (including 7 criteria) | 15,000–25,000 | 8–12 |
| User guide | 5,000–8,000 | 3–4 |
| Retrospective | 3,000–5,000 | 1.5–2.5 |
| **Total** | **32,000–51,500** | **17–25** |

Each criterion: **2,000–3,500 characters** (~1–1.5 pages), broken down as:

| Part | Characters |
|------|------------|
| Context | 200–400 |
| Decision | 200–400 |
| Alternatives | table with 3–4 rows |
| Consequences | 200–300 |
| Key decisions | 3–5 bullet points |
| Structure/diagram | if applicable |
| Checklist | table with 5–10 rows |

### What to write

- Specifics about **your** project
- Justification of **your** decisions
- Screenshots and diagrams of **your** application
- Honest analysis of results

### What NOT to write

- Literature review and technology history
- Copy-paste from framework documentation
- Abstract reasoning about the importance of IT
- Duplicated information between sections

---

## PDF Generation

=== "VS Code (easiest)"

    1. Install the **"Markdown PDF"** extension in VS Code
    2. Open any `.md` file
    3. `Ctrl+Shift+P` → "Markdown PDF: Export (pdf)"

=== "Pandoc (universal)"

    ```bash
    # Installation
    # Windows: choco install pandoc
    # macOS: brew install pandoc
    # Linux: sudo apt install pandoc

    # Generate PDF from all files
    pandoc docs/**/*.md -o diploma-project.pdf --toc --toc-depth=2
    ```

=== "MkDocs (advanced)"

    ```bash
    # Installation
    pip install mkdocs mkdocs-material mkdocs-pdf-export-plugin

    # Generation
    ENABLE_PDF_EXPORT=1 mkdocs build
    ```

---

## Submission Format

Submit **one ZIP archive** with this structure:

```
[LastName]_[FirstName]_Diploma.zip
│
├── documentation/
│   ├── docs/                    # MD source files
│   │   ├── index.md
│   │   ├── 01-project-overview/
│   │   ├── 02-technical/
│   │   ├── 03-user-guide/
│   │   ├── 04-retrospective/
│   │   └── assets/
│   │
│   └── [LastName]_Documentation.pdf
│
├── source-code/
│   ├── backend.zip              # Backend repository
│   ├── frontend.zip             # Frontend repository
│   └── [other].zip              # Other repositories (if any)
│
├── presentation/
│   └── [LastName]_Presentation.pptx
│
└── video/
    └── [LastName]_Demo.mp4      # Or link in README
```

| Component | Format | Requirements |
|-----------|--------|-------------|
| Documentation (MD) | `.md` files | Completed template, all sections filled |
| Documentation (PDF) | `.pdf` | Generated from MD, readable |
| Code | `.zip` | Each repository as a separate archive |
| Presentation | `.pptx` | See [Presentation Requirements](presentation-requirements.md) |
| Video | `.mp4` or link | See [Video Requirements](video-requirements.md) |

!!! tip "File naming"
    - Use Latin characters: `Ivanov_Ivan_Diploma.zip`
    - No spaces — use `_` or `-`
    - Last name first

---

## Pre-Submission Checklist

### Documentation

- [ ] All template sections are filled in
- [ ] No placeholders like `[Name]` or `[description]`
- [ ] All links work
- [ ] Images display correctly
- [ ] PDF is generated and readable
- [ ] All 7 evaluation criteria are listed
- [ ] Technical criteria include diagrams (architecture, component, ER, sequence, or deployment diagrams)
- [ ] Diagrams are original (created for your project, not generic examples)

### Code

- [ ] Each repository in a separate ZIP
- [ ] README with run instructions exists
- [ ] No secrets in code (passwords, API keys)
- [ ] `.env.example` is present
- [ ] Code runs successfully

### General

- [ ] Archive structure matches the format above
- [ ] Files are named correctly
- [ ] Archive opens without errors

---

## FAQ

??? note "Can I write in Russian?"
    No. The documentation must be in English. Code and code comments must also be in English.

??? note "Is this exact template mandatory?"
    Yes. The structure is mandatory. You may adapt minor visual styling, but you must follow the overall structure.

??? note "What if a criterion is not fully completed?"
    Honestly mark the checklist status as partially completed and explain in the Retrospective section what was not completed and why.

??? note "Can I add extra sections?"
    Any additions or changes to the template structure must be discussed with and approved by your supervisor. Do not add extra sections without explicit permission.

??? note "Can I remove sections that do not apply?"
    No. All sections are required. If something does not apply, briefly explain why in that section rather than removing it.

??? note "How do I handle large images or videos?"
    Optimize image file sizes. For videos, use a link to YouTube or Google Drive instead of embedding the file.

??? note "What if my project has multiple repositories?"
    Create a separate ZIP for each repository. Name them clearly (e.g., `backend.zip`, `frontend.zip`, `mobile.zip`).

??? note "Can I use a different PDF generation tool?"
    Yes, as long as the final PDF is readable and properly formatted. The three options listed are recommendations.

??? note "How detailed should the User Guide be?"
    Detailed enough for someone unfamiliar with your project to understand how to use it. Include screenshots for key features.

---

## Support

If you have questions:

1. Re-read this guide carefully
2. Check the examples in the template
3. Contact your supervisor

---

## Next Steps

- **Next section:** [Final Deliverables Checklist](../06-defense-and-completion/final-deliverables-checklist.md) — verify everything is ready for the defense
- **Related:** [Official Requirements](official-requirements.md) — formatting rules for the final thesis document
- **Related:** [Criteria Template](thesis-template/docs/02-technical/criteria/_template.md) — ADR template for each evaluation criterion
