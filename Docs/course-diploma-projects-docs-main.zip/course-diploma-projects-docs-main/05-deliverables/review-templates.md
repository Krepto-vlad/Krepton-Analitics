<!-- prev: official-requirements.md | next: video-requirements.md -->

!!! abstract "Stage 6 of 7 — Pre-Defense | Week 19"
    :mortar_board: **Students:** Understand the two reviews you need and how to request them.

    :school: **Staff:** Review templates and process for supervisors and independent experts.

    **Prerequisites:** Thesis being written. Pre-defense approaching.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Review Templates

**Step 2 of 5** in the Deliverables section. You should have read the [Official Requirements](official-requirements.md) first.

Your diploma project requires two formal reviews before the defense. This page explains the templates and who fills them in.

---

## Two Reviews You Need

| Review | Who writes it | Template file | Your role |
|--------|--------------|---------------|-----------|
| **Supervisor's review** | Your supervisor (научный руководитель) | `advisors-review.docx` | Provide your thesis on time so they can write it |
| **Independent expert's review** | An external reviewer (рецензент) | `review-template.docx` | Send the template + your thesis to the reviewer |

---

## Supervisor's Review (advisors-review.docx)

Your **supervisor** fills in this template with their evaluation and comments about your work. You do not write this yourself.

Your responsibility: make sure your supervisor has your finished thesis document with enough time to write the review before the defense deadline.

---

## Independent Expert's Review (review-template.docx)

You send this template to your assigned **independent reviewer** along with your thesis document.

!!! tip "Pre-fill the template"
    Fill in your personal details and project information before sending it to the reviewer. This saves them time and reduces errors.

### When you get the reviewer's contact

You receive the reviewer's contact details **after** you upload the final version of your thesis to the [national repository](https://talpykla.elaba.lt). See [Repository Upload](../06-defense-and-completion/repository-upload.md) for details.

### What to send

Send the reviewer an email with:

1. Your thesis document (PDF — check the file size)
2. Links to your repositories (make sure all resources are publicly accessible)
3. The pre-filled review template

!!! info "Timeline"
    The review process happens **after pre-defense** and **before final defense**. You need a successful pre-defense before you receive permission to get a review. Plan ahead — reviewers need time.

---

## After You Receive the Review

1. Confirm the administration also received it
2. Read the comments carefully — you must be ready to respond to them during the defense
3. Discuss the review with your supervisor

For the full review process details, see [Review Process](../06-defense-and-completion/review-process.md).

---

## Next Steps

- **Next:** [Video Requirements](video-requirements.md) — create your demo video before the pre-defense
- **Related:** [Review Process](../06-defense-and-completion/review-process.md) — detailed steps for getting and handling the review
- **Related:** [Official Requirements](official-requirements.md) — formatting rules for the thesis document you send to the reviewer
