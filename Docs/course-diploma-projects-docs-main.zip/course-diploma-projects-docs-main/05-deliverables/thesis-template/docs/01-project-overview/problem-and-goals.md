<!-- prev: index.md | next: stakeholders.md -->

# Problem Statement & Goals

## Context

[Describe the background and context of the project. What is the current situation? What market/domain does this operate in?]

## Problem Statement

**Who:** [Target user/customer segment]

**What:** [The specific problem they face]

**Why:** [Why this problem matters and needs to be solved]

### Pain Points

| # | Pain Point | Severity | Current Workaround |
|---|------------|----------|-------------------|
| 1 | [What frustrates users] | High/Medium/Low | [How they cope now] |
| 2 | [What inefficiencies exist] | High/Medium/Low | [How they cope now] |
| 3 | [What needs are unmet] | High/Medium/Low | [How they cope now] |

### Before / After

Show the concrete difference your product makes:

| Aspect | Before (without your product) | After (with your product) |
|--------|-------------------------------|---------------------------|
| [Key workflow or metric] | [Current state — slow, manual, error-prone] | [Improved state — fast, automated, reliable] |
| [Key workflow or metric] | [Current state] | [Improved state] |
| [Key workflow or metric] | [Current state] | [Improved state] |

> This table should make the product's value obvious at a glance. Use specific numbers where possible (e.g., "30 min manual process → 2 min automated").

## Business Goals

| Goal | Description | Success Indicator |
|------|-------------|-------------------|
| [Goal 1] | [What we want to achieve] | [How we know we succeeded] |
| [Goal 2] | [What we want to achieve] | [How we know we succeeded] |
| [Goal 3] | [What we want to achieve] | [How we know we succeeded] |

## Objectives & Metrics

| Objective | Metric | Current Value | Target Value | Timeline |
|-----------|--------|---------------|--------------|----------|
| [Objective 1] | [KPI] | [Baseline] | [Target] | [When] |
| [Objective 2] | [KPI] | [Baseline] | [Target] | [When] |
| [Objective 3] | [KPI] | [Baseline] | [Target] | [When] |

## Success Criteria

### Must Have

- [ ] [Critical criterion 1: Measurable outcome]
- [ ] [Critical criterion 2: Measurable outcome]
- [ ] [Critical criterion 3: Measurable outcome]

### Nice to Have

- [ ] [Optional criterion 1: Measurable outcome]
- [ ] [Optional criterion 2: Measurable outcome]

## Non-Goals

What this project explicitly does NOT aim to achieve:

- [Non-goal 1]
- [Non-goal 2]
