<!-- prev: ../04-retrospective/index.md | next: glossary.md -->

# 5. Appendices

Supplementary reference materials for the project.

## Contents

- [Glossary](glossary.md) - Key terms and definitions
- [API Reference](api-reference.md) - API endpoint documentation
- [Database Schema](db-schema.md) - Database structure and relationships
