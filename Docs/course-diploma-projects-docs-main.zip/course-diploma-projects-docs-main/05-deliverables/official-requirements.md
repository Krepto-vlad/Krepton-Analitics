<!-- prev: ../04-technical-requirements/04g-specialized/machine-learning.md | next: review-templates.md -->

!!! abstract "Stage 5 of 7 — Prepare Deliverables | Weeks 16–18"
    :mortar_board: **Students:** Formatting rules for your thesis document. Reviewers evaluate ONLY from this document.

    :school: **Staff:** Official formatting requirements reference.

    **Prerequisites:** Read early (Week 1), apply when writing (Week 18).

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Official Requirements

**Step 1 of 5** in the Deliverables section — read this before you start writing.

!!! warning "Key insight"
    Reviewers evaluate your work **only** from the thesis document. They will not open your app, check your repo, or contact you. If something is not in the document, it does not exist for the reviewer.

---

## What Is the Thesis Document

The **thesis document** (пояснительная записка) is a formal PDF that describes your diploma project. It must follow state repository formatting standards.

This is not an essay. It is a structured technical document: problem description, architecture, implementation decisions, and results.

---

## What You Must Prepare

| # | Item | Description |
|---|------|-------------|
| 1 | **Title** | Full project title, matching your approved topic |
| 2 | **Abstract** | 1-page summary of your work, in English |
| 3 | **Keywords** | 3–5 words that describe your project |
| 4 | **Main text** | The thesis document itself, following the formatting rules below |
| 5 | **Declaration of originality** | See the last appendix in the official guidelines |

---

## Formatting Rules

Your thesis document is a **diploma project** — follow the requirements for diploma projects specifically. Pay attention to:

- Table formatting
- Diagram labeling and referencing
- Table of contents structure
- Appendix formatting
- Page margins and font requirements

!!! tip "Read the full rules document"
    The official guidelines cover every formatting detail. Read them early so you do not need to reformat later.

---

## Important Notes

- Your diploma project type is **diploma project** (not coursework, not master's thesis). Use the correct section of the guidelines.
- If something does not fit in the main text, add it as an appendix. But do not overuse appendices.
- The document language is **English**.

---

## Official Guidelines Document

The full official document with detailed formatting requirements:

**[`Rules_for_students_papers_2025_final_RUS.pdf`](official-rules.pdf)**

This PDF covers structure, formatting, tables, diagrams, and appendices.

---

## Next Steps

- **Next:** [Review Templates](review-templates.md) — understand what your supervisor and independent reviewer will evaluate
- **Related:** [Thesis Guide](thesis-guide.md) — step-by-step guide for writing your thesis documentation
- **Related:** [Final Deliverables Checklist](../06-defense-and-completion/final-deliverables-checklist.md) — everything you need before the defense
