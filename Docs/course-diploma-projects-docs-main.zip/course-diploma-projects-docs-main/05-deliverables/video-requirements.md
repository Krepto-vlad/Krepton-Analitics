<!-- prev: review-templates.md | next: presentation-requirements.md -->

!!! abstract "Stage 5 of 7 — Prepare Deliverables | Weeks 16–18"
    :mortar_board: **Students:** Record your demo video before pre-defense. 30 sec – 2 min, 1080p+, .mp4 format.

    :school: **Staff:** Video quality requirements for evaluation.

    **Prerequisites:** Application working and ready to be recorded.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Video Requirements

**Step 3 of 5** in the Deliverables section. You should have read the [Review Templates](review-templates.md) from the previous step.

You will create a short demo video of your diploma project. This video serves as portfolio material and promotional content for the institution.

!!! warning "Deadline"
    Your demo video must be finished **before the pre-defense**, not before the final defense. The pre-defense committee uses it as part of their evaluation. No video = not admitted to pre-defense.

    Plan to finish recording and editing **at least 1 week before pre-defense**.

---

## Technical Specs

| Parameter | Requirement |
|-----------|-------------|
| **Duration** | 30 seconds – 2 minutes |
| **Aspect ratio** | 16:9 (horizontal) |
| **Resolution** | Minimum 1080p (Full HD) |
| **Format** | `.mp4` |
| **Audio** | Optional. If included: clear voiceover or royalty-free music only |

---

## Video Structure

| Section | Duration | What to show |
|---------|----------|-------------|
| **Title card** | 3–5 sec | Project name, your name, date |
| **Introduction** | 5–10 sec | Who you are (name, group, program) |
| **Problem** | 10–15 sec | What problem does your project solve? Who is the target audience? |
| **Solution demo** | 30–60 sec | Live screen recording of key features and main user flow |
| **Technical highlights** | 10–20 sec | Key technologies, interesting decisions, architecture overview |
| **Results** | 10–15 sec | What was achieved, lessons learned, future plans |
| **Closing card** | 3–5 sec | Project links (QR code or URL), your GitHub, institution logo |

---

## Do's and Don'ts

| Do | Don't |
|----|-------|
| Show the **actual working app**, not mockups | Use copyrighted music without a license |
| Use **screen recordings** with smooth cursor movements | Show sensitive data (passwords, API keys) |
| Add **subtitles** for accessibility | Record blurry or laggy screen captures |
| Keep **transitions smooth** but not distracting | Exceed 2 minutes — shorter is better |
| Use **annotations** (arrows, highlights) for key elements | Include long code scrolling — show snippets only |
| Maintain **good pacing** — no long pauses | Use flashy transitions or effects |

---

??? note "Production tips: Screen recording"
    - Use OBS Studio, Loom, or your OS built-in tools
    - Record at native resolution (1080p or higher)
    - Hide bookmarks bar, notifications, and personal tabs
    - Use a clean desktop background

??? note "Production tips: Audio"
    - Record in a quiet environment
    - Use a decent microphone (even a phone mic works if held close)
    - Speak clearly at a moderate pace
    - Normalize audio levels during editing

??? note "Production tips: Editing"
    - Cut out mistakes, pauses, and loading times
    - Add text overlays for key points
    - Use consistent fonts: Arial, Helvetica, Montserrat, or similar
    - Keep the visual style consistent throughout

??? note "Production tips: No voiceover?"
    - Use text cards to explain each section
    - Add royalty-free background music
    - Use annotations and callouts on screen recordings

---

## Submission

Upload to Google Drive and include in your final submission archive:

```
video/
└── [LastName]_Demo.mp4
```

Or provide a link in `video/README.md`:

```markdown
# Demo Video

**Link:** https://drive.google.com/...

Duration: 1:45
```

| Delivery option | When to use |
|-----------------|-------------|
| Google Drive link | File is larger than 100 MB |
| YouTube (unlisted) | You prefer streaming over download |
| Embedded in archive | File is smaller than 100 MB |

---

## Quality Checklist

- [ ] Duration is between 30 seconds and 2 minutes
- [ ] Resolution is 1080p or higher
- [ ] Format is `.mp4`
- [ ] Audio is clear (if present) or absent
- [ ] No copyrighted music without a license
- [ ] No sensitive data visible
- [ ] All sections from the structure table are covered
- [ ] Subtitles are readable
- [ ] File plays without errors

---

## Consent

By submitting the video, you allow it to be published on the institution's website, social media, and promotional materials. Your authorship will always be credited.

---

## Example Timelines

=== "30-second video"

    ```
    [0:00–0:03] Title card
    [0:03–0:05] "Hi, I'm [Name], this is [Project]"
    [0:05–0:25] Quick demo of main feature
    [0:25–0:30] Results + closing card
    ```

=== "2-minute video"

    ```
    [0:00–0:05] Title card
    [0:05–0:15] Introduction + problem
    [0:15–0:25] Solution overview
    [0:25–1:15] Detailed demo (3–4 features)
    [1:15–1:35] Technical highlights
    [1:35–1:50] Results + lessons learned
    [1:50–2:00] Closing + links
    ```

---

## Next Steps

- **Next:** [Presentation Requirements](presentation-requirements.md) — create your defense slides
- **Related:** [Defense Preparation](../06-defense-and-completion/defense-preparation.md) — tips for the pre-defense and final defense
- **Related:** [Final Deliverables Checklist](../06-defense-and-completion/final-deliverables-checklist.md) — verify you have everything ready
