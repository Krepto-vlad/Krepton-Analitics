<!-- prev: ../04b-data-layer/real-time-analytics.md | next: ../04d-frontend-and-ux/frontend.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** **Required criterion.** Modern framework, layered architecture, SOLID, 70% test coverage.

    :school: **Staff:** Backend assessment rubric — verify architecture, testing, deployment.

    **Prerequisites:** Topic approved with backend criterion selected.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Minimum Backend Requirements for a Passing Grade

Your backend must meet the following minimum requirements to pass the diploma defense.

## Use a Modern Framework

Build your application with a high-level server-side framework. Examples: ASP.NET Core, Spring, Django, Node.js, and others.

### Exception

Your project may be a console application or other software that does not need a framework. In that case, you must implement the following features yourself:
- Logging;
- Error handling;
- Serialization and data binding;
- Authorization and authentication.

## Data State Management

If your application stores object or data state, use a database. Choose between a relational database (e.g., PostgreSQL, MySQL) and a non-relational database (e.g., MongoDB) based on your project needs.

## Use an ORM

Use an ORM (Object-Relational Mapping) to interact with the database. Examples: Entity Framework, Hibernate, Sequelize, and others.

## Application Architecture

Follow layered architecture principles. For example, separate your code into layers: presentation, business logic, and data access. This ensures modularity and makes the code easier to maintain.

## Design Principles (SOLID)

Write your application code following SOLID principles:
- Single Responsibility Principle;
- Open/Closed Principle;
- Liskov Substitution Principle;
- Interface Segregation Principle;
- Dependency Inversion Principle.

## API Description

Clearly describe the backend interaction interface (API). You can use documentation tools (e.g., OpenAPI/Swagger) or a text description if your project does not support standard tools.

## Global Error Handling

Implement a centralized error handling mechanism in your application. This improves reliability and makes debugging easier.

## Logging

Log key events, errors, and other important operations. Logs must be structured and available for analysis.

## Production Deployment

Deploy your finished application to a production environment. This can be:
- A cloud solution (e.g., AWS, Azure, Google Cloud, Heroku);
- Private server resources (e.g., Docker containers on a local server).

Important: you must show that the application works and is accessible to external users.

## Test Coverage

Cover the business logic of your application with unit tests. The minimum required code coverage is **70%**. Use code coverage analysis tools to confirm this number.

---

## Specific Constraints, Technologies, and Approaches

Follow these constraints and recommendations during development. They help ensure quality, security, and accessibility of your application.

### General Constraints

1. **No paid libraries**
   Do not use paid libraries or tools that may limit others from reviewing or using your application. Your solution must be accessible and reproducible.

2. **Avoid vulnerable packages**
   Check your libraries and dependencies for known critical vulnerabilities. Use security analysis tools such as **npm audit**, **pip-audit**, or similar tools for your tech stack.

3. **Version control**
   Do all development in a version-controlled environment, for example Git. Your repository must contain a change history so reviewers can track your progress and approach.

4. **Use JSON**
   Use JSON as the main data format for transferring and processing information. This ensures compatibility with most modern technologies.

5. **Storing secrets and sensitive data**
   Do not store secrets (e.g., API keys, passwords, tokens) in the repository. Move them to secure storage or environment variables. Make sure your deployment process handles this.

6. **Automatic deployment from the repository**
   The application must be deployable and runnable from the latest version in the repository. No manual changes or workarounds should be needed. This shows maturity in your development approach.

### What Not to Do

1. **Do not invent your own encryption protocols**
   Do not create custom encryption protocols or custom implementations of standard solutions like JWT. Use proven, standardized technologies.

2. **Do not use outdated or educational-only libraries**
   Do not use libraries that are outdated or designed only for learning purposes. Examples:
   - **xmlrpc**;
   - Python's built-in **http.server** without modifications;
   - Other tools not meant for production use.

3. **Do not create stubs instead of a real API**
   Your application must not return static JSON or other fake data instead of real interaction with the database or other components. This is considered an unacceptable simplification.

### Modularity Recommendations

- Make your application modular. Structure your code following modularity principles. Avoid a monolithic approach (e.g., all code in one file). This makes maintenance, testing, and scaling easier.

---

## Maximum Backend Requirements for the Diploma Project

To get the highest grade (10 points), your backend must show advanced practices in development, deployment, and maintenance. Meeting these requirements demonstrates deep knowledge and skills.

### CI/CD Practices

- Automate building, testing, packaging, and deploying your application using CI/CD (Continuous Integration/Continuous Deployment).
- A typical process:
  - Create a Docker image with your application;
  - Store the image in a container registry (e.g., Docker Hub, AWS ECR, GitHub Container Registry);
  - Automatically deploy the image to a production environment (e.g., cloud: AWS, Azure, GCP, or a local server).
- During deployment, inject secrets (keys, passwords, tokens) and settings through environment variables or secret stores. Run all steps through a build and deployment pipeline (e.g., GitHub Actions, GitLab CI/CD, Jenkins).

### Microservice Architecture

- Build your application from several microservices. Each microservice must perform one clearly defined task.
- Microservices must be independent and deployable to production separately from each other.

### Asynchronous Communication

- Organize communication between application parts (microservices) asynchronously. For example, use message queues such as RabbitMQ or Kafka. This ensures scalability and system resilience.

### Caching

- Implement caching to optimize performance. For example, use Redis or Memcached to store temporary data, frequently used queries, or computation results.

### System Monitoring

- Set up a monitoring system for the application and infrastructure state.
- Use tools such as Grafana and Prometheus to:
  - Collect metrics (CPU load, request count, memory usage, etc.);
  - Visualize data through dashboards.

### Log Management System

- Make your application logs structured and centralized.
- Implement filtering, search, and log analysis through specialized tools such as ELK Stack (Elasticsearch, Logstash, Kibana) or Loki.
- Logs must be useful for debugging and analyzing system behavior.

### Request Tracing Between Microservices

- Implement request chain tracing between microservices using a **correlation ID**. This lets you track the full path of a request, even when it passes through several services.

### Alerting System

- Set up alerts for specific conditions. Examples: metric thresholds exceeded, errors occurred.
- Use tools such as Alertmanager to send notifications to messengers (Telegram, Slack) or by email.

### Quality Gates in CI/CD

- Set up quality gates in your CI/CD pipeline. This includes:
  - Automatic code quality checks (e.g., using SonarQube or similar tools);
  - Running tests (unit tests, integration tests);
  - Checking code test coverage (e.g., minimum coverage of 80%).
- Deployment must happen only when all checks pass.

---

## Common Mistakes and Issues That Affect the Backend Grade

Below is a list of mistakes and oversights that are considered unacceptable. Points will be deducted from the total grade for each one. These issues show non-compliance with modern development standards and reduce project quality.

### Security Mistakes

1. **Using insecure hashing algorithms**
   Example: using MD5 or SHA-1 instead of modern algorithms such as bcrypt, Argon2, or SHA-256.
   **Minus 1 point.**

2. **Storing sensitive data in plain text**
   Example: storing passwords or tokens in plain text instead of encrypting or hashing them.
   **Minus 1 point.**

3. **Missing input validation**
   Example: no user input validation, which can lead to SQL injection, XSS, and other attacks.
   **Minus 1 point.**

### Data and Error Handling Mistakes

4. **Missing error handling**
   Example: the application crashes on exceptions instead of handling them properly and returning clear messages to the user or system.
   **Minus 1 point.**

5. **Incorrect or missing HTTP status codes**
   Example: the application always returns **200 OK**, even on errors (e.g., when a resource is not found).
   **Minus 1 point.**

6. **Database inconsistency**
   Example: the API does not work with the declared entities. Database fields do not match the documentation.
   **Minus 1 point.**

### Design and Code Mistakes

7. **Missing API documentation**
   Example: no description of API methods, their parameters, and return data (e.g., through Swagger or text documentation).
   **Minus 1 point.**

8. **Poor code quality**
   Example: unreadable, poorly structured code. No comments. Use of unclear constructs.
   **Minus 1 point.**

9. **Inefficient database queries**
   Example: using eager-loading queries without need, missing indexes, too many queries instead of optimized operations.
   **Minus 1 point.**

10. **Hardcoded configuration**
    Example: parameters such as database URL, API keys, and file paths are written directly in the code instead of using environment variables.
    **Minus 1 point.**

11. **No modularity**
    Example: all code is in one file. No separation into layers (e.g., controllers, business logic, data access).
    **Minus 1 point.**

12. **Using magic strings**
    Example: strings or numbers used in code without explaining their meaning (e.g., **"admin"** instead of a constant **ROLE_ADMIN**).
    **Minus 1 point.**

13. **Code duplication**
    Example: repeated code blocks instead of extracting them into functions or methods.
    **Minus 1 point.**

### Testing Mistakes

14. **No test coverage**
    Example: no unit tests or insufficient tests (less than 70% coverage).
    **Minus 1 point.**

### API Implementation Mistakes

15. **Not following the REST approach**
    Example: incorrect use of HTTP methods (e.g., using **GET** to create a resource). No logical URL structure.
    **Minus 1 point.**
