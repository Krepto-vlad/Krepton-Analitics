<!-- prev: ../04a-business-and-docs/api-documentation.md | next: real-time-analytics.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for database design (OLTP, OLAP, or NoSQL options).

    :school: **Staff:** Assessment rubric for database implementation.

    **Prerequisites:** Project architecture designed. Database type chosen.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Databases

**Notes:**
1. If a database is only used as a helper part (for example, to store logs or settings), it does not count as a full database part of the project.
2. The DBMS must match the project goal. The choice of a NoSQL DBMS must be justified — explain why a specific model was chosen for this task.

**Requirements are split into the following categories:**

- Relational databases:
  - Transactional databases (OLTP)
  - Analytical databases (OLAP)
- Non-relational databases (NoSQL)

---

## Transactional Databases (OLTP)

### Minimum Requirements (for 5 points)

### Documentation

- Data dictionary: describe layers (if any), tables and columns, data types, keys, and data quality expectations.
- Describe how data integrity is maintained and how transactions are handled.
- ER diagram — optional.
- Logical schema: the visual representation must be clear. Highlight the main blocks and relationships. Color coding is allowed to improve readability.
- DDL script (SQL) to create the database structure.

### Design

- Use a modern relational DBMS (PostgreSQL, SQL Server, etc.).
- Design the structure with normalization up to third normal form (3NF).
- The schema must include enough tables and different types of relationships.
- For all tables, specify:
  - primary and foreign keys,
  - constraints (NOT NULL, UNIQUE, CHECK, etc.),
  - meaningful data types (for example, numeric for money, timestamp for dates).

### Deployment

- Create the database structure using an SQL script or migrations, not manually.
- Keep all scripts and migrations in version control (Git).

### Test Data

- Prepare enough test records to show that the application works and to cover edge cases.
- Provide scripts to fill reference tables (fixed data).

### Usage

- Set up roles and access rights:
  - at minimum: app_read, app_write, admin — or others that make more sense for your topic;
  - the application must not run under superuser;
  - when adding new objects, check and update user permissions.
- Store passwords only in encrypted form. Do not use outdated hashing methods (MD5, SHA-1, etc.).
- Ensure data integrity using constraints and transactions.

### Restrictions

- You must not store passwords in plain text.
- You must not use CSV/Excel files as the only data storage without a DBMS.
- You must not store unstructured documents (JSON) in a relational database without a well-designed model.
  - An exception is possible if the structure is described and justified in the documentation.
- You must not ignore data integrity (missing keys, constraints, or transactions).

### Maximum Requirements (for 10 points)

### Architecture and Functionality + Documentation

- When needed, use different types of DBMS in one project (for example, PostgreSQL for the transactional part and ClickHouse for analytics) — if the topic justifies it. Provide reasoning in the documentation.
- Implement data layers (raw -> staging -> data mart) — when needed, depending on the project topic. Provide reasoning in the documentation.
- Describe database structure versioning — how changes are tracked, how version history is stored (for example, through migrations and Git).
- Implement and justify indexes (depending on the project context).
- Use triggers, stored procedures, and user-defined functions that implement part of the business logic at the database level.
- Use views (VIEW) or materialized views to simplify and optimize queries.
- For fields that contain personal data (full name, e-mail, phone number, etc.), implement data masking or anonymization.

---

## Analytical Databases (OLAP)

### Minimum Requirements (for 5 points)

### Documentation

- Data dictionary: describe tables and columns, data types, keys, aggregates, and data quality expectations.
- Describe the layer architecture (for example, raw -> staging -> data mart) and the purpose of each layer.
- Logical schema: the visual representation must be clear. Highlight the main blocks and relationships. Color coding is allowed to improve readability.
- DDL script (SQL) to create the database structure.
- Provide a data flow diagram: where data comes from, how it is processed, and where it is loaded.
- Describe how data integrity and freshness are ensured (validation, deduplication, load monitoring).

### Design

- Use a modern analytical DBMS (for example, ClickHouse, Snowflake, etc.).
- The schema must include enough fact tables and dimension tables — according to the chosen model.
- Define data update rules (full load, incremental load, CDC).

### Deployment

- Create the database structure using SQL scripts or migrations and keep them in version control (Git).
- Prepare scripts or pipelines for data loading (ETL/ELT).

### Test Data

- Prepare test sources and data to show that loading and aggregation work correctly.

### Usage

- Implement analytical queries (GROUP BY, aggregates, window functions, filtering by dimensions).
- Show analytical reports or other visualizations.
- Implement data quality checks (duplicate control, null values, incorrect types).

### Restrictions

- You must not use transactional DBMS that are not designed for analytical workloads (for example, SQLite).
- You must not store all data in one table without separating dimensions.
- You must not load data manually — all steps must be reproducible (through scripts or a pipeline).

### Maximum Requirements (for 10 points)

### Architecture and Functionality + Documentation

- Implement an architecture with separate data layers (for example, raw -> staging -> ODS -> data mart -> semantic) and explain the purpose of each.
- Implement ETL or ELT processes with incremental loading, error handling, logging, and load reports.
- When needed, use optimization techniques: partitioning, clustering, distributed storage, denormalization.
- When needed, build indexes to speed up queries. Provide reasoning in the documentation.
- When needed, implement views and materialized views for aggregations and reports.
- Apply SCD (Slowly Changing Dimensions) techniques to track historical data.
- In the documentation, describe data sources, update frequency, quality control methods, and monitoring.

---

## Non-relational Databases (NoSQL)

### Minimum Requirements (for 5 points)

### Documentation

- Data dictionary: describe the purpose of the database, collections / nodes / tables, keys, data types, and data quality expectations.
- Describe the data model and provide reasoning for choosing a specific DBMS.
- Explain how data integrity is ensured (schema validation, constraints, cascading updates, relationship control, etc.).

### Structure and Design

- Use a modern NoSQL DBMS that fits the project task.
- Think through the data storage structure.
  - For document-oriented DBMS, for example:
    - define collections, documents, fields, nested structures, and indexes;
    - specify which fields are required, which are nested, and how validation is done.
- The number of collections or entities must match the project complexity.

### Reliability and Security

- Set up user roles and permissions:
  - read/write permissions, schema management, etc.
  - the application must not run under superuser.
- Do not store passwords and tokens in plain text.

### Deployment and Test Data

- All data and structure must be reproducible (dump, export, migrations).
- The set of test documents / nodes must be enough to show how the system works.

### Restrictions

- You must not use NoSQL simply as a "JSON container" without structure and validation.
- You must not store all data in one collection (or node) if there are different entity types.

### Maximum Requirements (for 10 points)

### Architecture and Functionality + Documentation

- Use different database types within one project (for example, MongoDB for documents, Redis for cache, Neo4j for relationships). Provide reasoning in the documentation.
- Show a well-designed data model:
  - for document-oriented databases, for example:
    - a deliberate choice between embedding (embedded) and references (referenced);
    - structure optimization based on query patterns.
- Use complex queries or aggregation mechanisms:
  - for document-oriented databases, for example: aggregation pipelines, filters, text field search.
- Implement indexes of different types (text, compound, geo indexes, TTL).
