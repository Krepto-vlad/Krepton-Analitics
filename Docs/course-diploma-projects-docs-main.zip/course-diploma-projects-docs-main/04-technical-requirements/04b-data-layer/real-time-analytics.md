<!-- prev: database.md | next: ../04c-backend/backend.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for real-time analytics. Must be continuous event streams, not button clicks.

    :school: **Staff:** Assessment rubric for real-time data handling.

    **Prerequisites:** Real-time requirement defined in business analysis.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Real-time Analytics

**Notes and Context**

If an application only displays current data but does not receive and process it automatically and continuously, it does not count as a real-time analytics implementation.

---

## Minimum Requirements (for 5 points)

- Provide at least **one** real event type arriving in near real-time: user actions, system events, device data, external APIs, etc.

### Documentation

- Describe the full event path: source + trigger -> backend -> delivery channel -> UI (schema or diagram).
- Clearly state which data is considered "real-time" and **what target delay is acceptable** (for example, up to 1-5 seconds) — with reasoning.
- Define the event source and the data transfer format.

### Implementation

**Backend**
- Implement real-time data reception (WebSocket, SSE, long polling, etc.).
- Process events as they arrive (filtering, counting, aggregates).
- Provide an API or endpoint to get the current data state.
- Separate the processing logic into a dedicated module/service, or clearly isolate it in the code.

**Frontend**
- Implement dynamic visualization on the FE that updates without page reload.
- When the connection is lost, show a message that data is unavailable.

---

## Maximum Requirements (for 10 points)

*In addition to the minimum requirements:*

### Documentation

- Describe the real-time component architecture in detail, split into layers:
  - ingestion (receiving events),
  - processing (processing/aggregation),
  - storage/serving (storing and delivering metrics).
- Justify the technology choices, for example:
  - message broker (Kafka, RabbitMQ, NATS, etc.),
  - in-memory/TSDB storage (Redis, TimescaleDB, etc.).
- Describe scaling patterns:
  - horizontal scaling of processors,
  - strategy for handling increased load.
- Describe mechanisms for data integrity and stream security:
  - authentication/authorization (for example, a token for WS),
  - access restrictions for metrics and events,
  - personal data and sensitive fields are masked or anonymized.

### Implementation

- Make sure the system handles updates with low latency for many clients.
- Use suitable technologies for stream processing (queues, in-memory databases, etc.).
- Implement windowed or time-based aggregates, complex metrics, and combined calculations.
- Ensure fault tolerance: client reconnection, proper error handling, and retries.
- Implement masking or anonymization of personal data in the stream.
- Visualization must work smoothly and reliably, showing live data updates and the practical value of real-time analytics.

---

## General Restrictions

- You must not update data only manually — by button click, page reload, or repeated request.
- You must not implement updates only on a schedule (cron, every few minutes or hours) without a continuous event stream.
- You must not use regular SQL queries without a stream processing mechanism or event subscription.
- You must not use static files or pre-prepared data (JSON, CSV, Excel) instead of real events.
- You must not simulate a stream — for example, when a chart "updates" with random numbers.
- A real-time implementation does not count if the update delay is too large (more than 10 seconds) and there is no explanation of why this is acceptable.
