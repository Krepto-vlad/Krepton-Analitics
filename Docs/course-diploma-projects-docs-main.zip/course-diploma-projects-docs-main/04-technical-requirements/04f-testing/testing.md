<!-- prev: auto-tests.md | next: ../04g-specialized/ai-assistant.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for testing strategy. Test plans, quality metrics, coverage analysis.

    :school: **Staff:** Assessment rubric for overall testing quality.

    **Prerequisites:** Test suites written. Coverage tools configured.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Qualitative or Quantitative Testing Diploma Project Requirements

**Scope and Goals**

You will use this document to understand the expectations and evaluation criteria for diploma projects focused on Qualitative or Quantitative Software Testing.

**This document defines:**
- Minimum requirements -- mandatory criteria you must meet to obtain a passing grade (grade = 5).
- Maximum requirements -- advanced criteria to achieve the highest grade (grade = 10).
- Major errors and shortcomings -- typical critical issues resulting in penalties.

---

## Minimum Requirements (for a Passing Grade)

1. Demonstrate the use of a structured testing workflow. Include a clear definition of whether the project focuses on qualitative testing, quantitative testing, or a combination of both.

2. Clearly define the test scope, testing goals, objectives, and entry/exit criteria. Justify these elements with respect to system complexity and associated risks.

3. Provide a requirements analysis or feature breakdown identifying testable functionality, user flows, or system components. Use this analysis as the basis for your testing process.

4. Include a set of manual test cases, checklists, or scenarios. Each artifact must include preconditions, steps, expected results, and prioritization (e.g., Smoke, Critical, etc.; High, Medium, etc.)

5. For quantitatively oriented projects, define and measure several key testing metrics (e.g., pass rate, defect density, defect leakage, execution time, coverage metrics).

6. For qualitatively oriented projects, include documented findings on usability issues, UX problems, unclear flows, or inconsistencies.

7. Provide a structured test execution report with identified defects, environment details, retesting results, and references to supporting artifacts.

8. Use at least one professional testing tool (e.g., Postman, JMeter, TestLink, Jira, Azure DevOps, etc.), and document its configuration and purpose. Tool usage must be relevant to the tested system and contribute to the overall testing workflow.

9. Store the entire project in a Git repository with meaningful commit history, along with documentation that allows full reproduction of the environment and test execution process.

10. Prepare a concise technical report summarizing the tested system, testing strategy, executed work, collected metrics (if applicable), and final conclusions.

---

## Maximum Requirements (for the Highest Grade)

1. Include a comprehensive testing strategy combining functional, non-functional, usability, exploratory, or regression testing. Justify the chosen approach using risk analysis or project constraints.

2. Apply advanced test design techniques (equivalence partitioning, boundary value analysis, decision tables, state transition diagrams, cause-effect graphs), and demonstrate how they improved coverage or reduced redundancy.

3. Use test prioritization or risk-based testing, with clearly presented reasoning and measurable impact.

4. For quantitative testing:
   a. Collect, visualize, and interpret testing metrics (e.g., traceability coverage, trends, defect distribution, performance indicators).
   b. Automate metric collection through scripts or built-in reporting tools.
   c. Include comparisons between multiple test cycles with data-driven conclusions.

5. For qualitative testing:
   a. Conduct structured exploratory testing sessions with session charters, timelines, and documented findings.
   b. Apply heuristic evaluation methods or cognitive walkthroughs.
   c. Support UX issues with appropriate evidence (screenshots, annotations, guideline comparisons).

6. Where applicable, include automated checks (UI, API, load, static analysis), even if only partially implemented, with proper architecture (e.g., page-object pattern, reusable components).

7. Use CI/CD pipelines to automatically execute tests and produce logs, reports, and other artifacts.

8. Include advanced visualizations (charts, defect trends, coverage graphs, performance curves), with a consolidated dashboard or structured summary where appropriate.

9. Provide comparisons of different testing methods, tools, or approaches and give justified conclusions along with recommendations for future improvements.

---

## Major Errors and Shortcomings Affecting Evaluation

| **Category**        | **Example of issue**                              | **Penalty**  |
|---------------------|---------------------------------------------------|--------------|
| Test design         | Missing test cases, unclear steps, inconsistent expected results | -1 point |
| Documentation       | Missing reports or coverage data, incomplete execution results | -1 point |
| Functional logic    | Tests not aligned with system behavior or requirements | -2 points |
| Tools & methodology | Incorrect or outdated tool usage                  | -1 point     |
| Analysis quality    | Missing interpretation or conclusions            | -1 point     |
| Testing completeness| Significant system areas not tested without justification | -2 points |
| Code quality (automation) | Non-modular, fragile, or poorly structured automation | -1 point |
| Evidence            | Missing screenshots, logs, metrics, or unverifiable results | -1 point |
