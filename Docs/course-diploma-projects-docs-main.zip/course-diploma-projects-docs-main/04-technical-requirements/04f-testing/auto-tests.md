<!-- prev: ../04e-infrastructure/microservices.md | next: testing.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for automated test suites. Unit, integration, and E2E tests.

    :school: **Staff:** Assessment rubric for test automation.

    **Prerequisites:** Code written. Test framework configured.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Auto Tests Diploma Project Requirements

**Scope and Goals**

You will use this document to understand the expectations and evaluation criteria for diploma projects that include automated testing.

**This document defines:**
- Minimum requirements -- mandatory criteria you must meet to obtain a passing grade (grade = 5).
- Maximum requirements -- advanced criteria to achieve the highest grade (grade = 10).
- Major errors and shortcomings -- critical issues resulting in penalties.

---

## Minimum Requirements (for a Passing Grade)

1. Include a structured and well-documented automated testing setup. Demonstrate your ability to create meaningful test cases and ensure that the application's core business logic is validated through automated tests.

2. Achieve at least 70% code coverage, measured using appropriate tools (such as Istanbul/NYC for JavaScript, Coverlet for .NET, JACoCo for Java, or equivalents). Provide coverage in the form of numerical metrics and, when possible, a coverage report or screenshot.

3. Implement a comprehensive suite of unit tests to verify individual functions and methods in isolation. Follow industry best practices, including the FIRST principles (Fast, Independent, Repeatable, Self-Validating, Timely). Each non-trivial function must have tests covering both common scenarios and edge cases.

4. Include integration tests that validate interactions between components. Examples include API endpoint tests, in-memory database testing, authentication/authorization checks, and validation of application configuration.

5. If the application includes a frontend, include automated tests for the UI layer. These may include component tests (e.g., Jest + React Testing Library) and/or end-to-end tests using tools like Cypress, Playwright, or Selenium to verify key user flows.

6. Run all automated tests in a continuous integration (CI) environment to ensure reproducibility on clean infrastructure. Test results must be visible in CI logs, showing that the full suite executes successfully.

7. Describe the testing strategy in your report, including the types of tests implemented, the tools used, instructions for running tests locally, and any known gaps in coverage together with justification.

8. Follow a clear naming convention and directory structure for test files (e.g., *.test.js, tests/, or language-specific equivalents) to ensure maintainability.

---

## Maximum Requirements (for the Highest Grade)

1. Provide a highly comprehensive automated testing strategy that includes unit, integration, component, and end-to-end testing, demonstrating deep understanding of multi-layer test design.

2. Cover all business-critical areas, including input validation, error handling, permission checks, and data processing. Use advanced techniques such as mocking external services, test doubles, fixtures, and in-memory infrastructure where appropriate.

3. Extend testing to complex integration scenarios, such as multi-service interactions, database migrations, asynchronous workflows, or message queue operations. For distributed systems or microservices, include component tests and full end-to-end scenarios.

4. Enhance test quality through the use of additional tools or methodologies, such as property-based testing, mutation testing, snapshot testing, or contract tests for API stability.

5. Run the test pipeline fully in CI/CD and include quality gates, such as minimum coverage thresholds, linting, and static analysis. Provide evidence of stable test execution (e.g., successful CI screenshots or badges).

6. Document the rationale behind test architecture decisions, demonstrate how automated tests improved code quality or helped identify defects, and provide recommendations for future enhancements to the test suite.

7. Consider including performance or load testing to assess system behavior under stress.

---

## Major Errors and Shortcomings Affecting Evaluation

| **Category**   | **Example of issue**                                | **Penalty**  |
|----------------|-----------------------------------------------------|--------------|
| Coverage       | Test coverage below 70%                             | -2 points    |
| Test quality   | Critical logic untested or missing edge cases       | -1 point     |
| CI/CD          | Tests not executed in CI or failing tests ignored   | -1 point     |
| Documentation  | Missing test strategy or unclear instructions       | -1 point     |
| Stability      | Presence of flaky or unstable tests                 | -1 point     |
| Architecture   | No integration tests or missing checks for critical flows | -1 point |
| Logic          | Hardcoded outputs or tests that do not validate real logic | -2 points |
| Code use       | Inappropriate mocking or tests tightly coupled to implementation | -1 point |
