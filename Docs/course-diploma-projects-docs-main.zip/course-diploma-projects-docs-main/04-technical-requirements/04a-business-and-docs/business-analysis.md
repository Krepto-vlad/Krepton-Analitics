<!-- prev: ../03-process-and-timeline/admin-guide.md | next: api-documentation.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** **Mandatory criterion.** Must be defended before a committee, not just an expert.

    :school: **Staff:** BA assessment rubric — committee evaluation, not individual expert.

    **Prerequisites:** Topic approved. This is the first criterion to complete.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Business Analysis Requirements for Passing the BA Stage of Diploma Preparation

> **Status: Mandatory criterion with a separate defense.** Unlike other criteria, Business Analysis requires a **separate defense before a committee** — not just an assessment with an individual expert. Passing this defense is a prerequisite for continuing with the diploma project.

> **Topic change policy:** After successfully defending the BA criterion, you may change your project topic — this is the last point where radical topic changes are allowed. If you change your topic, you must re-defend the BA criterion for the new topic. After the pre-defense, only minor adjustments are permitted (see [Topic Changes](../../02-getting-started/topic-changes.md)).

You will use this document to understand what is expected of you to pass the BA stage of diploma preparation.

**This document includes:**
1. Minimum based requirements -- requirements you must cover to pass the stage (grade -- 5)
2. Maximum based requirements -- requirements you are expected to cover to pass the stage with the highest grade (grade -- 10).

---

## Minimum Based Requirements

### Vision, Problem, Project

- a. **Vision Statement** (like an elevator pitch)
- b. **Problem Statement** (Background/Context) -- describe the problem your product aims to solve.
- c. **Business goals and objectives** -- goals and tasks you want to achieve.
- d. **Key stakeholders** -- key stakeholders, including the target audience and users.

### Scope

- a. **In-Scope** -- what is included in the project (features, processes, systems).
- b. **Out-of-Scope** -- what will not be done, to avoid scope creep.

### High-Level Solution Overview

- a. **Proposed Solution** -- a general description of the proposed technical solution.
- b. **Architecture / Integration Landscape (High-Level)** -- a diagram or text description of the systems involved and how they connect.

### Features & Requirements (High-Level)

- a. **Core Features** -- a list of key capabilities (epics, capabilities).
  - i. **Functional Requirements - Work Breakdown:** epics broken down into a skeleton-level list of user stories.
- b. **Non-Functional Requirements** -- non-functional requirements for the product (performance, security, scalability, availability).
- c. **Regulatory / Compliance Needs** -- legal and regulatory requirements (GDPR, ISO, etc.) that apply to the project.
- d. **Use Case Diagram** -- a visual representation of main usage scenarios (actors and their interactions with system features).

---

## Maximum Based Requirements

### Introduction

- a. **Purpose of the Document** -- why this document exists, its structure and goals (for example: agree on the project scope, give all parties a shared understanding).
- b. **Audience** -- who this document is written for.

### Vision

- a. **Vision Statement** (like an elevator pitch).
- b. **Problem Statement** (Background/Context) -- describe the business problem and the current situation.
- c. **Business Goals & Objectives** -- business goals and tasks you want to achieve (for example: reduce order processing time by 20%).
- d. **Stakeholders Analysis** -- analysis of stakeholders, including the target audience and users, and their influence/involvement (Influence/Interest matrix).
- e. **Success Criteria** -- measurable success criteria for the project (KPI, SLA, metrics).

### Scope

- a. **In-Scope** -- what is included in the project (features, processes, systems).
- b. **Out-of-Scope** -- what will not be done, to avoid scope creep.
- c. **Assumptions** -- important assumptions the project is built on (for example: API availability, data readiness).
- d. **Constraints** -- limitations (budget, deadlines, technology, regulations, available resources).

### High-Level Solution Overview

- a. **Proposed Solution** -- a general description of the proposed technical solution.
- b. **Architecture / Integration Landscape (High-Level)** -- a diagram or text description of the systems involved and how they connect.
- c. **Alternatives Considered** -- what options were considered and why this one was chosen.

### Features & Requirements

- a. **Core Features** -- a list of key capabilities (epics, capabilities).
  - i. **Functional Requirements - Work Breakdown:** epics broken down into a list of user stories.
    1. **User Stories with full descriptions. Suggested structure:**
       - a. Title
       - b. User Story statement: As a [role], I want [goal], so that [benefit]
       - c. Context
       - d. Scope/desired -- what should be done within this story.
       - e. Acceptance Criteria
       - f. Assumptions
       - g. Risks/Dependencies
       - h. Mockups/Attachments
  - ii. **Priority labelling** -- prioritization at the epic (feature) level (for example, MoSCoW) and at the user story level.
- b. **Non-Functional Requirements** -- non-functional requirements for the project (performance, security, scalability, availability).
- c. **Regulatory / Compliance Needs** -- legal and regulatory requirements (GDPR, ISO, etc.) that apply to the project.
- d. **Use Case Diagram** -- a visual representation of main usage scenarios (actors and their interactions with system features).

### Risks & Dependencies

- a. **Risks** -- a list of risks (for example: lack of data, integration delays).
- b. **Dependencies** -- dependencies on other projects, systems, teams, or external factors.
- c. **Mitigation Strategies** -- how you plan to reduce or manage the risks.
