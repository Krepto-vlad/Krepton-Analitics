<!-- prev: business-analysis.md | next: ../04b-data-layer/database.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for API documentation. Requires OpenAPI/Swagger spec.

    :school: **Staff:** Assessment rubric for API documentation quality.

    **Prerequisites:** API implementation started.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# API Documentation Diploma Project Requirements

**Scope and Goals**

You will use this document to understand the expectations and evaluation criteria for diploma projects that include API documentation.

**This document defines:**
- Minimum requirements -- mandatory criteria you must meet to obtain a passing grade (grade = 5).
- Maximum requirements -- advanced criteria to achieve the highest grade (grade = 10).
- Major errors and shortcomings -- critical issues resulting in penalties.

---

## Minimum Requirements (for a Passing Grade)

1. **Produce a structured and well-organized API documentation set**, covering the essential components of an API reference (endpoints, parameters, request/response formats, authentication, errors). Ensure the documentation is clear, technically accurate, and easy to navigate.

2. **Provide a complete API specification**, created using industry standards --- such as **OpenAPI/Swagger**, **GraphQL schema**, or **gRPC proto definitions**. Validate the specification using appropriate tools (Swagger Editor, Spectral, Redocly, etc.) and provide it as a version-controlled file (YAML/JSON).

3. **Document each API endpoint with meaningful examples**, including at minimum:
   - sample requests
   - sample responses
   - HTTP status codes
   - error messages
   - data model descriptions

   Make sure your examples reflect real-world usage and cover both typical and edge-case scenarios.

4. **Include a minimum of one "Getting Started" guide and at least one step-by-step integration tutorial**, showing how a developer would authenticate and interact with the API in a practical workflow.

5. **If the API supports multiple operations or resources, include a high-level architecture overview**, such as:
   - system context diagram
   - request flow diagram
   - explanation of modules/resources

   This overview should help readers understand how the API fits into its broader system.

6. **Publish or prepare the documentation in a developer-accessible format**, such as:
   - an online documentation site (GitBook, Docusaurus, Redoc, Swagger UI)
   - a well-structured Markdown documentation repository

   The deliverable must be clean, structured, and operational.

7. **Describe the documentation strategy in your written report**, including tools used, standards followed, naming conventions, versioning approach, and formatting rules. Evaluate any known gaps or limitations in the documentation.

8. **Follow a consistent formatting and naming convention across all source files**, including clear folder structure (e.g., /reference, /guides, /examples, /schemas), ensuring traceability and maintainability.

---

## Maximum Requirements (for the Highest Grade)

1. **Deliver a highly comprehensive API documentation system**, including not only reference docs but also conceptual guides, best practices, tutorials, onboarding flows, release notes, and versioning documentation. Demonstrate mastery of information architecture and developer experience (DX) design.

2. **Thoroughly describe advanced topics**, such as:
   - complex request flows
   - pagination strategies
   - rate limits
   - authentication/authorization deep dive
   - error taxonomy
   - idempotency
   - versioning strategy

   Show deep understanding of API design principles and standards.

3. **Include detailed diagrams and service interaction descriptions**, for example:
   - sequence diagrams
   - component diagrams
   - dependency maps
   - request--response lifecycles

   For multi-service or microservice APIs, include cross-service contract explanations.

4. **Enhance API quality using advanced documentation tools or methodologies**, such as:
   - API linting or schema validation (Spectral, Redocly CLI)
   - contract testing definitions (e.g., Pact contracts)
   - auto-generated examples
   - API mock servers
   - developer sandbox environments

---

## Major Errors and Shortcomings Affecting Evaluation

| **Category**         | **Example of Issue**                                      | **Penalty**  |
|----------------------|-----------------------------------------------------------|--------------|
| **Completeness**     | Key endpoints undocumented; missing request/response examples; incomplete data models | **-2 points** |
| **Accuracy**         | Incorrect endpoint descriptions, parameters, or status codes; mismatched examples vs. actual API behavior | **-1 point**  |
| **Structure & Navigation** | Poor documentation organization; unclear hierarchy; missing TOC; hard-to-find sections | **-1 point**  |
| **Specification Quality** | Invalid or inconsistent OpenAPI/Swagger schema; schema fails validation tools | **-1 point**  |
| **Developer Experience** | Missing authentication guide, onboarding flow, or integration tutorial | **-1 point**  |
| **Examples**         | Missing or trivial example requests/responses; examples not runnable or inconsistent | **-2 points** |
| **Versioning & Updates** | No versioning strategy or missing changelog; inconsistent endpoint versions | **-1 point**  |
| **Security Documentation** | Missing authentication/authorization details, unclear token handling, or missing security warnings | **-2 points** |
| **Error Handling**   | Error codes undocumented or incomplete; no explanation of error structure or recovery steps | **-1 point**  |
