<!-- prev: frontend.md | next: refined-ux.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for adaptive UI. Must support mobile, tablet, and desktop.

    :school: **Staff:** Assessment rubric for multi-device UI support.

    **Prerequisites:** UI framework chosen. Screen layouts defined.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Adaptive UI Requirements (Web/Mobile)

**UI Design Specification**

*Adaptive UI makes sure the interface displays correctly and conveniently on devices with different screen sizes, pixel densities, and orientations.*

*Your goal is to keep functionality, visual consistency, and usability regardless of the device type.*

---

## Minimum Requirements for a Passing Grade

### General Criteria

Support 3 main device types (mobile phone, tablet, desktop). For mobile applications, support common aspect ratios (for example, 16:9, 21:9) and portrait/landscape modes.

**What is checked:**
- The interface displays correctly when the screen resolution and orientation change. (No overlapping elements.)
- Relative units are used.
- The interface works correctly when the browser zoom or system settings change.

### Visual Criteria

Scale fonts, icons, and images used in the application without distortion. Apply a consistent color palette and typography across all devices.

**What is checked:**
- The final result of how images display on different devices.
- The minimum size of interactive elements for small touch-screen devices (at least 44px).
- Contrast and readability on different backgrounds and compliance with the WCAG 2.1 standard, level AA (at least 4.5:1 for text).
- A consistent color palette and typography is used across all devices.

### Structural Criteria

Interactive UI elements and static content blocks must adjust to the current screen resolution and orientation. Make sure the main navigation is available on all devices.

**What is checked:**
- The interface is built on a responsive grid.
- Blocks scale properly when the screen width changes.
- The main navigation is always available.

---

## Maximum Project Requirements

### Addition to General Criteria

- Support any screen type (including 4K, ultrawide, foldable, smartwatch).
- Implement automatic device detection (pixel density, orientation, aspect ratio).
- Use a Design System.

### Addition to Visual Criteria

- Implement light/dark theme support.
- Use SVG images for icons.
- Allow users to customize display settings (scale, color scheme).

### Addition to Structural Criteria

- Rebuild the application layout when the screen size changes.
- Adapt the mobile version for one-hand use and for platform system patterns (Android bottom navigation / iOS tab bar).
- UI elements must not be covered by the keyboard.

---

## General Document Requirements

Submit the final document in one of these formats:
- **Figma project** (preferred);
- **Adobe XD / Sketch** file;
- **PDF export** of mockups (if online access is not possible).

All pages and components must have clear labels. Provide 3 variants for different devices. Create a library of reusable components. For interactive elements, show the appearance for different states.
