<!-- prev: adaptive-ui.md | next: ../04e-infrastructure/cicd.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for UX design. Requires interaction scenarios, prototypes, user research.

    :school: **Staff:** Assessment rubric for UX quality.

    **Prerequisites:** UI design started. User personas defined.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Refined UX Requirements

**UX Design Specification**

*Document the interaction logic, interface structure, navigation, and UX requirements.*

---

## Minimum Requirements for a Passing Grade

### Interaction Design, Scenarios (User Flow, CJM), and Prototyping

> Describe 2-3 key scenarios of user interaction with the product: from start to result. For each scenario, describe the user's steps and actions.

**What is checked:**
- Transition logic: steps follow in order, without "jumps"; the scenario fully covers the user's task.
- Scenario completeness: there is a starting point, a main flow, alternative flows, error handling, and a successful ending.
- Step justification: each step is justified from the user's goal perspective.
- Link to navigation: every screen or action from the scenario appears on the navigation diagram.

### Visual Style and Component Library

> Develop a structure of visual elements: color palette, typography, grid, components, and states. Keep a consistent visual style across all elements.

**What is checked:**
- No duplication: there are no repeated or redundant elements.
- Visual hierarchy: important elements are logically highlighted, and the interface is easy to read.
- The component library design follows the general visual style principles.

### Screen Prototypes (Wireframes / Mockups)

Develop at least 3 key screens that show all elements and include mock content. All interactive elements must include information about the result of interacting with them.

**What is checked:**
- Error messages: error texts are present and clear to the user.
- Data validation: there are warnings and restrictions to prevent errors.
- Visual hierarchy: important elements are highlighted, and the interface is easy to read.

---

## Maximum Project Requirements

### Target Audience Analysis (User Research) and Personas

Define research goals, tasks, and methods; describe the sample and context. Analyze the data and identify key insights, user needs, and problems. Create 1--2 realistic personas that reflect user goals, behavior, and motivation.

**What is checked:**
- Research depth and the soundness of chosen methods
- How realistic the personas are and how they connect to the research

### Usability Testing

> Define goals, hypotheses, tasks, and participant profiles. Conduct testing with users, record results and metrics (success rate, time, errors), identify problems, set priorities, and apply improvements to the prototype.

**What is checked:**
- How thoroughly the test was prepared.
- Test analysis results

### Navigation Scheme (Information Architecture / Sitemap)

> Develop a screen or page structure (sitemap, screen tree, flowchart) that shows:
- all application sections and the connections between them;
- primary and secondary transitions (main menu, submenus, modal windows);
- screen states (authorized / not authorized, empty / filled pages).

> Identify the navigation patterns --- what is the main way users move around (menu, tabs, buttons, swipes, etc.).

**What is checked:**
- Structure completeness: navigation covers all scenarios from the previous section.
- Optimal depth: the user can complete key actions in the fewest clicks while following core usability principles.
- Predictability and consistency: the structure matches user expectations.
- State management: navigation element visibility is correct for different roles and states (guest, authorized user, error, loading).
- Naming consistency: sections have clear and uniform names.

---

## Additional Requirements

### Addition to Interaction Design

- Interactive prototypes (for example, Figma)

### Addition to Screen Prototypes

> Work on application accessibility:
- sufficient contrast between text and background;
- readable fonts;
- duplication through color, text, sound, etc.;
- minimum size of interactive zones;
- keyboard navigation support (where needed).

> Work on exception handling: plan for empty states, network errors, and loading.

---

## General Document Requirements

- Format the document so it is structured and readable, as a UX Design Specification (PDF) or a project in Figma/Miro with comments.
- All diagrams and mockups must have labels and be linked together (scenarios -> navigation -> screens).
- For each UX decision, provide a short justification ("why this approach").
- At the end of the document, include an accessibility checklist (based on WCAG guidelines or your own logic).
