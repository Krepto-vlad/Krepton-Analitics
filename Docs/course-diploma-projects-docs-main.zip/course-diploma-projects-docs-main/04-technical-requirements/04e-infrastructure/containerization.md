<!-- prev: cicd.md | next: cloud.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for containerization. Docker images, compose files, orchestration.

    :school: **Staff:** Assessment rubric for container-based deployment.

    **Prerequisites:** Application has deployable components.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Containerization Requirements

**Notes and Context**

Containerization must provide reproducible deployment of the application on any machine with Docker. All project components (except third-party services like Redis/PostgreSQL, where you can use official images) must be packaged into containers.

---

## Minimum Requirements (5 points)

### Docker Images

**Required build rules:**
- Create a separate Dockerfile for each service
- Separate layers correctly (unchanged content first, frequently changed content last)
- Use .dockerignore to exclude unnecessary files
- Use ENV variables for all settings (no hardcoded values)
- Set up Volumes for persistent data
- Configure ports correctly (EXPOSE)

**Size optimization:**
- Image size must be reasonable (<1GB backend, <500MB frontend)
- Remove temporary files and package manager cache after installation
- Do not include unnecessary tools (compilers, debug tools, IDE)
- Use Multi-stage build where applicable

**Security:**
- Do not store sensitive data in images (passwords, tokens, keys)
- Run as a non-root user (USER directive)
- Version your images (do not use latest in production)

### Docker Compose

**Required elements:**
- docker-compose.yml for local deployment
- All services start with docker-compose up
- Correct dependencies between services (depends_on)
- Isolated networks for components
- Volumes for the database and uploaded files
- Environment variables through .env file
- .env.example with sample values

### Documentation

**You must document:**
- README with launch instructions
- Description of each image and its purpose
- List of all ENV variables with descriptions
- Container architecture diagram
- Resource requirements (minimum RAM/CPU)

---

## Maximum Requirements (10 points)

*All minimum requirements PLUS:*

### Advanced Optimization

- **Custom base image** with pre-configured dependencies
- **Conditional caching** without rebuild when code is unchanged
- **Build pipeline** with the ability to clean up old images
- **Distroless or Alpine** base images where possible
- **Layer caching** strategy documented

### Production-ready Features

- **Healthcheck** for each container
- **Resource limits** (memory, CPU) for containers
- **Graceful shutdown** with signal handling
- **Automatic restart** on failure (restart policies)
- **Logging** in structured format (JSON)

### Extended Configuration

- Separate compose files for dev/test/prod environments
- **Override files** for different configurations
- **Secrets management** (Docker secrets or external vault)
- **Network policies** for additional isolation

### Monitoring and Debugging

- Integration with a monitoring system (Prometheus metrics)
- Centralized logging
- Debug mode with debugger connection support
- Performance metrics for containers

---

## Restrictions --- What You Must Not Do

### Critical Security Mistakes

- Store secrets in Dockerfile, images, or commits
- Use the --privileged flag without strong justification
- Leave default passwords in containers
- Publish private images to public registries

### Architecture Mistakes

- Run containers as root without justification
- Use the latest tag for production
- Hardcode paths, URLs, and configurations
- Make containers stateful without volumes
- Use one container for everything (anti-pattern "fat container")

### Optimization Mistakes

- Copy node_modules, venv, .git into the image
- Ignore layer order (frequently changed content first)
- Install packages at runtime instead of build time
- Skip clearing package manager cache after installation
- Use images with known CVE vulnerabilities

### Implementation Mistakes

- Missing .dockerignore
- Ignoring exit codes and OS signals
- Logging to files instead of stdout/stderr
- Using COPY . . without filtering
- Running multiple processes in one container without a supervisor

---

## Presentation Format

### Docker Compose File

- Full docker-compose.yml with comments
- Diagram of the build pipeline and service interactions

### Image Descriptions

**For each image, provide:**
- Purpose and functionality
- Base image and the reason for choosing it
- Final image size
- Main optimizations

### Container Descriptions

**For each container, provide:**
- Role in the system
- External and internal ports
- Volumes and their purpose
- Environment variables
- Healthcheck strategy
- Resource limits (if set)

### Metrics

- Image build time
- Image sizes before and after optimization
- Cold start time for the entire system
- Resource usage at runtime
