<!-- prev: containerization.md | next: microservices.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for cloud deployment. Cloud provider, scaling, monitoring.

    :school: **Staff:** Assessment rubric for cloud infrastructure.

    **Prerequisites:** Application ready for deployment. Cloud provider selected.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Cloud Diploma Project Requirements

**Scope and Goals**

You will use this document to understand the expectations and evaluation criteria for diploma projects that include cloud technologies.

**This document defines:**
- Minimum requirements -- mandatory criteria you must meet to obtain a passing grade (grade = 5).
- Maximum requirements -- advanced criteria to achieve the highest grade (grade = 10).
- Major errors and shortcomings -- critical issues resulting in penalties.

---

## Minimum Requirements (for a Passing Grade)

1. Demonstrate your ability to deploy, configure, and operate an application in a cloud environment. You may use any cloud provider, including AWS, Azure, GCP, Digital Ocean, Render, Fly.io, or similar.

2. Deploy at least one application component (backend, frontend, or full stack) to a cloud platform, and ensure the deployed system is accessible to reviewers through a public URL or IP address.

3. Prepare clear documentation describing all deployment steps, configuration actions, and instructions necessary to reproduce the environment.

4. Use at least one managed cloud service, such as object storage, a managed database, serverless functions, or a message queue.

5. Store all sensitive configuration values securely using cloud-native mechanisms, ensuring that credentials are not exposed in your project repository.

6. Maintain your project in a Git repository with a visible commit history, and include in the documentation a description of the cloud architecture and all deployed resources.

7. Ensure the deployed application remains consistently reachable during evaluation, and configure appropriate network settings such as firewall rules, security groups, and port access to ensure secure availability.

8. Ensure that no unnecessary paid cloud resources remain running during or after evaluation.

---

## Maximum Requirements (for the Highest Grade)

1. Demonstrate advanced cloud deployment by running the full application stack using containers or orchestration tools and integrating CI/CD pipelines to ensure automated, reliable delivery.

2. Incorporate at least two different managed cloud services, showing your ability to design and operate a multi-service cloud architecture.

3. Use Infrastructure as Code to provision and configure resources reproducibly, employing tools such as Terraform, CloudFormation, Ansible, or equivalent technologies.

4. Include cloud-native monitoring and logging, implement automated restarts or auto-scaling where appropriate, and demonstrate basic fault-tolerance testing to validate system resilience.

5. Address security and cost considerations by applying proper IAM roles and least-privilege principles, minimizing unnecessary cloud expenses, and documenting all relevant security measures.

6. Provide clear evidence of the cloud environment through screenshots or similar materials, ensuring all sensitive information (such as access keys or tokens) is properly hidden or redacted.

7. Provide scripts or configurations enabling full reproducibility of the deployed environment.

---

## Major Errors and Shortcomings Affecting Evaluation

| **Category**      | **Example of issue**                                 | **Penalty**  |
|-------------------|-----------------------------------------------------|--------------|
| Deployment        | Application not reachable via cloud URL             | -2 points    |
| Cloud integration | No use of any managed cloud service                 | -1 point     |
| Documentation     | Missing cloud setup description                     | -1 point     |
| Security          | Credentials exposed in repository                   | -2 points    |
| Technology        | Using legacy or unsupported cloud services          | -1 point     |
| Reliability       | Application fails after restart or deployment       | -1 point     |
| Architecture      | Hardcoded local paths, no environment variables     | -1 point     |
| Cost control      | Running unnecessary resources leading to waste      | -1 point     |
