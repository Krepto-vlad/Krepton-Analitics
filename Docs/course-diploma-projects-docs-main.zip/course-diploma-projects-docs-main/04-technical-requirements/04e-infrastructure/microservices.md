<!-- prev: cloud.md | next: ../04f-testing/auto-tests.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for microservices. Independent deployable services, async communication.

    :school: **Staff:** Assessment rubric for microservice architecture.

    **Prerequisites:** Architecture decision to use microservices (justified).

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Microservice Architecture

**Notes and Context**

Microservice architecture fits projects with clear separation of business domains and a need to scale components independently. Do not use microservices just for the sake of it --- the architecture must solve specific problems in your project.

**Important:** You need at least 3 services to demonstrate a distributed system. Simply splitting frontend/backend/db does NOT count as microservice architecture.

---

## Minimum Requirements (5 points)

### Documentation

**Required sections:**
- **Architecture diagram:** all services, their interactions, protocols
- **Domain model:** bounded contexts
- **API documentation:** contracts between services (OpenAPI/AsyncAPI)
- **Deployment diagram:** how services are deployed
- **Decomposition rationale:** why this specific split was chosen

### Architecture

**Service separation:**
- At least 3 business services (not counting infrastructure services)
- Each service is responsible for a separate business domain
- Services can work independently (loose coupling)
- No shared database (each service has its own database or schema) --- or a reason why sharing is necessary

**Communication:**
- Synchronous: REST API or gRPC between services
- Clear interaction contracts (versioned APIs)
- Timeouts and retry policies for all calls
- Handling of unavailable dependent services
- **Rate limiting** on API Gateway or service entry points (basic request throttling to prevent cascade failures)

### Implementation

**Each service must:**
- Have its own codebase (can be in a monorepo)
- Build into a separate Docker image (if the containerization criterion is chosen)
- Have an independent database or isolated schema
- Provide health/ready endpoints
- Log with a correlation ID for tracing

**API Gateway or entry point:**
- Single entry point for external clients
- Request routing to services
- Basic authentication/authorization
- Rate limiting (requests per second/minute per client)

### Error Handling

- Graceful degradation when a service is unavailable
- Return partial results where possible
- Correct HTTP error codes
- Centralized error logging

### Testing

- Unit tests for each service
- Integration tests for critical flows
- Contract testing between services

### Restrictions

**What you must not do:**
- Synchronous call chains longer than 3 services
- Direct access to another service's database
- Shared libraries with business logic
- Distributed transactions (2PC)
- A monolith that is only split into folders

---

## Maximum Requirements (10 points)

*All minimum requirements PLUS at least **2-3 directions**:*

### Direction 1: Asynchronous Communication

- Message broker (RabbitMQ, Kafka, NATS)
- Event-driven architecture with domain events
- Pub/Sub pattern for loose coupling
- Dead letter queues for failed messages
- Handler idempotency
- Event sourcing (optional)

### Direction 2: Resilience Patterns

- Circuit breakers (Hystrix pattern)
- Bulkheads for resource isolation
- Rate limiting between services
- Retry with exponential backoff
- Timeout management
- Fallback mechanisms

### Direction 3: Observability

- Distributed tracing (Jaeger/Zipkin)
- Correlation IDs across all services
- Centralized logging (ELK/Loki)
- Metrics collection (Prometheus)
- Custom business metrics
- Service dependency mapping

### Direction 4: Advanced Patterns

- Saga pattern for distributed transactions
- CQRS for separating reads and writes
- API composition pattern
- Backend for Frontend (BFF)
- Service registry and discovery
- Database per service with synchronization

### Direction 5: API Management

- Advanced API Gateway (Kong, Zuul)
- Rate limiting per client
- API versioning strategy
- Request/Response transformation
- Caching at the gateway level
- OAuth2/JWT authentication

---

## Recommendations

**When you do NOT need microservices:**
- Simple CRUD application
- No clear domain boundaries

**Good decomposition examples:**
- **E-commerce:** Orders, Inventory, Payments, Users, Notifications
- **Streaming:** Content, Users, Recommendations, Analytics, Billing
- **Ride-sharing:** Rides, Drivers, Passengers, Payments, Tracking
- **Food delivery:** Restaurants, Orders, Delivery, Payments, Reviews

**Anti-patterns to avoid:**
- Entity services (UserService, ProductService)
- Services that are too small (CRUD for a single table)
- Services that are too large (mini-monoliths)
- Circular dependencies between services
