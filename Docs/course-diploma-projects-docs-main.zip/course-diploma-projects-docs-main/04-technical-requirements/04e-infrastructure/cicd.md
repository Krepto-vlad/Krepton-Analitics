<!-- prev: ../04d-frontend-and-ux/refined-ux.md | next: containerization.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for CI/CD pipelines. Automated build, test, and deploy.

    :school: **Staff:** Assessment rubric for CI/CD implementation.

    **Prerequisites:** Code repository set up. Build tools configured.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# CI/CD

**Notes and Context**

CI/CD should show **engineering culture**, automation, fewer manual steps, and standard DevOps practices.

Important:
You **do not need** complex infrastructure (Kubernetes, clouds). But you must show a **meaningful pipeline**, real automation, and correct deployment.

Minimum:
- CI (build + tests) --- required
- CD (deploy) --- welcome, but can be simplified: deploy to a server, containerization, or publishing artifacts.

---

## Minimum Requirements (5 points)

### Documentation

**Required sections:**
- **CI/CD pipeline diagram**
  Build -> tests -> artifact creation -> deploy.
- **Description of the tool you use**
  GitHub Actions, GitLab CI, Azure DevOps, Jenkins, Bitbucket Pipelines, or other.
- **What is automated and why**
  Explain each stage.
- **List of artifacts**
  Docker images, dist files, release artifacts, build artifacts.
- **Description of environments**
  Dev / Test / Production (or equivalent), even if environments are simulated.

### CI/CD Pipeline Architecture

**Must include at minimum:**

**CI (at least 3 stages)**

1. **Code checks**
   - Lint (ESLint, TSLint, SonarLint)
   - Format check (Prettier)

2. **Build**
   - dotnet build, npm build, mvn package, etc.

3. **Testing**
   - Unit tests --- required
   - e2e / integration --- if available

**CD (at least one type)**

- Deploy to:
  - server (SSH + copy artifacts)
  - Docker (build and run container)
  - cloud (Netlify, Vercel, Render, Fly.io, Azure, AWS, GCP)
  - local server with automatic build artifact updates

CD can be **manual (manual trigger)** --- this is acceptable.

### CI/CD Implementation

Each pipeline must:
- Start automatically:
  - on push,
  - on pull request,
  - manually --- if needed.
- Use **caching** for dependencies:
  npm cache, dotnet nuget cache, Gradle cache, etc.
- Produce artifacts:
  - build output,
  - Docker image,
  - zip with artifacts.
- Have *at least one* form of deployment:
  - Docker compose
  - GitHub Pages (for FE)
  - Vercel/Netlify
  - Self-hosted server
  - Azure WebApp / AWS ECS / GCP CloudRun

### Quality and Error Handling

- The pipeline must **fail** on build or test errors.
- Stage logs must be clear and readable.
- CI reports must show:
  - number of tests
  - linter results
- Handle deployment errors:
  - cancel deployment on a failed build
  - check that the container or server started successfully

### Security

**Minimum requirements:**
- Store secrets (passwords, tokens) in:
  - GitHub Secrets,
  - GitLab Variables,
  - Jenkins credentials,
  - or a similar secure storage
- No secrets in code or YAML files
- Include at least one static security analysis:
  - npm audit
  - dotnet list package --vulnerable
  - pip audit
  - or SonarCloud (optional)

### Restrictions

**What you must not do:**
- Upload artifacts manually
- Store secrets in the repository
- CI/CD config as "one command inside one job"
- No tests
- No pipeline documentation
- Fully manual deployment without automation

---

## Maximum Requirements (10 points)

*Complete all minimum requirements **plus** at least two directions below.*

### Direction 1: Advanced CD

- Blue/Green deployment
- Canary releases
- Zero downtime deploy
- Rollback mechanisms
- Automatic database migration in CD

### Direction 2: Containerization and Orchestration

- Docker multi-stage build
- Docker Compose with multiple services
- Kubernetes:
  - Deployments
  - Services
  - Ingress
- Automatic deployment to Kubernetes through CI

### Direction 3: Observability

- Integration with monitoring:
  - Grafana
  - Prometheus
  - Elastic Stack
- CI/CD logs in a separate storage
- Auto-tagging containers with versions
- Slack/Teams/Discord notifications about pipeline status

### Direction 4: Quality Gates

- SonarQube or SonarCloud analysis
- Test coverage > 70%
- Code smells, bugs, vulnerabilities
- PR Quality rules:
  - successful pipeline required
  - code review required

### Direction 5: Infrastructure as Code

- Terraform
- Pulumi
- Ansible
- Automated environment creation
- Versioned environments
