<!-- prev: cryptography.md | next: ../../05-deliverables/official-requirements.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for ML models. Dataset handling, training, metrics, deployment.

    :school: **Staff:** Assessment rubric for machine learning implementation.

    **Prerequisites:** Prediction task defined. Dataset sourced.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Machine Learning (ML) Diploma Project Requirements

**Scope and Goals**

You will use this document to understand the expectations and evaluation criteria for diploma projects in the field of Machine Learning (ML).

**This document defines:**
- Minimum requirements -- mandatory criteria you must meet to obtain a passing grade (grade = 5).
- Maximum requirements -- advanced criteria to achieve the highest grade (grade = 10).
- Major errors and shortcomings -- typical critical issues resulting in penalties.

---

## Minimum Requirements (for a Passing Grade)

1. Apply at least one modern ML method using frameworks such as Scikit-learn, TensorFlow, PyTorch, or similar. Acceptable approaches include regression, classification, clustering, or basic neural networks.

2. Provide a clearly described dataset containing at least 1,000 records (or equivalent complexity). Split the dataset into training, validation, and test subsets. Justify the choice and source of data.

3. Include data cleaning, normalization/scaling, encoding, and feature extraction or selection. Document and justify all steps in terms of their impact on model performance.

4. Train at least one ML model, explain hyperparameter choices, and evaluate performance using suitable metrics such as accuracy, Precision, Recall, F1-score, ROC-AUC, RMSE, MAE, etc. Include validation results, confusion matrices, or learning curves.

5. Provide a simple interface to interact with the trained model -- command-line tool, web app, or API endpoint -- that accepts new input and outputs predictions.

6. Implement structured logging of model input/output and handle runtime exceptions (e.g., invalid input, missing files).

7. Store the entire project in a Git repository with visible commit history. Include clear installation and launch instructions ensuring reproducibility.

8. Prepare a short report (Markdown or Word) including dataset description, model architecture, preprocessing steps, and usage guide.

---

## Maximum Requirements (for the Highest Grade)

1. Deploy the trained model as a web service or an interactive app (e.g., Streamlit, Flask, FastAPI, or Gradio). Ensure the interface allows running predictions and showing evaluation metrics.

2. Apply hyperparameter optimization techniques (GridSearchCV, Random Search, Bayesian optimization). Compare multiple models and justify your final choice.

3. Use tools like MLflow, TensorBoard, or Weights & Biases to log experiments, visualize training progress, and compare runs.

4. Implement automated testing and deployment using CI/CD pipelines (GitHub Actions, GitLab CI, Jenkins). Ensure that the model and code versions are synchronized and reproducible.

5. Demonstrate optimization of model inference (e.g., quantization, batching, GPU acceleration). Measure inference time before and after optimization.

6. Include feature-importance plots, SHAP or LIME explanations, and a brief note on data bias and ethical use of ML.

7. Provide unit and integration tests with at least 70% coverage. Attach CI/CD reports or test coverage screenshots as evidence.

8. Present meaningful visualizations -- feature importance, learning curves, confusion matrices -- and a working demo app.

9. Compare multiple ML approaches, analyze performance differences, and suggest future improvement directions.

---

## Major Errors and Shortcomings Affecting Evaluation

| **Category**     | **Example of issue**                               | **Penalty**  |
|------------------|----------------------------------------------------|--------------|
| Model functionality | Model fails to train or produce valid predictions | -2 points    |
| Dataset & evaluation | No dataset description or missing performance metrics | -1 point |
| Documentation    | Missing or incomplete project description / API docs | -1 point    |
| Technology       | Use of outdated or unsupported frameworks          | -1 point     |
| Ethics & validation | No consideration of data bias or explainability   | -1 point     |
| Logic            | Static or hardcoded outputs instead of real predictions | -2 points |
| Code quality     | Poorly structured or non-modular code              | -1 point     |
| Testing          | No tests or coverage < 70%                         | -1 point     |
