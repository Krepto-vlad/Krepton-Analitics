<!-- prev: ai-assistant.md | next: machine-learning.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for cryptography. Encryption, digital signatures, secure protocols.

    :school: **Staff:** Assessment rubric for security implementation.

    **Prerequisites:** Security requirements defined. Crypto use case identified.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# Diploma Project Requirements: Cryptography Applications in IT

## Project Objective

You are required to design, implement, and evaluate an IT solution that integrates cryptographic mechanisms appropriate to its purpose and context. Your project must demonstrate a strong linkage between the theoretical foundations of cryptography and their practical application in securing information systems, communications, or data integrity.

---

## Learning Outcomes

Upon completion of the project, you should be able to:

- Demonstrate a comprehensive understanding of key cryptographic principles, including symmetric and asymmetric encryption, hashing, digital signatures, and key management.
- Analyze and justify the selection of a specific cryptographic approach relative to system requirements, security constraints, and performance trade-offs.
- Implement a cryptographic solution using appropriate technologies, frameworks, or libraries.
- Design and execute test cases evaluating the strength, efficiency, and correctness of your implemented cryptographic mechanisms.
- Critically assess the adequacy and limitations of the chosen cryptographic method in real-world conditions.

---

## Project Components and Deliverables

### Theoretical Foundation

- Present a concise review of cryptographic concepts relevant to your project.
- Discuss existing algorithms and frameworks (e.g., AES, RSA, ECC, SHA-3, homomorphic encryption) and justify the selection of one or more approaches.
- Explain key mathematical principles or cryptographic primitives underlying the chosen algorithms.

### System Design and Implementation

- Provide a system architecture diagram illustrating where and how cryptography is applied within your solution.
- Implement the chosen cryptographic components in a working software prototype.
- Document all security assumptions, key management strategies, and dependencies.

### Justification of Cryptographic Choice

- Explicitly describe the rationale for the chosen cryptographic method(s), referencing:
  - Security requirements (confidentiality, integrity, authentication, non-repudiation).
  - Expected threat model and adversarial capabilities.
  - Performance and resource considerations (e.g., speed, memory, energy use).
  - Compliance with relevant standards (e.g., NIST, ISO/IEC).

### Testing and Evaluation

- Develop and execute test cases demonstrating the functionality and robustness of your cryptographic implementation.
- Conduct performance analysis, testing metrics such as encryption/decryption latency, throughput, and computational complexity.
- Evaluate resilience by simulating attacks (e.g., brute force, side-channel, or chosen plaintext/ciphertext scenarios) where applicable.
- Interpret results in comparison to theoretical expectations and current industry benchmarks.

### Documentation and Presentation

- Submit a comprehensive report containing:
  - Abstract, introduction, literature review, methodology, results, discussion, and conclusion.
  - Clear references to all used sources following academic citation standards.
- Provide source code with documentation and comments.
- Prepare an oral defense or presentation demonstrating your implementation and validation process, supported by empirical results.

---

## Assessment Criteria

| **Criterion**           | **Weight** | **Description**                                                      |
|-------------------------|------------|----------------------------------------------------------------------|
| Theoretical foundation  | 20%        | Demonstrates clear understanding and application of cryptographic theory. |
| Design and justification| 25%        | Appropriateness and justification of chosen cryptographic approach.  |
| Implementation quality  | 25%        | Functionality, code quality, and integration of cryptographic features. |
| Testing and evaluation  | 20%        | Depth and rigor of test cases demonstrating adequacy and strength.   |
| Documentation and presentation | 10% | Clarity, completeness, and academic rigor of the report and defense. |
