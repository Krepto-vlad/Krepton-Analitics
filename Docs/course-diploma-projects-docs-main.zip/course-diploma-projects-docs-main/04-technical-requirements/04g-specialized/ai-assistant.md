<!-- prev: ../04f-testing/testing.md | next: cryptography.md -->

!!! abstract "Stage 3 of 7 — Build & Get Assessed | Weeks 4–18"
    :mortar_board: **Students:** Grading rubric for AI-powered features. Prompt engineering, evaluation, integration.

    :school: **Staff:** Assessment rubric for AI implementation.

    **Prerequisites:** AI use case defined in business analysis.

    [Full Journey](../../student-journey.md) | [Staff Guide](../../staff-guide.md)

# AI Assistant / Chatbot

**Notes and Context**

An AI assistant must be a complete solution with a well-designed user experience. It should not be a simple wrapper over a language model API. Your project must show that you understand how LLMs work, prompt engineering, and modern approaches to building dialog systems.

**Important:** You choose the domain and assistant type (text, voice, or multimodal). However, your choice must be well-reasoned and must fit the task you selected.

---

## Minimum Requirements (for 5 points)

### Documentation

**Required sections:**
- **Assistant description:** purpose, target audience, main use cases
- **Solution architecture:** component interaction diagram, model choice and reasoning
- **Prompt Engineering documentation:**
  - System prompt with an explanation of each part
  - Prompt templates for different scenarios
  - Examples of typical dialogs
- **API documentation:** endpoint descriptions, request/response formats
- **System limitations:** what the assistant CANNOT do
- **User guide:** how to interact with the bot

### Design

**Architecture:**
- Use a modern LLM through an API (OpenAI, Anthropic, Google, open-source)
- Multi-layer architecture: UI -> Backend -> LLM API
- Separate business logic from model integration

**Prompt Engineering:**
- Design a system prompt that defines the assistant's behavior
- Prepare at least 3 different prompt templates for different scenarios
- Handle edge cases (empty input, overly long messages, inappropriate content)

**UX/UI:**
- Build an intuitive chat interface (web or messenger)
- Show status indicators: typing, processing, error
- Allow the user to start a new conversation

### Implementation

**Core functionality:**
- Process user text queries
- Generate relevant responses through the model API
- Basic input validation (length, format)
- Handle API errors (timeouts, rate limits, unavailability)
- Log requests and responses

**Security:**
- Store API keys in environment variables
- Add basic prompt injection protection (filter dangerous patterns)
- Set up rate limiting to prevent abuse

### Test Data and Scenarios

- Prepare at least 10 example dialogs that show the assistant's capabilities
- Create test scenarios for different types of requests
- Include examples of how the system handles incorrect requests

### Usage

- Response time must be under 10 seconds for standard requests
- Support at least 10 concurrent users
- Handle Cyrillic characters correctly (if applicable)
- Keep conversation history within a session

### Restrictions

**What you must NOT do:**
- A simple proxy to ChatGPT/Claude API without any processing
- No prompt engineering (raw forwarding of questions)
- Hardcoded answers or fake AI
- API keys stored in source code
- Ignoring API errors
- No input validation

---

## Maximum Requirements (for 10 points)

*All minimum requirements PLUS:*

### Advanced Architecture

**Multiple models:**
- Use 2+ different models for different tasks
- Smart model selection based on the request
- Fallback mechanism when the primary model is unavailable
- Cost optimization through choosing the right model

**RAG (Retrieval-Augmented Generation):**
- Integration with a vector DB (Pinecone, Weaviate, pgvector, ChromaDB)
- Document upload and indexing (PDF, TXT, MD)
- Semantic search over the knowledge base
- At least 100 documents/pages in the knowledge base
- Retrieval quality metrics (precision, recall)

**MCP (Model Context Protocol) or Tool Use:**
- Integration with external tools (calculator, search, API)
- Decide when to use tools
- At least 3 different tools/functions

### Advanced Processing

**Preprocessing:**
- Detect language and intent of the request
- Classify the request type
- Check for toxicity/inappropriate content
- Auto-correct typos

**Postprocessing:**
- Format responses (markdown, lists, tables)
- Fact-check critical information
- Add sources/references to responses
- Structured output (JSON for certain requests)

### Context Management

**Dialog history:**
- Full conversation context management
- Save history between sessions
- Smart context compression when limits are exceeded
- Allow references to previous messages

**Personalization:**
- User profiles with preferences
- Adapt response style to the user
- Remember important information about the user
- Settings: formality, response length, technical level

### Multimodality

*At least one additional input/output type:*
- **Images:** analyze uploaded images, generate images
- **Audio:** speech-to-text, text-to-speech integration
- **Documents:** process uploaded PDF/DOCX files
- **Structured data:** work with tables, CSV

### Monitoring and Analytics

**Metrics:**
- Dashboard with usage metrics
- Average response time, number of requests
- Popular topics/questions
- User satisfaction metrics (if feedback exists)

**Logging:**
- Structured logs (JSON)
- Request tracing (correlation ID)
- API cost monitoring
- Alerts on critical errors

### Optimization

**Performance:**
- Cache frequent requests
- Stream responses (print as they are generated)
- Async processing for heavy requests
- Load balancing under high load

**Cost optimization:**
- Automatic model selection by cost/quality
- Batch requests where possible
- Use embeddings cache for RAG

### Developer Documentation

- OpenAPI/Swagger specification
- Guide on how to add new prompts
- Documentation on extending functionality
- Performance benchmarks

---

## Common Mistakes and Issues

### Critical Security Mistakes

1. **API keys stored in code or repository**
   *Example:* api_key = "sk-xxxxx" directly in code
   **Minus 2 points**

2. **No prompt injection protection**
   *Example:* User input is passed directly without sanitization
   **Minus 1 point**

3. **Logging sensitive data**
   *Example:* Full user data in logs
   **Minus 1 point**

### Architecture Mistakes

4. **No API error handling**
   *Example:* The app crashes on 429 (rate limit) or timeout
   **Minus 1 point**

5. **Simple proxy with no added value**
   *Example:* response = openai.complete(user_input) and nothing else
   **Minus 2 points**

6. **No prompt engineering**
   *Example:* No system prompt, no context, no instructions
   **Minus 1 point**

### UX/Functionality Mistakes

7. **No processing status indicator**
   *Example:* The user cannot tell if the bot is working
   **Minus 1 point**

8. **Context loss within a session**
   *Example:* The bot forgets what was discussed 2 messages ago
   **Minus 1 point**

9. **No input validation**
   *Example:* Messages of any length are accepted; the app crashes on emoji
   **Minus 1 point**

### Implementation Mistakes

10. **Synchronous blocking processing**
    *Example:* The entire server waits for an OpenAI response for one user
    **Minus 1 point**

11. **No logging**
    *Example:* It is impossible to trace problems in production
    **Minus 1 point**

12. **Hardcoded configuration**
    *Example:* URLs, models, and parameters are hardcoded in the source
    **Minus 1 point**

### Documentation Mistakes

13. **No prompt documentation**
    *Example:* It is unclear which prompts are used and why
    **Minus 1 point**

14. **No description of system limitations**
    *Example:* It is not stated what the bot CANNOT do
    **Minus 1 point**

### Deployment Mistakes

15. **Application is not deployed or not accessible**
    *Example:* Works only on localhost
    **Minus 2 points**

---

## Recommendations

**For a successful defense:**
- Choose a specific domain and make the assistant an expert in it
- Show that you understand how LLMs work through good prompt engineering
- Demonstrate several interesting use cases, not just Q&A
- Always handle edge cases and errors
- Add at least one standout feature from the maximum requirements

**Examples of good topics:**
- Medical assistant with RAG over medical reference books
- Educational tutor with personalization based on the student's level
- HR assistant integrated with corporate systems
- E-commerce consultant with product catalog search
- Game master for text-based RPGs with world state management
