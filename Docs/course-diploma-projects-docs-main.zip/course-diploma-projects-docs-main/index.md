# Diploma Project Knowledge Base

!!! tip "Start here"
    :mortar_board: **Are you a student?** Start with your [Journey Map](student-journey.md) — it shows every step from topic selection to final defense.

    :school: **Are you staff?** See the [Staff Guide](staff-guide.md) — responsibilities by role and stage.

Welcome to the diploma project knowledge base. This site contains all course documentation — requirements, grading rubrics, organizational procedures, deliverable specs, and the thesis template — organized as a progressive learning arc.

Start at Section 1 and work forward; each section builds on the ones before it.

---

## Reading Path

| Section | Chapters | Time | What You'll Learn |
|---------|----------|------|-------------------|
| [1. Overview](01-overview/course-overview.md) | 2 | 6 min | Project types, complexity criteria |
| [2. Getting Started](02-getting-started/team-rules.md) | 3 | 4 min | Teams, supervisors, topic selection |
| [3. Process and Timeline](03-process-and-timeline/diploma-lifecycle.md) | 5 | 6 min | Milestones, assessments, slot booking, timeline |
| [4. Technical Requirements](04-technical-requirements/04a-business-and-docs/business-analysis.md) | 17 | 70 min | Grading rubrics for all 17 disciplines |
| [5. Deliverables](05-deliverables/official-requirements.md) | 5 + template | 18 min | Thesis, presentation, video, reviews |
| [6. Defense and Completion](06-defense-and-completion/final-deliverables-checklist.md) | 4 | 4 min | Final checklist, defense prep |
| **Total** | **36 + template** | **~108 min** | |

---

## Quick Links

- **Grading rubrics** — see [Technical Requirements](04-technical-requirements/04a-business-and-docs/business-analysis.md) (17 criteria across 7 domains)
- **Thesis template** — see [Thesis Template](05-deliverables/thesis-template/docs/index.md) (copy this into your own repo)
- **Self-evaluation template** — see [Criteria Template](05-deliverables/thesis-template/docs/02-technical/criteria/_template.md)
- **Final checklist** — see [Final Deliverables Checklist](06-defense-and-completion/final-deliverables-checklist.md)
