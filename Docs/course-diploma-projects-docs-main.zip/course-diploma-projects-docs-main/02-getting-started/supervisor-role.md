<!-- prev: team-rules.md | next: topic-changes.md -->

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Understand what your supervisor does and what they expect from you.

    :school: **Staff:** Your responsibilities as a supervisor — weekly standups, checkpoints, thesis review.

    **Prerequisites:** You are looking for or have been assigned a supervisor.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Project Supervisor

## Supervisor Qualifications

Your project supervisor can be:

- An SDC instructor with an academic degree (Master's, Candidate of Technical Sciences, or Doctoral)
- An instructor from another university with an academic degree (Master's, Candidate of Technical Sciences, or Doctoral)
- A specialist from another organization with at least 3 years of relevant practical experience in the field of the specialty (in this case, an academic degree is not required)

---

## Supervisor Responsibilities During the Diploma Project

### Choose a Topic Together with the Student

- Verify that you have collected the required number of complexity points from the topic and complexity requirements.
- Sign the application form and record all agreements using the provided template.

### Set Up a Regular Communication Process

- Hold **weekly meetings with the student** (standup format, at least 15 minutes).
  - Topics: what was planned, what was done, reasons for delays, blockers, whether help is needed.
  - Meetings must be documented in writing.
  - Rescheduling by 1–2 days is acceptable.

### Track Progress

- Conduct **4 progress reviews** (опроцентовки) according to the established schedule (progress milestones).
- Make sure the student **completes all required items** for the chosen topic and complexity level on time.
- If needed, direct the student to expert consultations in specific areas (UI, Backend, Frontend, etc.).

### Review the Explanatory Note

- **Mandatory proofreading** of the explanatory note in English.
  - Check the structure, terminology, language, and logical flow.
- The student must send the **final version** of the explanatory note to the supervisor **at least 5 working days** before the pre-defense.
- The supervisor reviews and signs off on the submitted version. If the student makes changes after sign-off, a new review cycle is required.
- **Versioning:** The supervisor should confirm which version (by date or commit hash) was reviewed.

### Admission Decision

- The supervisor decides on **admission to the pre-defense**:
  - Signs the title page if the student is admitted.
  - Provides a mandatory written explanation if the student is not admitted.
- **Final admission to the defense** is granted only after all required components (UI, Frontend, Backend, etc.) are approved by expert instructors.
