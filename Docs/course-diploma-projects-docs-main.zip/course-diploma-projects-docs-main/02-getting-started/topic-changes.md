<!-- prev: supervisor-role.md | next: ../03-process-and-timeline/diploma-lifecycle.md -->

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Read this if you need to change your topic before or after approval.

    :school: **Staff:** Policy for handling topic change requests.

    **Prerequisites:** You have started the topic selection process.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Diploma Topics and Deadlines for Changes

According to university regulations and branch office rules, you can change or adjust the topic at the following stages:

### Before the administrative deadline

You can change the topic and complexity criteria until **<date set by administration>**. To do this, submit a new topic application using the standard form with the current date and fill in all the information again.

### After the BA defense

After successfully defending the BA criterion before a committee, you may **change your project topic** — including switching to a completely different idea. If you change your topic, you must re-defend the BA criterion for the new topic. This is the last point where radical topic changes are allowed.

### After the pre-defense

After the pre-defense (a preliminary committee review before the final defense), you may only make **minor adjustments** to the topic wording or description — within 3 working days, and only if the committee recommends changes. **Radical changes to the topic, project scope, or project description are not allowed at this stage.** The pre-defense confirms the direction of your project; from this point, you refine and finalize.

- You must send all applications to [office@esdc.lt](mailto:office@esdc.lt). Always add your supervisor to the recipients.
