<!-- prev: ../01-overview/project-types-and-criteria.md | next: supervisor-role.md -->

!!! abstract "Stage 1 of 7 — Topic Selection | Weeks 1–2"
    :mortar_board: **Students:** Read this if you plan to work in a team (max 2 people).

    :school: **Staff:** Rules for team project supervision.

    **Prerequisites:** Decided whether to work alone or with a partner.

    [Full Journey](../student-journey.md) | [Staff Guide](../staff-guide.md)

# Team Work Requirements

- Diploma projects can be individual or team-based.
- A team project can have a maximum of 2 students.
- In a team, you and your partner work on one shared project. However, each of you works on a separate part. Each student prepares their own full explanatory note (пояснительная записка), graphical materials, and other deliverables.
- Each member of a team diploma project must defend their part individually.
- Both members of a team project must defend on the same day.
