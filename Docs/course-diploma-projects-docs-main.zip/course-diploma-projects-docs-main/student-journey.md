# Your Diploma Journey

This page shows your complete path from topic selection to final defense. Use it to find what you need right now.

## Journey Overview

| Stage | When | What You Do | Key Pages |
|-------|------|-------------|-----------|
| 1. Choose Your Topic | Weeks 1–2 | Select project type, pick 7+ criteria, find supervisor | [Course Overview](01-overview/course-overview.md), [Project Types](01-overview/project-types-and-criteria.md), [Team Rules](02-getting-started/team-rules.md) |
| 2. Get Approved | Week 3 | Submit application, get admin approval | [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md), [Topic Changes](02-getting-started/topic-changes.md) |
| 3. Plan & Start Building | Weeks 4–6 | Set up repo, start coding, Progress Review 1 | [Thesis Guide](05-deliverables/thesis-guide.md), [Technical Requirements](04-technical-requirements/04a-business-and-docs/business-analysis.md) |
| 4. Build & Get Assessed | Weeks 7–15 | Expert assessments, progress reviews, complexity check | [Expert Assessment](03-process-and-timeline/expert-assessment.md), [Booking Slots](03-process-and-timeline/booking-slots.md), [Timeline](03-process-and-timeline/timeline.md) |
| 5. Prepare Deliverables | Weeks 16–18 | Record video, create presentation, write thesis, deploy | [Video](05-deliverables/video-requirements.md), [Presentation](05-deliverables/presentation-requirements.md), [Official Requirements](05-deliverables/official-requirements.md) |
| 6. Pre-Defense | Week 19 | Present to committee, get reviewer contact | [Defense Preparation](06-defense-and-completion/defense-preparation.md), [Review Templates](05-deliverables/review-templates.md) |
| 7. Final Defense | Weeks 20–22 | Get reviews, upload to repository, defend | [Final Checklist](06-defense-and-completion/final-deliverables-checklist.md), [Repository Upload](06-defense-and-completion/repository-upload.md) |

---

??? success "Stage 1: Choose Your Topic (Weeks 1–2)"

    ### What you need to do

    - [ ] Read the [Course Overview](01-overview/course-overview.md) to understand the process
    - [ ] Choose your project type: web, mobile, or game application
    - [ ] Select **7+ complexity criteria** (teams: 10+, with 5 per member) from the list below
    - [ ] Check that your topic is not [prohibited](01-overview/project-types-and-criteria.md#what-is-not-allowed)
    - [ ] Find a [supervisor](02-getting-started/supervisor-role.md) and agree on your topic
    - [ ] If working in a team, read the [team rules](02-getting-started/team-rules.md)

    ### Criteria to choose from

    All criteria are listed in [Project Types and Criteria](01-overview/project-types-and-criteria.md). Here is the full list grouped by category:

    **Required (must include all 3):**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Business Analysis](04-technical-requirements/04a-business-and-docs/business-analysis.md) | Vision, problem statement, stakeholders, user stories, use cases |
    | [Backend](04-technical-requirements/04c-backend/backend.md) | Server-side framework, API, database, SOLID, 70% test coverage |
    | [Frontend](04-technical-requirements/04d-frontend-and-ux/frontend.md) | SPA with modern framework, state management, responsive layout |

    **Business & Docs:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [API Documentation](04-technical-requirements/04a-business-and-docs/api-documentation.md) | OpenAPI/Swagger spec, tutorials, architecture overview |

    **Data Layer:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Database](04-technical-requirements/04b-data-layer/database.md) | Schema design, migrations, roles, encryption (OLTP, OLAP, or NoSQL) |
    | [Real-time Analytics](04-technical-requirements/04b-data-layer/real-time-analytics.md) | Continuous event streams, WebSocket/SSE, live dashboards |

    **Frontend & UX:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Adaptive UI](04-technical-requirements/04d-frontend-and-ux/adaptive-ui.md) | 3 device types, responsive grid, relative units, WCAG contrast |
    | [Refined UX](04-technical-requirements/04d-frontend-and-ux/refined-ux.md) | Interaction scenarios, visual style, prototypes, user research |

    **Infrastructure:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [CI/CD](04-technical-requirements/04e-infrastructure/cicd.md) | Automated build, test, deploy pipelines |
    | [Containerization](04-technical-requirements/04e-infrastructure/containerization.md) | Docker images, compose files, orchestration |
    | [Cloud](04-technical-requirements/04e-infrastructure/cloud.md) | Cloud provider deployment, scaling, monitoring |
    | [Microservices](04-technical-requirements/04e-infrastructure/microservices.md) | Independent deployable services, async communication |

    **Testing:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [Auto Tests](04-technical-requirements/04f-testing/auto-tests.md) | Unit, integration, and E2E test suites |
    | [Testing](04-technical-requirements/04f-testing/testing.md) | Test strategy, quality metrics, coverage analysis |

    **Specialized:**

    | Criterion | What it covers |
    |-----------|---------------|
    | [AI Assistant](04-technical-requirements/04g-specialized/ai-assistant.md) | AI-powered features, prompt engineering, evaluation |
    | [Cryptography](04-technical-requirements/04g-specialized/cryptography.md) | Encryption, digital signatures, secure protocols |
    | [Machine Learning](04-technical-requirements/04g-specialized/machine-learning.md) | ML models, dataset handling, training, deployment |

    ### What happens next

    :arrow_right: **Stage 2:** Your supervisor signs your application and submits it to administration for approval.

??? success "Stage 2: Get Approved (Week 3)"

    ### What you need to do

    - [ ] Confirm your supervisor has signed your application
    - [ ] Wait for administration to approve your topic
    - [ ] If your topic needs changes, follow the [topic change process](02-getting-started/topic-changes.md)

    ### Prerequisites

    :white_check_mark: You have selected 7+ criteria and agreed on a topic with your supervisor.

    !!! warning "Failure risk"
        If your topic is not approved, you face **automatic expulsion** from the diploma process. Make sure your criteria count and topic meet requirements before submission.

    ### Key pages

    - [Diploma Lifecycle](03-process-and-timeline/diploma-lifecycle.md) — full process overview
    - [Topic Changes](02-getting-started/topic-changes.md) — how to adjust your topic if needed

    ### What happens next

    :arrow_right: **Stage 3:** Start building your project. Set up your repository and begin coding.

??? success "Stage 3: Plan & Start Building (Weeks 4–6)"

    ### What you need to do

    - [ ] Set up your project repository with proper structure
    - [ ] Start implementing your chosen architecture
    - [ ] Begin writing your [thesis documentation](05-deliverables/thesis-guide.md) early
    - [ ] Complete **Progress Review 1** with your supervisor (initial prototype/architecture)
    - [ ] Attend weekly 15-minute standups with your supervisor
    - [ ] Read the grading rubrics for your chosen criteria (links in Stage 1)

    ### Prerequisites

    :white_check_mark: Your topic is approved by administration.

    ### Key pages

    - [Thesis Guide](05-deliverables/thesis-guide.md) — how to write your thesis document
    - [Official Requirements](05-deliverables/official-requirements.md) — formatting rules
    - All [Technical Requirements](04-technical-requirements/04a-business-and-docs/business-analysis.md) for your chosen criteria

    ### What happens next

    :arrow_right: **Stage 4:** Start booking expert assessment slots and continue building.

??? success "Stage 4: Build & Get Assessed (Weeks 7–15)"

    ### What you need to do

    - [ ] [Book assessment slots](03-process-and-timeline/booking-slots.md) with experts for each criterion
    - [ ] Submit materials to experts **at least 1 week before** your booked slot
    - [ ] Attend expert meetings (max 2 per criterion: assessment + optional appeal)
    - [ ] Complete **Progress Review 2** (Week 10) — working MVP
    - [ ] Complete **Progress Review 3** (Weeks 13–15) — feature-complete build
    - [ ] Continue weekly standups with supervisor

    ### Prerequisites

    :white_check_mark: Topic approved. Repository set up. Development started.

    !!! warning "Complexity check at Week 10"
        At Progress Review 2, your supervisor **must assess** whether your project meets complexity requirements. If the project is too simple, they will notify you **in writing**. Take this seriously — the pre-defense committee can reject projects that lack overall complexity, even if individual criteria pass.

    !!! danger "Expert assessment failure"
        A grade below 5 or "not passed" on any criterion means you are **not admitted to final defense**.

    ### Key pages

    - [Expert Assessment](03-process-and-timeline/expert-assessment.md) — how assessments work
    - [Booking Slots](03-process-and-timeline/booking-slots.md) — how to book and rules
    - [Timeline](03-process-and-timeline/timeline.md) — week-by-week milestones

    ### What happens next

    :arrow_right: **Stage 5:** Start preparing your deliverables — video, presentation, thesis, and deployment.

??? success "Stage 5: Prepare Deliverables (Weeks 16–18)"

    ### What you need to do

    - [ ] Record your [demo video](05-deliverables/video-requirements.md) (30 sec – 2 min, .mp4, 1080p+)
    - [ ] Create your [presentation](05-deliverables/presentation-requirements.md) (12–18 slides + appendix)
    - [ ] Finalize your [thesis document](05-deliverables/thesis-guide.md)
    - [ ] Submit thesis to supervisor **at least 5 working days** before pre-defense
    - [ ] **Deploy your application** — it must be live and accessible before pre-defense
    - [ ] Complete **Progress Review 4** — final version + thesis draft

    ### Prerequisites

    :white_check_mark: Expert assessments in progress or completed. Feature-complete build.

    !!! danger "Hard blockers"
        Without these, you will **not be admitted** to pre-defense:

        - :x: No live deployment — committee cannot open/use your app
        - :x: No demo video — required for institutional records
        - :x: No thesis document — reviewer cannot write review

    ### Key pages

    - [Video Requirements](05-deliverables/video-requirements.md) — specs, structure, dos and don'ts
    - [Presentation Requirements](05-deliverables/presentation-requirements.md) — slide structure, quality checklist
    - [Official Requirements](05-deliverables/official-requirements.md) — thesis formatting rules
    - [Thesis Guide](05-deliverables/thesis-guide.md) — step-by-step writing guide

    ### What happens next

    :arrow_right: **Stage 6:** Present at pre-defense. Your supervisor must sign your admission.

??? success "Stage 6: Pre-Defense (Week 19)"

    ### What you need to do

    - [ ] Get supervisor's written admission (or written rejection with reasons)
    - [ ] Present to the pre-defense committee
    - [ ] Demonstrate your deployed application
    - [ ] Show your demo video
    - [ ] If approved, receive reviewer contact from administration (within 3 days)

    ### Prerequisites

    :white_check_mark: Video recorded. Presentation ready. Thesis submitted to supervisor. App deployed.

    !!! tip "Presentation strategy"
        The committee forms their impression in the first 2–3 minutes. Lead with your strongest features. Spend **70% of your time** on your best 3–4 criteria and the product demo. Save weaker areas for Q&A.

        See [Defense Preparation](06-defense-and-completion/defense-preparation.md) for detailed tips.

    ### Key pages

    - [Defense Preparation](06-defense-and-completion/defense-preparation.md) — how to prepare and present
    - [Review Templates](05-deliverables/review-templates.md) — understand the review process

    ### What happens next

    :arrow_right: **Stage 7:** Get your reviews, upload to the national repository, and prepare for final defense.

??? success "Stage 7: Final Defense (Weeks 20–22)"

    ### What you need to do

    - [ ] Send thesis + repo links + pre-filled review template to your assigned reviewer
    - [ ] Wait for independent review (confirm admin also received it)
    - [ ] Supervisor writes their review using `advisors-review.docx`
    - [ ] Upload thesis to [national repository](06-defense-and-completion/repository-upload.md) (talpykla.elaba.lt)
    - [ ] Verify all [final deliverables](06-defense-and-completion/final-deliverables-checklist.md) are complete
    - [ ] Attend final defense and present to committee + external experts

    ### Prerequisites

    :white_check_mark: Pre-defense passed. Reviewer contact received.

    ### Final deliverables checklist

    | # | Document | Ready? |
    |---|----------|--------|
    | 1 | Thesis document (PDF) | :black_square_button: |
    | 2 | Abstract (1-page English) | :black_square_button: |
    | 3 | Presentation (.pptx/.pdf) | :black_square_button: |
    | 4 | Demo video (.mp4) | :black_square_button: |
    | 5 | Advisor report | :black_square_button: |
    | 6 | Independent review | :black_square_button: |
    | 7 | Live deployment (URL) | :black_square_button: |

    ### Key pages

    - [Final Deliverables Checklist](06-defense-and-completion/final-deliverables-checklist.md) — everything that must exist
    - [Review Process](06-defense-and-completion/review-process.md) — how to get your review
    - [Repository Upload](06-defense-and-completion/repository-upload.md) — upload instructions
    - [Defense Preparation](06-defense-and-completion/defense-preparation.md) — presentation tips
